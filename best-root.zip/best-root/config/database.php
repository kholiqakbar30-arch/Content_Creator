<?php
return [
    'db_host' => 'localhost',
    'db_port' => '5432',
    'db_name' => 'best',
    'db_user' => 'postgres',
    'db_pass' => 'yamaha1*', // cuma di sini, tidak di Database.php
];
