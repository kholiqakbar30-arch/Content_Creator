<?php

// Tampilkan error saat development (nonaktifkan di production)
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// Mulai session di satu tempat saja
session_start();

// Force no cache untuk semua halaman
header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
header("Cache-Control: post-check=0, pre-check=0", false);
header("Pragma: no-cache");
header("Expires: Sat, 01 Jan 2000 00:00:00 GMT");

// Load autoloader
require_once __DIR__ . '/../app/Core/autoload.php';

// Load routes
require_once __DIR__ . '/../routes/web.php';

// Dispatch request ke route yang sesuai
\app\core\router::dispatch();