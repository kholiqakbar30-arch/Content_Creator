<?php
// Cegah cache halaman login
header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
header("Pragma: no-cache");
header("Expires: Sat, 01 Jan 2000 00:00:00 GMT");

// Kalau sudah login, langsung ke mainpage
if (isset($_SESSION['user_id'])) {
    header('Location: /best-root/public/mainpage');
    exit;
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="Cache-Control" content="no-store, no-cache, must-revalidate">
    <meta http-equiv="Pragma" content="no-cache">
    <meta http-equiv="Expires" content="0">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>BEST-login</title>
    <link rel="icon" type="image/x-icon" href="assets/images/favicon.ico">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: Arial, sans-serif;
            background-color:rgba(240, 239, 239, 0.56);
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
            overflow: hidden;
        }

        .container {
            position: relative;
            width: 50vw;
            max-width: 900px;
            height: 70vh;
            min-height: 500px;
            background: white;
            border-radius: 30px;
            overflow: hidden;
            box-shadow: 0 10px 40px rgba(0, 0, 0, 0.2);
        }

        .slide-panel {
            position: absolute;
            width: 50%;
            height: 100%;
            background: linear-gradient(220deg, #5dade2 0%,rgb(2, 94, 155) 100%);
            transition: all 0.8s cubic-bezier(0.68, -0.55, 0.265, 1.55);
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
            padding: 40px;
            z-index: 10;
        }

        .slide-panel.left {
            left: 0;
            border-radius: 0 200px 200px 0;
        }

        .slide-panel.right {
            right: 0;
            left: auto;
            background: linear-gradient(135deg,rgb(15, 85, 112) 0%,rgb(16, 141, 175) 100%);
            border-radius: 200px 0 0 200px;
        }

        @font-face {
            font-family: 'Forte';
            src: url('/best-root/assets/fonts/forte.ttf') format('truetype');
            font-weight: normal;
            font-style: normal;
        }
        
        .welcome-text {
            font-family: 'Forte', cursive;
            font-weight: bold;
            font-size: 2.5rem;
            color: #000;
            margin-bottom: 2px;
            text-align: center;
        }

        @font-face {
            font-family: 'Noto Sans Adlam';
            src: url('/best-root/assets/fonts/ADLaMDisplay-Regular.ttf') format('truetype');
            font-weight: normal;
            font-style: normal;
        }

        .brand-name {
            margin-bottom: 2px;
            display: flex;
            justify-content: center;
            align-items: center;
        }

        .brand-name img {
            width: 160px;
            height: auto;
            display: block;
        }

        .subtitle {
            font-family: 'Aptos', 'Segoe UI', sans-serif;
            color: white;
            font-size: 0.6rem;
            margin-bottom: 30px;
            margin-top: -20px;
            text-align: center;
            font-weight: bold;
        }

        .contact-text {
            font-family: 'Aptos', 'Segoe UI', sans-serif;
            color: white;
            font-size: 0.95rem;
            margin-bottom: 20px;
            text-align: center;
        }

        .btn-outline {
            font-family: 'Aptos', 'Segoe UI', sans-serif;
            background: transparent;
            border: 2px solid white;
            color: white;
            padding: 12px 40px;
            border-radius: 25px;
            font-size: 1rem;
            cursor: pointer;
            transition: all 0.3s;
            display: block;
            width: fit-content;
            margin: 0 auto;
        }

        .btn-outline:hover {
            background: white;
            color: #3498db;
        }

        .form-container {
            position: absolute;
            width: 50%;
            height: 100%;
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
            padding: 50px;
            transition: all 0.8s cubic-bezier(0.68, -0.55, 0.265, 1.55);
        }

        .form-container.left {
            left: 0;
            opacity: 1;
            pointer-events: auto;
        }

        .form-container.right {
            right: 0;
            left: auto;
            opacity: 1;
            pointer-events: auto;
        }

        .form-container.active {
            opacity: 1;
            pointer-events: auto;
            z-index: 5;
        }

        .form-container.inactive {
            opacity: 0;
            pointer-events: none;
            z-index: 1;
        }

        .form-title {
            font-family: 'Forte', cursive;
            font-weight: bold;
            font-size: 2.5rem;
            color: #000;
            margin-bottom: 40px;
        }

        .form-title-contact-admin {
            font-family: 'Forte', cursive;
            font-weight: bold;
            font-size: 2rem;
            color: #000;
            margin-bottom: 40px;
        }

        .input-group {
            width: 100%;
            margin-bottom: 20px;
            position: relative;
        }

        .input-field {
            width: 100%;
            padding: 15px 50px 15px 20px;
            border: none;
            background: #5dade2;
            border-radius: 25px;
            font-size: 1rem;
            color: white;
            outline: none;
            font-family: Arial, sans-serif;
        }

        .input-field::placeholder {
            color: rgba(255, 255, 255, 0.8);
        }

        .input-field.dark {
            background: #1a5f7a;
        }

        .input-icon {
            position: absolute;
            right: 20px;
            top: 50%;
            transform: translateY(-50%);
            color: white;
            font-size: 1.2rem;
        }

        .btn-primary {
            font-family: 'Aptos', 'Segoe UI', sans-serif;
            width: 100%;
            padding: 15px;
            background: #000;
            color: white;
            border: none;
            border-radius: 25px;
            font-size: 1.1rem;
            cursor: pointer;
            margin-top: 10px;
            transition: all 0.3s;
        }

        .btn-primary:hover {
            background: #333;
        }

        .forgot-password {
            font-family: 'Aptos', 'Segoe UI', sans-serif;
            color: #e74c3c;
            text-decoration: underline;
            margin-top: 15px;
            cursor: pointer;
            font-size: 1rem;
        }

        .send-text {
            font-family: 'Aptos', 'Segoe UI', sans-serif;
            color: #1a5f7a;
            font-size: 0.95rem;
            margin-bottom: 20px;
            text-align: center;
        }

        .already-account {
            font-family: 'Aptos', 'Segoe UI', sans-serif;
            color: white;
            font-size: 0.95rem;
            margin-bottom: 20px;
            text-align: center;
        }

        .alert-error {
            width: 100%;
            background: #fdecea;
            border: 1px solid #e74c3c;
            color: #c0392b;
            padding: 10px 16px;
            border-radius: 10px;
            margin-bottom: 10px;
            font-size: 0.85rem;
            text-align: center;
        }

        /* Fallback untuk font Forte */
        @font-face {
            font-family: 'Forte';
            src: local('Brush Script MT'), local('Lucida Handwriting'), local('Edwardian Script ITC');
            font-style: italic;
        }
    </style>
</head>
<body>
    <div class="container">
        <!-- Sliding Panel -->
        <div class="slide-panel left" id="slidePanel">
            <div id="panelContent">
                <!-- Content will be dynamically updated -->
            </div>
        </div>

        <!-- Login Form -->
        <div class="form-container right active" id="loginForm">
            <h1 class="form-title">Login</h1>

            <form action="/best-root/public/login" method="post">
                <div class="input-group">
                    <input type="text" name="npk" class="input-field" placeholder="ID User" required>
                    <span class="input-icon">👤</span>
                </div>

                <div class="input-group">
                    <input type="password" name="password" class="input-field" placeholder="Password" required>
                    <span class="input-icon">🔒</span>
                </div>

                <?php if (!empty($_GET['error'])): ?>
                    <div class="alert-error">
                        <?php if ($_GET['error'] === 'empty'): ?>
                            NPK dan password tidak boleh kosong.
                        <?php else: ?>
                            NPK atau password salah. Silakan coba lagi.
                        <?php endif; ?>
                    </div>
                <?php endif; ?>

                <button type="submit" class="btn-primary">Login</button>
            </form>

            <div class="forgot-password">Forgot your password</div>
        </div>

        <!-- Contact Admin Form -->
        <div class="form-container left inactive" id="contactForm">
            <h1 class="form-title-contact-admin">Contact Admin</h1>
            <div class="input-group">
                <input type="text" class="input-field dark" placeholder="NPK">
                <span class="input-icon">💳</span>
            </div>
            <div class="input-group">
                <input type="text" class="input-field dark" placeholder="Name">
                <span class="input-icon">👤</span>
            </div>
            <p class="send-text">Send to admin to get access</p>
            <button class="btn-primary">Send</button>
        </div>
    </div>

    <script>
        const slidePanel = document.getElementById('slidePanel');
        const panelContent = document.getElementById('panelContent');
        const loginForm = document.getElementById('loginForm');
        const contactForm = document.getElementById('contactForm');
        
        let isLoginView = true;

        function updatePanelContent() {
            if (isLoginView) {
                panelContent.innerHTML = `
                    <div class="welcome-text">Welcome to</div>
                    <div class="brand-name">
                        <img src="assets/images/apple-touch-icon.png" alt="Logo" class="brand-logo">
                    </div>
                    <div class="subtitle">Buyer Efficiency System Tools</div>
                    <div class="contact-text">Contact the admin to get access</div>
                    <button class="btn-outline" onclick="toggleView()">Contact Admin</button>
                `;
            } else {
                panelContent.innerHTML = `
                    <div class="welcome-text" style="color: #000;">Welcome to</div>
                    <div class="brand-name">
                        <img src="assets/images/apple-touch-icon.png" alt="Logo" class="brand-logo">
                    </div>
                    <div class="subtitle" style="color: #fff;">Buyer Efficiency System Tools</div>
                    <div class="already-account">Already have an account</div>
                    <button class="btn-outline" onclick="toggleView()">Login</button>
                `;
            }
        }

        function toggleView() {
            isLoginView = !isLoginView;
            
            if (isLoginView) {
                slidePanel.classList.remove('right');
                slidePanel.classList.add('left');
                slidePanel.style.background = 'linear-gradient(220deg, #5dade2 0%,rgb(2, 94, 155) 100%)';
                loginForm.classList.remove('inactive');
                loginForm.classList.add('right', 'active');
                contactForm.classList.remove('right', 'active');
                contactForm.classList.add('left', 'inactive');
            } else {
                slidePanel.classList.remove('left');
                slidePanel.classList.add('right');
                slidePanel.style.background = 'linear-gradient(135deg,rgb(15, 85, 112) 0%,rgb(16, 141, 175) 100%)';
                contactForm.classList.remove('inactive');
                contactForm.classList.add('left', 'active');
                loginForm.classList.remove('right', 'active');
                loginForm.classList.add('right', 'inactive');
            }
            
            updatePanelContent();
        }

        // Initialize
        updatePanelContent();

        // Cegah forward ke mainpage dari bfcache browser
        window.addEventListener('pageshow', function(e) {
            if (e.persisted) {
                window.location.reload();
            }
        });
    </script>
</body>
</html>