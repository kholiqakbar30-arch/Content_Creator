<?php
header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
header("Cache-Control: post-check=0, pre-check=0", false);
header("Pragma: no-cache");
header("Expires: Sat, 01 Jan 2000 00:00:00 GMT");

if (!isset($_SESSION['user_id'])) {
    header('Location: /best-root/public/login');
    exit;
}

$name = $_SESSION['name'] ?? 'User';
$role = $_SESSION['role'] ?? '-';
$npk  = $_SESSION['npk'] ?? '-';
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="Cache-Control" content="no-store, no-cache, must-revalidate">
    <meta http-equiv="Pragma" content="no-cache">
    <meta http-equiv="Expires" content="0">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" type="image/x-icon" href="assets/images/favicon.ico">
    <title>BEST - Mainpage</title>

    <!-- Bootstrap 5 Local -->
    <link rel="stylesheet" href="/best-root/assets/bootstrap-5.3.8/css/bootstrap.min.css">
    <!-- Bootstrap Icons Local -->
    <link rel="stylesheet" href="/best-root/public/bootstrap-5.3.8/font/bootstrap-icons.min.css">

    <style>
        :root {
            --sidebar-width: 220px;
            --sidebar-collapsed-width: 60px;
            --navbar-height: 60px;
            --primary: #1a5f7a;
            --primary-light: #5dade2;
            --primary-dark: #0f3d50;
            --bg: #f0f2f5;
            --sidebar-bg:rgb(255, 255, 255);
            --sidebar-text: #555;
            --sidebar-active: #1a5f7a;
            --transition: 0.3s ease;
        }

        * { margin: 0; padding: 0; box-sizing: border-box; }

        body {
            font-family: 'Segoe UI', sans-serif;
            background: var(--bg);
            overflow-x: hidden;
        }

        /* ===== SIDEBAR ===== */
        #sidebar {
            position: fixed;
            top: 0; left: 0;
            height: 100vh;
            width: var(--sidebar-width);
            background: var(--sidebar-bg);
            border-right: 1px solid #e8e8e8;
            box-shadow: 2px 0 8px rgba(0,0,0,0.06);
            transition: width var(--transition);
            z-index: 1000;
            overflow: hidden;
            display: flex;
            flex-direction: column;
        }

        #sidebar.collapsed { width: var(--sidebar-collapsed-width); }

        .sidebar-logo {
            display: flex;
            align-items: center;
            gap: 10px;
            padding: 12px 16px;
            border-bottom: 1px solid #f0f0f0;
            min-height: var(--navbar-height);
            white-space: nowrap;
            overflow: hidden;
        }

        .sidebar-logo .logo-icon {
            width: 36px; height: 36px;
            background: transparent;
            border-radius: 0;
            display: flex; align-items: center; justify-content: center;
            flex-shrink: 0;
        }

        .sidebar-logo .logo-icon img {
            width: 100%; height: 100%;
            object-fit: contain;
        }

        .sidebar-logo .logo-sub {
            font-size: 0.62rem;
            color: black;
            display: block;
            font-weight: 600;
            line-height: 1.5;
        }

        .sidebar-logo .text-sub {
            font-size: 1.5rem;
            color:rgba(31, 31, 31, 0.36);
            display: block;
            font-weight: 100;
            line-height: 1.3;
        }

        .sidebar-nav {
            flex: 1;
            overflow-y: auto; overflow-x: hidden;
            padding: 10px 0;
        }

        .sidebar-nav::-webkit-scrollbar { width: 3px; }
        .sidebar-nav::-webkit-scrollbar-thumb { background: #ddd; border-radius: 2px; }

        .nav-label {
            font-size: 0.62rem;
            text-transform: uppercase;
            letter-spacing: 1.2px;
            color: #aaa;
            padding: 10px 18px 4px;
            white-space: nowrap;
            transition: opacity var(--transition);
        }

        #sidebar.collapsed .nav-label { opacity: 0; }

        .nav-item-link {
            display: flex;
            align-items: center;
            gap: 12px;
            padding: 10px 16px;
            color: #555;
            text-decoration: none;
            cursor: pointer;
            transition: all var(--transition);
            white-space: nowrap;
            overflow: hidden;
            border-left: 3px solid transparent;
            margin: 1px 0;
        }

        .nav-item-link:hover {
            background: #f5f8ff;
            color: var(--primary);
        }

        .nav-item-link.active {
            background: #e8f4fd;
            color: var(--primary);
            border-left-color: var(--primary);
            font-weight: 600;
        }

        .nav-item-link i { font-size: 1.1rem; flex-shrink: 0; width: 20px; text-align: center; }

        .nav-item-link .nav-text {
            font-size: 0.85rem; font-weight: 500;
            transition: opacity var(--transition);
        }

        #sidebar.collapsed .nav-text { opacity: 0; }

        .sidebar-footer {
            border-top: 1px solid #f0f0f0;
            padding: 12px 16px;
            display: flex; align-items: center; gap: 10px;
            white-space: nowrap; overflow: hidden;
        }

        .sidebar-footer .avatar {
            width: 34px; height: 34px;
            background: linear-gradient(135deg, var(--primary), var(--primary-light));
            border-radius: 50%;
            display: flex; align-items: center; justify-content: center;
            color: white; font-weight: 700; font-size: 0.85rem; flex-shrink: 0;
        }

        .sidebar-footer .user-name { font-size: 0.82rem; color: #333; font-weight: 600; }
        .sidebar-footer .user-role { font-size: 0.68rem; color: #999; }

        /* ===== NAVBAR ===== */
        #navbar {
            position: fixed;
            top: 0; left: var(--sidebar-width); right: 0;
            height: var(--navbar-height);
            background: white;
            box-shadow: 0 1px 8px rgba(0,0,0,0.08);
            display: flex; align-items: center; justify-content: space-between;
            padding: 0 24px;
            z-index: 999;
            transition: left var(--transition);
        }

        #navbar.collapsed { left: var(--sidebar-collapsed-width); }

        .navbar-left { 
            display: flex; 
            align-items: center; 
            gap: 16px; 
            margin-left: -30px
        }

        #toggleSidebar {
            background: transparent;
            border: none;
            font-size: 1.3rem;
            padding: 8px 12px;
            margin-left: 0;
            cursor: pointer;
            display: flex;
            align-items: center;
            justify-content: center;
        }

        #toggleSidebar:hover {
            background: #f4f6f9;
            border-radius: 8px;
        }

        .page-title { font-size: 1rem; font-weight: 600; color: var(--primary-dark); }

        .navbar-right {
            display: flex;
            align-items: center;
            gap: 18px;
            padding-right: 10px; /* biar gak nempel ke kanan */
        }

        .nav-divider {
            width: 1px;
            height: 26px;
            background: #e5e5e5;
        }

        .btn-notif {
            width: 40px;
            height: 40px;
            border-radius: 12px;
            border: none;
            background: #f8fafc;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 1.1rem;
            color: #555;
            position: relative;
            cursor: pointer;
            transition: all 0.2s ease;
        }

        .btn-notif:hover {
            background: #eef4ff;
            color: var(--primary);
        }

        .notif-badge {
            position: absolute;
            top: 8px;
            right: 8px;
            width: 8px;
            height: 8px;
            background: #e74c3c;
            border-radius: 50%;
        }

        .user-dropdown {
            display: flex;
            align-items: center;
            gap: 12px;
            padding: 6px 14px;
            border-radius: 12px;
            cursor: pointer;
            transition: all 0.2s ease;
        }

        .user-dropdown:hover {
            background: #f4f6f9;
        }

        .avatar-sm {
            width: 34px;
            height: 34px;
            font-size: 0.85rem;
        }

        .user-info {
            display: flex;
            flex-direction: column;
            line-height: 1.2;
        }

        .user-name-nav {
            font-size: 0.85rem;
            font-weight: 600;
            color: var(--primary-dark);
        }

        .user-role-nav {
            font-size: 0.7rem;
            color: #999;
        }

        .chevron {
            font-size: 0.65rem;
            color: #888;
        }

        /* ===== MAIN CONTENT ===== */
        #main-content {
            margin-left: var(--sidebar-width);
            margin-top: var(--navbar-height);
            padding: 28px;
            min-height: calc(100vh - var(--navbar-height));
            transition: margin-left var(--transition);
        }

        #main-content.collapsed { margin-left: var(--sidebar-collapsed-width); }

        /* ===== PAGES ===== */
        .page { display: none; animation: fadeIn 0.3s ease; }
        .page.active { display: block; }

        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(8px); }
            to   { opacity: 1; transform: translateY(0); }
        }

        /* ===== CARDS ===== */
        .stat-card {
            background: white; border-radius: 14px;
            padding: 22px 24px;
            box-shadow: 0 2px 12px rgba(0,0,0,0.06);
            display: flex; align-items: center; gap: 18px;
            transition: transform 0.2s, box-shadow 0.2s;
        }

        .stat-card:hover { transform: translateY(-3px); box-shadow: 0 6px 20px rgba(0,0,0,0.1); }

        .stat-icon {
            width: 52px; height: 52px; border-radius: 12px;
            display: flex; align-items: center; justify-content: center;
            font-size: 1.4rem; flex-shrink: 0;
        }

        .stat-value { font-size: 1.6rem; font-weight: 700; color: var(--primary-dark); line-height: 1; }
        .stat-label { font-size: 0.8rem; color: #888; margin-top: 4px; }
        .stat-change { font-size: 0.75rem; margin-top: 4px; }

        .content-card {
            background: white; border-radius: 14px;
            padding: 24px;
            box-shadow: 0 2px 12px rgba(0,0,0,0.06);
        }

        .card-header-custom {
            display: flex; align-items: center; justify-content: space-between;
            margin-bottom: 20px; padding-bottom: 14px;
            border-bottom: 1px solid #f0f0f0;
        }

        .card-header-custom h5 { font-size: 0.95rem; font-weight: 600; color: var(--primary-dark); }

        @media (max-width: 768px) {
            #sidebar { width: var(--sidebar-collapsed-width); }
            #navbar { left: var(--sidebar-collapsed-width); }
            #main-content { margin-left: var(--sidebar-collapsed-width); }
        }
    </style>
</head>
<body>

<!-- ===== SIDEBAR ===== -->
<div id="sidebar">
    <div class="sidebar-logo">
        <div class="logo-icon">
            <img src="assets/images/apple-touch-icon.png" alt="Logo" class="BEST logo">
        </div>
        <div>
            <span class="text-sub">|</span>
        </div>
        <div>
            <span class="logo-sub">Buyer Efficiency System Tools</span>
        </div>
    </div>

    <nav class="sidebar-nav">
        <div class="nav-label">MENU UTAMA</div>

        <a class="nav-item-link active" onclick="showPage('dashboard', this)">
            <i class="bi bi-grid-1x2-fill"></i>
            <span class="nav-text">Dashboard</span>
        </a>
        <a class="nav-item-link" onclick="showPage('purchase-order', this)">
            <i class="bi bi-cart3"></i>
            <span class="nav-text">Purchase Order</span>
        </a>
        <a class="nav-item-link" onclick="showPage('vendor', this)">
            <i class="bi bi-people-fill"></i>
            <span class="nav-text">Vendor</span>
        </a>
        <a class="nav-item-link" onclick="showPage('laporan', this)">
            <i class="bi bi-bar-chart-fill"></i>
            <span class="nav-text">Laporan</span>
        </a>

        <div class="nav-label">SISTEM</div>

        <a class="nav-item-link" onclick="showPage('pengaturan', this)">
            <i class="bi bi-gear-fill"></i>
            <span class="nav-text">Pengaturan</span>
        </a>
        <a class="nav-item-link" href="/best-root/public/logout">
            <i class="bi bi-box-arrow-left"></i>
            <span class="nav-text">Logout</span>
        </a>
    </nav>

    <div class="sidebar-footer">
        <div class="avatar"><?= strtoupper(substr($name, 0, 1)) ?></div>
        <div>
            <div class="user-name"><?= htmlspecialchars($name) ?></div>
            <div class="user-role"><?= htmlspecialchars($role) ?></div>
        </div>
    </div>
</div>

<!-- ===== NAVBAR ===== -->
<div id="navbar">
    <div class="navbar-left">
        <button id="toggleSidebar" onclick="toggleSidebar()">
            <i id="toggleIcon" class="bi bi-chevron-left"></i>
        </button>
        <span class="page-title" id="pageTitle">Dashboard</span>
    </div>
    <div class="navbar-right">
        <button class="btn-notif">
            <i class="bi bi-bell"></i>
            <span class="notif-badge"></span>
        </button>

        <div class="nav-divider"></div>

        <div class="dropdown">
            <div class="user-dropdown" data-bs-toggle="dropdown">
                <div class="avatar-sm"><?= strtoupper(substr($name, 0, 1)) ?></div>
                <div class="user-info">
                    <div class="user-name-nav"><?= htmlspecialchars($name) ?></div>
                    <div class="user-role-nav"><?= htmlspecialchars($role) ?></div>
                </div>
                <i class="bi bi-chevron-down chevron"></i>
            </div>
            <ul class="dropdown-menu dropdown-menu-end shadow border-0" style="border-radius:10px; min-width:200px; padding:6px;">
                <li class="px-3 py-2" style="border-bottom:1px solid #f0f0f0; margin-bottom:4px;">
                    <div style="font-size:0.82rem; font-weight:600; color:#333;"><?= htmlspecialchars($name) ?></div>
                    <div style="font-size:0.75rem; color:#999;"><?= htmlspecialchars($npk) ?> &middot; <?= htmlspecialchars($role) ?></div>
                </li>
                <li>
                    <a class="dropdown-item" href="#" onclick="showPage('pengaturan', null)" style="font-size:0.85rem; border-radius:6px;">
                        <i class="bi bi-person me-2" style="color:var(--primary);"></i>Profil Saya
                    </a>
                </li>
                <li>
                    <a class="dropdown-item" href="#" style="font-size:0.85rem; border-radius:6px;">
                        <i class="bi bi-bell me-2" style="color:var(--primary);"></i>Notifikasi
                    </a>
                </li>
                <li style="border-top:1px solid #f0f0f0; margin-top:4px; padding-top:4px;">
                    <a class="dropdown-item text-danger" href="/best-root/public/logout" style="font-size:0.85rem; border-radius:6px;">
                        <i class="bi bi-box-arrow-left me-2"></i>Logout
                    </a>
                </li>
            </ul>
        </div>
    </div>
</div>

<!-- ===== MAIN CONTENT ===== -->
<div id="main-content">

    <!-- PAGE: DASHBOARD -->
    <div class="page active" id="page-dashboard">
        <div class="mb-4">
            <h4 style="color:var(--primary-dark); font-weight:700;">Selamat Datang, <?= htmlspecialchars($name) ?>! 👋</h4>
            <p class="text-muted" style="font-size:0.9rem;">Berikut ringkasan aktivitas sistem hari ini.</p>
        </div>

        <div class="row g-3 mb-4">
            <div class="col-12 col-sm-6 col-xl-3">
                <div class="stat-card">
                    <div class="stat-icon" style="background:#e8f4fd;"><i class="bi bi-cart3" style="color:#3498db;"></i></div>
                    <div>
                        <div class="stat-value">24</div>
                        <div class="stat-label">Purchase Order</div>
                        <div class="stat-change text-success"><i class="bi bi-arrow-up"></i> 12% bulan ini</div>
                    </div>
                </div>
            </div>
            <div class="col-12 col-sm-6 col-xl-3">
                <div class="stat-card">
                    <div class="stat-icon" style="background:#fef9e7;"><i class="bi bi-hourglass-split" style="color:#f39c12;"></i></div>
                    <div>
                        <div class="stat-value">8</div>
                        <div class="stat-label">PO Pending</div>
                        <div class="stat-change text-warning"><i class="bi bi-dash"></i> Menunggu approval</div>
                    </div>
                </div>
            </div>
            <div class="col-12 col-sm-6 col-xl-3">
                <div class="stat-card">
                    <div class="stat-icon" style="background:#eafaf1;"><i class="bi bi-people-fill" style="color:#27ae60;"></i></div>
                    <div>
                        <div class="stat-value">36</div>
                        <div class="stat-label">Vendor Aktif</div>
                        <div class="stat-change text-success"><i class="bi bi-arrow-up"></i> 3 vendor baru</div>
                    </div>
                </div>
            </div>
            <div class="col-12 col-sm-6 col-xl-3">
                <div class="stat-card">
                    <div class="stat-icon" style="background:#fdedec;"><i class="bi bi-exclamation-triangle-fill" style="color:#e74c3c;"></i></div>
                    <div>
                        <div class="stat-value">3</div>
                        <div class="stat-label">PO Overdue</div>
                        <div class="stat-change text-danger"><i class="bi bi-arrow-up"></i> Perlu perhatian</div>
                    </div>
                </div>
            </div>
        </div>

        <div class="row g-3">
            <div class="col-12 col-lg-7">
                <div class="content-card">
                    <div class="card-header-custom">
                        <h5><i class="bi bi-clock-history me-2" style="color:var(--primary-light);"></i>Aktivitas Terbaru</h5>
                        <span class="badge" style="background:var(--bg); color:var(--primary); font-size:0.75rem; padding:6px 10px; border-radius:8px;">Hari ini</span>
                    </div>
                    <div class="list-group list-group-flush">
                        <?php
                        $activities = [
                            ['icon'=>'bi-cart-check','color'=>'#27ae60','text'=>'PO #2024-001 disetujui','time'=>'10 menit lalu'],
                            ['icon'=>'bi-person-plus','color'=>'#3498db','text'=>'Vendor baru: PT. Maju Jaya','time'=>'1 jam lalu'],
                            ['icon'=>'bi-exclamation-circle','color'=>'#e74c3c','text'=>'PO #2024-005 overdue','time'=>'2 jam lalu'],
                            ['icon'=>'bi-file-earmark-check','color'=>'#9b59b6','text'=>'Laporan bulan ini selesai','time'=>'3 jam lalu'],
                        ];
                        foreach ($activities as $a): ?>
                        <div class="list-group-item border-0 px-0 py-2 d-flex align-items-center gap-3">
                            <div style="width:34px;height:34px;background:<?= $a['color'] ?>18;border-radius:8px;display:flex;align-items:center;justify-content:center;flex-shrink:0;">
                                <i class="bi <?= $a['icon'] ?>" style="color:<?= $a['color'] ?>;font-size:0.9rem;"></i>
                            </div>
                            <div class="flex-grow-1">
                                <div style="font-size:0.85rem;color:#333;"><?= $a['text'] ?></div>
                                <div style="font-size:0.75rem;color:#aaa;"><?= $a['time'] ?></div>
                            </div>
                        </div>
                        <?php endforeach; ?>
                    </div>
                </div>
            </div>
            <div class="col-12 col-lg-5">
                <div class="content-card h-100">
                    <div class="card-header-custom">
                        <h5><i class="bi bi-pie-chart-fill me-2" style="color:var(--primary-light);"></i>Status PO</h5>
                    </div>
                    <div class="d-flex flex-column gap-3">
                        <?php
                        $statuses = [
                            ['label'=>'Approved','value'=>13,'total'=>24,'color'=>'#27ae60'],
                            ['label'=>'Pending','value'=>8,'total'=>24,'color'=>'#f39c12'],
                            ['label'=>'Overdue','value'=>3,'total'=>24,'color'=>'#e74c3c'],
                        ];
                        foreach ($statuses as $s):
                            $pct = round($s['value']/$s['total']*100);
                        ?>
                        <div>
                            <div class="d-flex justify-content-between mb-1">
                                <span style="font-size:0.82rem;color:#555;"><?= $s['label'] ?></span>
                                <span style="font-size:0.82rem;font-weight:600;color:<?= $s['color'] ?>;"><?= $s['value'] ?> (<?= $pct ?>%)</span>
                            </div>
                            <div class="progress" style="height:8px;border-radius:4px;background:#f0f0f0;">
                                <div class="progress-bar" style="width:<?= $pct ?>%;background:<?= $s['color'] ?>;border-radius:4px;"></div>
                            </div>
                        </div>
                        <?php endforeach; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- PAGE: PURCHASE ORDER -->
    <div class="page" id="page-purchase-order">
        <div class="mb-4 d-flex justify-content-between align-items-center">
            <div>
                <h4 style="color:var(--primary-dark);font-weight:700;">Purchase Order</h4>
                <p class="text-muted" style="font-size:0.9rem;">Kelola semua purchase order</p>
            </div>
            <button class="btn btn-sm" style="background:var(--primary);color:white;border-radius:8px;padding:8px 16px;">
                <i class="bi bi-plus-lg me-1"></i> Buat PO Baru
            </button>
        </div>
        <div class="content-card">
            <div class="card-header-custom">
                <h5><i class="bi bi-table me-2" style="color:var(--primary-light);"></i>Daftar PO</h5>
                <input type="text" class="form-control form-control-sm" placeholder="Cari PO..." style="width:200px;border-radius:8px;">
            </div>
            <div class="table-responsive">
                <table class="table table-hover align-middle" style="font-size:0.85rem;">
                    <thead style="background:#f8f9fa;">
                        <tr><th>No. PO</th><th>Vendor</th><th>Tanggal</th><th>Total</th><th>Status</th><th>Aksi</th></tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td><strong>#2024-001</strong></td><td>PT. Maju Jaya</td><td>01 Feb 2024</td><td>Rp 15.000.000</td>
                            <td><span class="badge" style="background:#eafaf1;color:#27ae60;border-radius:6px;">Approved</span></td>
                            <td><button class="btn btn-sm btn-outline-primary" style="border-radius:6px;font-size:0.75rem;">Detail</button></td>
                        </tr>
                        <tr>
                            <td><strong>#2024-002</strong></td><td>CV. Sukses Makmur</td><td>03 Feb 2024</td><td>Rp 8.500.000</td>
                            <td><span class="badge" style="background:#fef9e7;color:#f39c12;border-radius:6px;">Pending</span></td>
                            <td><button class="btn btn-sm btn-outline-primary" style="border-radius:6px;font-size:0.75rem;">Detail</button></td>
                        </tr>
                        <tr>
                            <td><strong>#2024-003</strong></td><td>PT. Karya Mandiri</td><td>28 Jan 2024</td><td>Rp 22.000.000</td>
                            <td><span class="badge" style="background:#fdedec;color:#e74c3c;border-radius:6px;">Overdue</span></td>
                            <td><button class="btn btn-sm btn-outline-primary" style="border-radius:6px;font-size:0.75rem;">Detail</button></td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <!-- PAGE: VENDOR -->
    <div class="page" id="page-vendor">
        <div class="mb-4 d-flex justify-content-between align-items-center">
            <div>
                <h4 style="color:var(--primary-dark);font-weight:700;">Vendor</h4>
                <p class="text-muted" style="font-size:0.9rem;">Manajemen data vendor</p>
            </div>
            <button class="btn btn-sm" style="background:var(--primary);color:white;border-radius:8px;padding:8px 16px;">
                <i class="bi bi-plus-lg me-1"></i> Tambah Vendor
            </button>
        </div>
        <div class="content-card">
            <div class="card-header-custom">
                <h5><i class="bi bi-people-fill me-2" style="color:var(--primary-light);"></i>Daftar Vendor</h5>
                <input type="text" class="form-control form-control-sm" placeholder="Cari vendor..." style="width:200px;border-radius:8px;">
            </div>
            <div class="table-responsive">
                <table class="table table-hover align-middle" style="font-size:0.85rem;">
                    <thead style="background:#f8f9fa;">
                        <tr><th>Nama Vendor</th><th>Kontak</th><th>Kategori</th><th>Total PO</th><th>Status</th><th>Aksi</th></tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td><strong>PT. Maju Jaya</strong></td><td>021-5551234</td><td>Material</td><td>12 PO</td>
                            <td><span class="badge" style="background:#eafaf1;color:#27ae60;border-radius:6px;">Aktif</span></td>
                            <td><button class="btn btn-sm btn-outline-primary" style="border-radius:6px;font-size:0.75rem;">Detail</button></td>
                        </tr>
                        <tr>
                            <td><strong>CV. Sukses Makmur</strong></td><td>021-5559876</td><td>Jasa</td><td>5 PO</td>
                            <td><span class="badge" style="background:#eafaf1;color:#27ae60;border-radius:6px;">Aktif</span></td>
                            <td><button class="btn btn-sm btn-outline-primary" style="border-radius:6px;font-size:0.75rem;">Detail</button></td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <!-- PAGE: LAPORAN -->
    <div class="page" id="page-laporan">
        <div class="mb-4">
            <h4 style="color:var(--primary-dark);font-weight:700;">Laporan</h4>
            <p class="text-muted" style="font-size:0.9rem;">Lihat laporan dan analitik</p>
        </div>
        <div class="content-card">
            <div class="card-header-custom">
                <h5><i class="bi bi-bar-chart-fill me-2" style="color:var(--primary-light);"></i>Laporan Bulanan</h5>
            </div>
            <p class="text-muted" style="font-size:0.9rem;">Fitur laporan akan segera tersedia.</p>
        </div>
    </div>

    <!-- PAGE: PENGATURAN -->
    <div class="page" id="page-pengaturan">
        <div class="mb-4">
            <h4 style="color:var(--primary-dark);font-weight:700;">Pengaturan</h4>
            <p class="text-muted" style="font-size:0.9rem;">Konfigurasi akun dan sistem</p>
        </div>
        <div class="content-card">
            <div class="card-header-custom">
                <h5><i class="bi bi-person-fill me-2" style="color:var(--primary-light);"></i>Informasi Akun</h5>
            </div>
            <div class="row g-3" style="max-width:500px;">
                <div class="col-12">
                    <label class="form-label" style="font-size:0.85rem;font-weight:600;">Nama</label>
                    <input type="text" class="form-control" value="<?= htmlspecialchars($name) ?>" style="border-radius:8px;">
                </div>
                <div class="col-12">
                    <label class="form-label" style="font-size:0.85rem;font-weight:600;">NPK</label>
                    <input type="text" class="form-control" value="<?= htmlspecialchars($npk) ?>" readonly style="border-radius:8px;background:#f8f9fa;">
                </div>
                <div class="col-12">
                    <label class="form-label" style="font-size:0.85rem;font-weight:600;">Role</label>
                    <input type="text" class="form-control" value="<?= htmlspecialchars($role) ?>" readonly style="border-radius:8px;background:#f8f9fa;">
                </div>
                <div class="col-12">
                    <button class="btn" style="background:var(--primary);color:white;border-radius:8px;font-size:0.85rem;">Simpan Perubahan</button>
                </div>
            </div>
        </div>
    </div>

</div>

<!-- Bootstrap JS Local -->
<script src="/best-root/assets/bootstrap-5.3.8/js/bootstrap.bundle.min.js"></script>
<script>
    let sidebarCollapsed = false;

    function toggleSidebar() {
        const sidebar = document.getElementById("sidebar");
        const icon = document.getElementById("toggleIcon");

        sidebar.classList.toggle("collapsed");

        if (sidebar.classList.contains("collapsed")) {
            icon.classList.remove("bi-chevron-left");
            icon.classList.add("bi-chevron-right");
        } else {
            icon.classList.remove("bi-chevron-right");
            icon.classList.add("bi-chevron-left");
        }
    }

    const pageTitles = {
        'dashboard': 'Dashboard',
        'purchase-order': 'Purchase Order',
        'vendor': 'Vendor',
        'laporan': 'Laporan',
        'pengaturan': 'Pengaturan',
    };

    function showPage(pageId, clickedEl) {
        document.querySelectorAll('.page').forEach(p => p.classList.remove('active'));
        const target = document.getElementById('page-' + pageId);
        if (target) target.classList.add('active');

        document.querySelectorAll('.nav-item-link').forEach(el => el.classList.remove('active'));
        if (clickedEl) clickedEl.classList.add('active');

        document.getElementById('pageTitle').textContent = pageTitles[pageId] || pageId;
    }

    window.addEventListener('pageshow', function(e) {
        if (e.persisted) window.location.reload();
    });
</script>

</body>
</html>