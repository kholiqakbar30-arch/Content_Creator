<?php
header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
header("Cache-Control: post-check=0, pre-check=0", false);
header("Pragma: no-cache");
header("Expires: Sat, 01 Jan 2000 00:00:00 GMT");

if (!isset($_SESSION['user_id'])) {
    header('Location: /best-root/public/login');
    exit;
}

$name = $_SESSION['name'] ?? 'User';
$role = $_SESSION['role'] ?? '-';
$npk  = $_SESSION['npk'] ?? '-';
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="Cache-Control" content="no-store, no-cache, must-revalidate">
    <meta http-equiv="Pragma" content="no-cache">
    <meta http-equiv="Expires" content="0">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" type="image/x-icon" href="assets/images/favicon.ico">
    <title>BEST - Mainpage</title>
    <link rel="stylesheet" href="/best-root/public/bootstrap-5.3.8/css/bootstrap.min.css">
    <link rel="stylesheet" href="/best-root/public/bootstrap-5.3.8/font/bootstrap-icons.min.css">
    <style>
        :root {
            --sidebar-width: 230px;
            --sidebar-collapsed-width: 60px;
            --navbar-height: 60px;
            --primary: #4f46e5;
            --primary-light: #818cf8;
            --primary-dark: #1e1b4b;
            --primary-hover-bg: #eef2ff;
            --bg: #f5f6fa;
            --transition: 0.3s ease;
        }
        @font-face {
            font-family: 'Forte';
            src: url('/best-root/public/assets/fonts/forte.ttf') format('truetype');
        }
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { font-family: 'Segoe UI', system-ui, sans-serif; background: var(--bg); overflow-x: hidden; color: #374151; }

        /* SIDEBAR */
        #sidebar {
            position: fixed; top: 0; left: 0; height: 100vh;
            width: var(--sidebar-width); background: #fff;
            border-right: 1px solid #e8e8e8; box-shadow: 2px 0 8px rgba(0,0,0,0.05);
            transition: width var(--transition); z-index: 1000;
            overflow: hidden; display: flex; flex-direction: column;
        }
        #sidebar.collapsed { width: var(--sidebar-collapsed-width); }

        .sidebar-logo {
            display: flex; align-items: center; gap: 10px;
            padding: 12px 16px; border-bottom: 1px solid #f0f0f0;
            min-height: var(--navbar-height); white-space: nowrap; overflow: hidden; flex-shrink: 0;
        }
        .sidebar-logo .logo-icon { width: 34px; height: 34px; flex-shrink: 0; }
        .sidebar-logo .logo-icon img { width: 100%; height: 100%; object-fit: contain; }
        .sidebar-logo .divider { font-size: 1.4rem; color: rgba(0,0,0,0.2); font-weight: 100; }
        .sidebar-logo .brand { font-size: 0.6rem; font-weight: 700; color: #374151; line-height: 1.5; }

        .sidebar-nav { flex: 1; overflow-y: auto; overflow-x: hidden; padding: 8px 0; }
        .sidebar-nav::-webkit-scrollbar { width: 3px; }
        .sidebar-nav::-webkit-scrollbar-thumb { background: #e0e0e0; border-radius: 2px; }

        .nav-label {
            font-size: 0.58rem; text-transform: uppercase; letter-spacing: 1.2px;
            color: #9ca3af; padding: 10px 18px 4px; white-space: nowrap;
            transition: opacity var(--transition);
        }
        #sidebar.collapsed .nav-label { opacity: 0; }

        .nav-item-link {
            display: flex; align-items: center; gap: 10px;
            padding: 9px 16px; color: #0161cfff; text-decoration: none;
            cursor: pointer; transition: all var(--transition);
            white-space: nowrap; overflow: hidden;
            border-left: 3px solid transparent; margin: 1px 0;
        }
        .nav-item-link:hover { background: var(--primary-hover-bg); color: var(--primary); }
        .nav-item-link.active { background: var(--primary-hover-bg); color: var(--primary); border-left-color: var(--primary); font-weight: 600; }
        .nav-item-link .nav-icon { font-size: 1rem; flex-shrink: 0; width: 20px; text-align: center; }
        .nav-item-link .nav-text { font-size: 0.83rem; font-weight: 500; flex: 1; transition: opacity var(--transition); }
        .nav-item-link .nav-arrow { font-size: 0.6rem; color: #ccc; transition: transform 0.25s, opacity var(--transition); flex-shrink: 0; }
        #sidebar.collapsed .nav-text, #sidebar.collapsed .nav-arrow { opacity: 0; }
        .nav-item-link.has-sub.open .nav-arrow { transform: rotate(90deg); }

        .nav-submenu { overflow: hidden; max-height: 0; transition: max-height 0.3s ease; background: #fafafa; }
        .nav-submenu.open { max-height: 300px; }
        #sidebar.collapsed .nav-submenu { display: none; }

        .nav-sub-link {
            display: flex; align-items: center; gap: 8px;
            padding: 7px 16px 7px 44px; color: #0076fdff; text-decoration: none;
            font-size: 0.79rem; cursor: pointer; transition: all 0.2s;
            border-left: 3px solid transparent;
        }
        .nav-sub-link:hover { background: var(--primary-hover-bg); color: var(--primary); }
        .nav-sub-link.active { color: var(--primary); font-weight: 600; border-left-color: var(--primary); background: var(--primary-hover-bg); }
        .nav-sub-link i { font-size: 0.78rem; width: 14px; text-align: center; flex-shrink: 0; }

        .sidebar-footer { border-top: 1px solid #f0f0f0; padding: 10px 16px; white-space: nowrap; overflow: hidden; flex-shrink: 0; }
        .sidebar-footer .footer-copy { font-size: 0.61rem; color: #b0b7c3; display: flex; align-items: center; gap: 3px; }
        .sidebar-footer .footer-copy img { width: 13px; height: 13px; object-fit: contain; }

        /* NAVBAR */
        #navbar {
            position: fixed; top: 0; left: var(--sidebar-width); right: 0;
            height: var(--navbar-height); background: white;
            box-shadow: 0 1px 8px rgba(0,0,0,0.08);
            display: flex; align-items: center; justify-content: space-between;
            padding: 0 24px; transition: left var(--transition);
            padding-bottom: 0 24px; z-index: 998;
            align-items: stretch;
        }
        #navbar.collapsed { left: var(--sidebar-collapsed-width); }
        .navbar-left {
            display: flex;
            align-items: flex-end;
            gap: 16px;
            margin-left: -30px;
            flex: 1;
            overflow-x: auto;
            white-space: nowrap;
            line-height: 1;
        }
        #toggleSidebar {
            background: transparent; 
            border: none; 
            font-size: 28px; 
            padding-top: 12px;
            padding-bottom: 12px;
            padding-left: 5px;
            padding-right: 2px;
            cursor: pointer; 
            border-radius: 8px; 
            color: #555; 
            transition: all 0.2s;
            display: flex; 
            align-items: center;
            margin-left: -10px;
            margin-bottom: 2px;
            height: 59px;
        }
        #toggleSidebar:hover { background: var(--primary-hover-bg); color: var(--primary); }
        .page-title { font-size: 1rem; font-weight: 600; color: #111827; }
        .page-title.hidden { display: none; }
        .navbar-right {
            display: flex;
            align-items: center;
            gap: 8px;
            flex-shrink: 0;
            padding-left: 12px;
            border-left: 1px solid #e5e7eb;
            margin-left: 8px;
        }
        .nav-divider { width: 1px; height: 26px; background: #e5e5e5; }
        .btn-notif {
            width: 40px; height: 40px; border-radius: 12px; border: none;
            background: #f8fafc; display: flex; align-items: center; justify-content: center;
            font-size: 1.1rem; color: #555; position: relative; cursor: pointer; transition: all 0.2s;
        }
        .btn-notif:hover { background: var(--primary-hover-bg); color: var(--primary); }
        .notif-badge { position: absolute; top: 8px; right: 8px; width: 8px; height: 8px; background: #dc2626; border-radius: 50%; }
        .user-dropdown {
            display: flex; align-items: center; gap: 10px; padding: 5px 10px;
            border-radius: 12px; cursor: pointer; border: none; background: transparent;
            outline: none; box-shadow: none; transition: background 0.2s;
        }
        .user-dropdown:hover, .user-dropdown:focus { background: #f0f1f5; box-shadow: none; }
        .avatar-sm {
            width: 34px; height: 34px; min-width: 34px;
            font-family: 'Forte', serif; font-size: 1rem;
            background: linear-gradient(135deg, var(--primary), var(--primary-light));
            border-radius: 50%; display: flex; align-items: center; justify-content: center;
            color: white; font-weight: 700; flex-shrink: 0;
        }
        .user-info { display: flex; flex-direction: column; line-height: 1.2; }
        .user-name-nav { font-size: 0.85rem; font-weight: 600; color: #111827; }
        .user-role-nav { font-size: 0.7rem; color: #9ca3af; }

        /* TAB STYLES - MICROSOFT EDGE INSPIRED */
        .tab-container {
            overflow-x: hidden;
            scroll-behavior: smooth;
            -webkit-overflow-scrolling: touch;
            transition: overflow-x 0.3s ease;
        }
        
        .tab-container {
            overflow-x: auto;
            scroll-behavior: smooth;
            -webkit-overflow-scrolling: touch;
            scrollbar-width: none;
            -ms-overflow-style: none;
        }

        .tab-container::-webkit-scrollbar {
            display: none;
            width: 0;
            height: 0;
        }

        .tab-container:hover::-webkit-scrollbar-thumb,
        .tab-container.scrolling::-webkit-scrollbar-thumb {
            opacity: 1;
        }
        
        .tab-container::-webkit-scrollbar-thumb:hover {
            background: #94a3b8;
        }
        
        .tab-container::-webkit-scrollbar-track {
            background: transparent;
        }
        
        .tab-container::after {
            content: '';
            position: absolute;
            right: 0;
            top: 0;
            bottom: 0;
            width: 30px;
            background: linear-gradient(to right, transparent, white);
            pointer-events: none;
            opacity: 0;
            transition: opacity 0.3s ease;
        }
        
        .tab-container.can-scroll-right::after {
            opacity: 1;
        }
        
        .tab-container::before {
            content: '';
            position: absolute;
            left: 0;
            top: 0;
            bottom: 0;
            width: 30px;
            background: linear-gradient(to left, transparent, white);
            pointer-events: none;
            opacity: 0;
            transition: opacity 0.3s ease;
        }
        
        .tab-container.can-scroll-left::before {
            opacity: 1;
        }

        .tab-container::-webkit-scrollbar {
            height: 2px;
        }

        .tab-container::-webkit-scrollbar-thumb:hover {
            background: #94a3b8;
        }

        .tab-list {
            display: flex;
            align-items: center;
            gap: 2px;
            flex-wrap: nowrap;
            height: 28px;
            Margin-bottom: -1px;
        }

        .tab-item {
            display: inline-flex;
            align-items: center;
            gap: 4px;
            padding: 0 5px 0 5px;
            height: 18px;
            background: #f1f5f9;
            border-radius: 16px 16px 0 0;
            font-size: 0.7rem;
            color: #334155;
            cursor: pointer;
            transition: all 0.15s ease;
            border: 0px solid transparent;
            border-bottom: none;
            position: relative;
            flex: 0 0 auto;
            min-width: 70px;
            max-width: 250px;
            width: auto;
            box-shadow: 0 -1px 2px rgba(0,0,0,0.02);
            overflow: hidden;
        }

        .tab-item:hover {
            background: #e2e8f0;
            color: #0f172a;
            box-shadow: none;
        }

        .tab-item.active:hover {
            background: #f5f6fa;
            box-shadow: none;
            border-top: 4px solid var(--primary);
        }

        .tab-item.active {
            background: #f5f6fa;
            color: #0f172a;
            border-color: #e2e8f0;
            border-top: 3px solid var(--primary);
            font-weight: 600;
            height: 90px;
            Padding-bottom: 60px;
            margin-top: 68px;
            box-shadow: none; /* Hapus shadow background */
            overflow: hidden;
        }

        .tab-item.active::after {
            content: '';
            position: absolute;
            bottom: -2px;
            left: 0;
            right: 0;
            height: 3px;
            background: none;
            box-shadow: 1px 0 0px var(--primary); /* Efek glow hanya pada border */
            border-radius: 3px 3px 0 0;
            z-index: 999;

        }


        .tab-item:first-child {
            min-width: 100px;
        }

        .tab-item:first-child.active {
            border-left-color: #e2e8f0;
        }

        .tab-icon {
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 0.7rem;
            color: #64748b;
            flex-shrink: 0;
            width: 16px; /* Fixed width */
        }

        .tab-item.active .tab-icon {
            color: var(--primary);
        }


        .tab-content {
            flex: 1;
            overflow: hidden;
            text-overflow: ellipsis;
            white-space: nowrap;
            display: flex;
            align-items: center;
            gap: 4px;
            min-width: 30px; 
            max-width: calc(100% - 10px);
            padding-right: 20px;
        }

        .tab-parent {
            font-weight: 500;
            color: #475569;
            font-size: 0.65rem; 
            max-width: 60px; 
        }

        .tab-item.active .tab-parent,
        .tab-item.active .tab-child {
            color: #0f172a;
            font-weight: 600;
        }
        
        .tab-separator {
            display: flex;
            align-items: center;
            color: #94a3b8;
            font-size: 0.5rem;
            margin: 0 1px;
            flex-shrink: 0;
        }

        .tab-separator i {
            font-size: 0.6rem;
        }

        .tab-child {
            color: #64748b;
            font-size: 0.6rem; 
            max-width: 50px; 
        }

        .tab-item.active .tab-child {
            color: #475569;
        }

        .tab-close {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            width: 16px; 
            height: 16px;
            border-radius: 3px;
            font-size: 0.65rem;
            color: #94a3b8;
            cursor: pointer;
            transition: all 0.15s;
            margin-left: 0;
            flex-shrink: 0;
            opacity: 0.9;
            background: rgba(241, 245, 249, 0.9);
            border: none;
        }

        .tab-close:hover {
            background:rgba(248, 67, 67, 0.35);
            color: #1e293b;
            opacity: 1;
        }
        
        .tab-item.active .tab-close {
            opacity: 1;
            background: transparent;
        }

        .tab-item.active .tab-close:hover {
            background:rgba(248, 67, 67, 0.35);
            color: #1e293b;
            opacity: 1;
        }

        .new-tab-btn {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            width: 28px;
            height: 28px;
            border-radius: 6px;
            background: transparent;
            border: none;
            color: #64748b;
            font-size: 1rem;
            cursor: pointer;
            transition: all 0.15s;
            margin-left: 4px;
            flex-shrink: 0;
        }

        .new-tab-btn:hover {
            background: #e2e8f0;
            color: var(--primary);
        }

        .navbar-left {
            display: flex;
            align-items: flex-end;
            height: 62px;
            margin-left: -25px;
        }

        .navbar-left .page-title.hidden {
            display: none;
        }

        @media (max-width: 768px) {
            .tab-item {
                min-width: 120px;
                padding: 0 8px 0 12px;
                font-size: 0.75rem;
            }
            
            .tab-item:first-child {
                min-width: 80px;
            }
            
            .new-tab-btn {
                width: 24px;
                height: 24px;
            }
        }

        /* MAIN */
        #main-content {
            margin-left: var(--sidebar-width); margin-top: var(--navbar-height);
            padding: 26px; min-height: calc(100vh - var(--navbar-height));
            transition: margin-left var(--transition);
        }
        #main-content.collapsed { margin-left: var(--sidebar-collapsed-width); }

        .page { display: none; animation: fadeIn 0.25s ease; }
        .page.active { display: block; }
        @keyframes fadeIn { from { opacity:0; transform:translateY(5px); } to { opacity:1; transform:translateY(0); } }

        /* CARDS */
        .stat-card {
            background: white; border-radius: 14px; padding: 18px 20px;
            box-shadow: 0 2px 12px rgba(0,0,0,0.05);
            display: flex; align-items: center; gap: 14px;
            transition: transform 0.2s, box-shadow 0.2s; height: 100%;
        }
        .stat-card:hover { transform: translateY(-2px); box-shadow: 0 6px 20px rgba(0,0,0,0.09); }
        .stat-icon { width: 46px; height: 46px; border-radius: 12px; display: flex; align-items: center; justify-content: center; font-size: 1.2rem; flex-shrink: 0; }
        .stat-value { font-size: 1.45rem; font-weight: 700; color: #111827; line-height: 1; }
        .stat-label { font-size: 0.76rem; color: #6b7280; margin-top: 3px; }
        .stat-change { font-size: 0.71rem; margin-top: 3px; }

        .content-card { background: white; border-radius: 14px; padding: 20px; box-shadow: 0 2px 12px rgba(0,0,0,0.05); }
        .card-hdr {
            display: flex; align-items: center; justify-content: space-between;
            margin-bottom: 16px; padding-bottom: 12px; border-bottom: 1px solid #f0f0f0;
        }
        .card-hdr h5 { font-size: 0.9rem; font-weight: 600; color: #111827; margin: 0; }

        .page-heading { color: var(--primary-dark); font-weight: 700; font-size: 1.15rem; }
        .page-sub { font-size: 0.85rem; color: #6b7280; margin-top: 2px; }

        /* Todo items */
        .todo-item { display: flex; align-items: center; gap: 10px; padding: 9px 0; border-bottom: 1px solid #f5f5f5; }
        .todo-item:last-child { border-bottom: none; }
        .todo-dot { width: 9px; height: 9px; border-radius: 50%; flex-shrink: 0; }

        /* Badges */
        .bs { display: inline-flex; align-items: center; padding: 2px 9px; border-radius: 20px; font-size: 0.7rem; font-weight: 600; }
        .bs-green  { background: #f0fdf4; color: #16a34a; }
        .bs-yellow { background: #fffbeb; color: #d97706; }
        .bs-red    { background: #fef2f2; color: #dc2626; }
        .bs-gray   { background: #f1f5f9; color: #64748b; }
        .bs-indigo { background: #eef2ff; color: #4f46e5; }
        .bs-black  { background: #111827; color: white; }

        /* Table */
        .tbl thead th { font-size: 0.76rem; font-weight: 600; color: #6b7280; background: #f8f9fa; padding: 9px 12px; border-bottom: 1px solid #f0f0f0; }
        .tbl tbody td { font-size: 0.82rem; padding: 9px 12px; vertical-align: middle; }
        .tbl tbody tr:hover { background: #fafbff; }

        /* Progress */
        .prog { height: 7px; border-radius: 4px; background: #f0f0f0; overflow: hidden; }
        .prog-bar { height: 100%; border-radius: 4px; }

        /* Chart bars */
        .chart-wrap { display: flex; align-items: flex-end; gap: 6px; height: 110px; margin-bottom: 28px; }
        .chart-bar { flex: 1; border-radius: 5px 5px 0 0; background: linear-gradient(180deg, var(--primary-light), var(--primary)); opacity: 0.85; position: relative; transition: opacity 0.2s; }
        .chart-bar:hover { opacity: 1; }
        .bar-lbl { position: absolute; bottom: -20px; left: 50%; transform: translateX(-50%); font-size: 0.58rem; color: #9ca3af; white-space: nowrap; }

        /* Buttons */
        .btn-p { background: var(--primary); color: white; border: none; border-radius: 8px; padding: 7px 16px; font-size: 0.83rem; font-weight: 600; cursor: pointer; display: inline-flex; align-items: center; gap: 6px; transition: background 0.2s; }
        .btn-p:hover { background: #4338ca; }
        .btn-o { background: transparent; color: var(--primary); border: 1.5px solid var(--primary); border-radius: 8px; padding: 6px 13px; font-size: 0.8rem; font-weight: 500; cursor: pointer; display: inline-flex; align-items: center; gap: 5px; transition: all 0.2s; }
        .btn-o:hover { background: var(--primary-hover-bg); }
        .btn-d { background: transparent; color: #dc2626; border: 1.5px solid #dc2626; border-radius: 8px; padding: 5px 10px; font-size: 0.78rem; cursor: pointer; transition: all 0.2s; }
        .btn-d:hover { background: #fef2f2; }

        /* Form */
        .flbl { font-size: 0.82rem; font-weight: 600; color: #374151; margin-bottom: 5px; display: block; }
        .finp {
            border-radius: 8px; border: 1px solid #e5e7eb; padding: 8px 12px;
            font-size: 0.83rem; width: 100%; transition: border-color 0.2s;
            font-family: inherit; background: white;
        }
        .finp:focus { border-color: var(--primary); outline: none; box-shadow: 0 0 0 3px rgba(79,70,229,0.08); }

        /* Dropdown */
        #userDropdownWrapper { position: relative; }
        .udm {
            display: none; position: absolute; top: calc(100% + 8px); right: 0;
            background: white; border-radius: 12px; box-shadow: 0 8px 24px rgba(0,0,0,0.12);
            min-width: 210px; padding: 6px; list-style: none; margin: 0; z-index: 9999;
        }
        .udm.show { display: block; animation: dmIn 0.15s ease; }
        @keyframes dmIn { from { opacity:0; transform:translateY(-5px); } to { opacity:1; transform:translateY(0); } }
        .udm-hdr { padding: 9px 14px; border-bottom: 1px solid #f0f0f0; margin-bottom: 4px; }
        .dl {
            display: flex; align-items: center; gap: 10px; padding: 8px 14px;
            font-size: 0.84rem; color: #374151; text-decoration: none; border-radius: 8px; transition: background 0.15s;
        }
        .dl:hover { background: #f5f6fa; color: #111827; }
        .dl.dng { color: #dc2626; }
        .dl.dng:hover { background: #fef2f2; }
        .ddiv { border-top: 1px solid #f0f0f0; margin: 4px 0; }
        #chevronIcon { transition: transform 0.2s; font-size: 0.65rem; color: #9ca3af; }
        #chevronIcon.rotated { transform: rotate(180deg); }

        /* Modal */
        .modal-overlay { display: none; position: fixed; inset: 0; background: rgba(0,0,0,0.4); z-index: 9999; align-items: center; justify-content: center; }
        .modal-box { background: white; border-radius: 16px; padding: 26px; width: 380px; box-shadow: 0 20px 60px rgba(0,0,0,0.18); }

        @media print {
            #sidebar, #navbar, .no-print { display: none !important; }
            #main-content { margin: 0 !important; padding: 20px !important; }
        }
        @media (max-width: 768px) {
            #sidebar { width: var(--sidebar-collapsed-width); }
            #navbar { left: var(--sidebar-collapsed-width); }
            #main-content { margin-left: var(--sidebar-collapsed-width); }
            .tab-container { max-width: calc(100vw - 200px); }
            .tab-item { padding: 4px 8px; font-size: 0.75rem; }
        }
        
        /* Animations for scroll tooltip */
        @keyframes fadeInUp {
            from {
                opacity: 0;
                transform: translate(-50%, 10px);
            }
            to {
                opacity: 1;
                transform: translate(-50%, 0);
            }
        }
        
        @keyframes fadeOut {
            from {
                opacity: 1;
                transform: translate(-50%, 0);
            }
            to {
                opacity: 0;
                transform: translate(-50%, -10px);
            }
        }
    </style>
</head>
<body>

<!-- SIDEBAR -->
<div id="sidebar">
    <div class="sidebar-logo">
        <div class="logo-icon"><img src="assets/images/apple-touch-icon.png" alt="Logo"></div>
        <span class="divider">|</span>
        <span class="brand">Buyer Efficiency<br>System Tools</span>
    </div>

    <nav class="sidebar-nav">
        <div class="nav-label">MAIN MENU</div>

        <a class="nav-item-link active" href="#" data-page="home" onclick="return navigateToPage(this)">
            <i class="bi bi-house-fill nav-icon"></i><span class="nav-text">Home</span>
        </a>

        <!-- Attendance -->
        <div class="nav-item">
            <a class="nav-item-link has-sub" onclick="toggleSub(this)">
                <i class="bi bi-calendar-check-fill nav-icon"></i>
                <span class="nav-text">Attendance</span>
                <i class="bi bi-chevron-right nav-arrow"></i>
            </a>
            <div class="nav-submenu">
                <a class="nav-sub-link" href="#" data-page="att-db" onclick="return navigateToPage(this)"><i class="bi bi-bar-chart"></i> Dashboard</a>
                <a class="nav-sub-link" href="#" data-page="att-list" onclick="return navigateToPage(this)"><i class="bi bi-list-ul"></i> Data Absensi</a>
            </div>
        </div>

        <!-- Overtime -->
        <div class="nav-item">
            <a class="nav-item-link has-sub" onclick="toggleSub(this)">
                <i class="bi bi-clock-history nav-icon"></i>
                <span class="nav-text">Overtime</span>
                <i class="bi bi-chevron-right nav-arrow"></i>
            </a>
            <div class="nav-submenu">
                <a class="nav-sub-link" href="#" data-page="ot-db" onclick="return navigateToPage(this)"><i class="bi bi-bar-chart"></i> Dashboard</a>
                <a class="nav-sub-link" href="#" data-page="ot-form" onclick="return navigateToPage(this)"><i class="bi bi-pencil-square"></i> Form Pengajuan</a>
                <a class="nav-sub-link" href="#" data-page="ot-budget" onclick="return navigateToPage(this)"><i class="bi bi-wallet2"></i> Budget Overtime</a>
            </div>
        </div>

        <!-- Expense -->
        <div class="nav-item">
            <a class="nav-item-link has-sub" onclick="toggleSub(this)">
                <i class="bi bi-wallet2 nav-icon"></i>
                <span class="nav-text">Expense</span>
                <i class="bi bi-chevron-right nav-arrow"></i>
            </a>
            <div class="nav-submenu">
                <a class="nav-sub-link" href="#" data-page="exp-db" onclick="return navigateToPage(this)"><i class="bi bi-bar-chart"></i> Dashboard</a>
                <a class="nav-sub-link" href="#" data-page="exp-list" onclick="return navigateToPage(this)"><i class="bi bi-tags"></i> Kategori & Detail</a>
            </div>
        </div>

        <!-- Skillmap -->
        <div class="nav-item">
            <a class="nav-item-link has-sub" onclick="toggleSub(this)">
                <i class="bi bi-diagram-3-fill nav-icon"></i>
                <span class="nav-text">Skillmap</span>
                <i class="bi bi-chevron-right nav-arrow"></i>
            </a>
            <div class="nav-submenu">
                <a class="nav-sub-link" href="#" data-page="sk-db" onclick="return navigateToPage(this)"><i class="bi bi-bar-chart"></i> Dashboard</a>
                <a class="nav-sub-link" href="#" data-page="sk-list" onclick="return navigateToPage(this)"><i class="bi bi-list-stars"></i> Data Skill</a>
            </div>
        </div>

        <!-- Drawing -->
        <div class="nav-item">
            <a class="nav-item-link has-sub" onclick="toggleSub(this)">
                <i class="bi bi-file-earmark-ruled-fill nav-icon"></i>
                <span class="nav-text">Drawing</span>
                <i class="bi bi-chevron-right nav-arrow"></i>
            </a>
            <div class="nav-submenu">
                <a class="nav-sub-link" href="#" data-page="drw-db" onclick="return navigateToPage(this)"><i class="bi bi-bar-chart"></i> Dashboard</a>
                <a class="nav-sub-link" href="#" data-page="drw-list" onclick="return navigateToPage(this)"><i class="bi bi-table"></i> Data Drawing</a>
                <a class="nav-sub-link" href="#" data-page="drw-receipt" onclick="return navigateToPage(this)"><i class="bi bi-printer"></i> Form Tanda Terima</a>
            </div>
        </div>

        <!-- Quotation -->
        <div class="nav-item">
            <a class="nav-item-link has-sub" onclick="toggleSub(this)">
                <i class="bi bi-file-earmark-text-fill nav-icon"></i>
                <span class="nav-text">Quotation</span>
                <i class="bi bi-chevron-right nav-arrow"></i>
            </a>
            <div class="nav-submenu">
                <a class="nav-sub-link" href="#" data-page="quo-db" onclick="return navigateToPage(this)"><i class="bi bi-bar-chart"></i> Dashboard</a>
                <a class="nav-sub-link" href="#" data-page="quo-list" onclick="return navigateToPage(this)"><i class="bi bi-list-ul"></i> Data Quotation</a>
            </div>
        </div>

        <!-- Inventory ATK -->
        <div class="nav-item">
            <a class="nav-item-link has-sub" onclick="toggleSub(this)">
                <i class="bi bi-box-seam-fill nav-icon"></i>
                <span class="nav-text">Inventory ATK</span>
                <i class="bi bi-chevron-right nav-arrow"></i>
            </a>
            <div class="nav-submenu">
                <a class="nav-sub-link" href="#" data-page="inv-db" onclick="return navigateToPage(this)"><i class="bi bi-bar-chart"></i> Dashboard Stock</a>
                <a class="nav-sub-link" href="#" data-page="inv-io" onclick="return navigateToPage(this)"><i class="bi bi-arrow-left-right"></i> Barang Masuk/Keluar</a>
                <a class="nav-sub-link" href="#" data-page="inv-low" onclick="return navigateToPage(this)"><i class="bi bi-exclamation-triangle"></i> Stock Menipis</a>
            </div>
        </div>

        <div class="nav-label">SISTEM</div>
        <a class="nav-item-link" href="#" data-page="settings" onclick="return navigateToPage(this)">
            <i class="bi bi-gear-fill nav-icon"></i><span class="nav-text">Pengaturan</span>
        </a>
        <a class="nav-item-link" href="/best-root/public/logout">
            <i class="bi bi-box-arrow-left nav-icon"></i><span class="nav-text">Logout</span>
        </a>
    </nav>

    <div class="sidebar-footer">
        <div class="footer-copy">
            &copy; <img src="/best-root/public/assets/images/apple-touch-icon.png" alt="BEST"> <?= date('Y') ?> Buyer Efficiency System Tools
        </div>
    </div>
</div>

<!-- NAVBAR -->
<div id="navbar">
    <div class="navbar-left">
        <button id="toggleSidebar" onclick="toggleSidebar()">
            <i id="toggleIcon" class="bi bi-chevron-compact-left"></i>
        </button>
        <span class="page-title" id="pageTitle">Home</span>
        <!-- TAB CONTAINER - dengan scrollbar di atas -->
        <div class="tab-container">
            <div class="tab-list" id="tabList">
                <!-- Tabs akan ditambahkan via JavaScript -->
            </div>
        </div>
    </div>
    <div class="navbar-right">
        <button class="btn-notif"><i class="bi bi-bell"></i><span class="notif-badge"></span></button>
        <div class="nav-divider"></div>
        <div id="userDropdownWrapper">
            <button class="user-dropdown" type="button" onclick="toggleUD()">
                <div class="avatar-sm"><?= strtoupper(substr($name,0,1)) ?></div>
                <div class="user-info">
                    <div class="user-name-nav"><?= htmlspecialchars($name) ?></div>
                    <div class="user-role-nav"><?= htmlspecialchars($role) ?></div>
                </div>
                <i class="bi bi-chevron-down" id="chevronIcon"></i>
            </button>
            <ul class="udm" id="userDropdownMenu">
                <li class="udm-hdr">
                    <div style="font-size:0.82rem;font-weight:600;color:#111827;"><?= htmlspecialchars($name) ?></div>
                    <div style="font-size:0.74rem;color:#9ca3af;"><?= htmlspecialchars($npk) ?> &middot; <?= htmlspecialchars($role) ?></div>
                </li>
                <li><a class="dl" href="#" onclick="showPage('settings',null);closeUD();"><i class="bi bi-person" style="color:#4f46e5;"></i> Profil Saya</a></li>
                <li><a class="dl" href="#"><i class="bi bi-bell" style="color:#4f46e5;"></i> Notifikasi</a></li>
                <li class="ddiv"></li>
                <li><a class="dl dng" href="/best-root/public/logout"><i class="bi bi-box-arrow-left"></i> Logout</a></li>
            </ul>
        </div>
    </div>
</div>

<!-- MAIN CONTENT -->
<div id="main-content">

<!-- ======== HOME ======== -->
<div class="page" id="page-home">
    <div class="mb-4">
        <div class="page-heading">Selamat Datang, <?= htmlspecialchars($name) ?>! 👋</div>
        <div class="page-sub">Ringkasan aktivitas sistem hari ini.</div>
    </div>
    <div class="row g-3 mb-4">
        <?php $hcards=[['Pending','8','bi-hourglass-split','#4f46e5','#eef2ff','Menunggu approval','text-warning'],['Approved','13','bi-check2-circle','#16a34a','#f0fdf4','+5 bulan ini','text-success'],['Overdue','3','bi-exclamation-triangle-fill','#dc2626','#fef2f2','Perlu perhatian','text-danger'],['Total Task','24','bi-list-task','#d97706','#fffbeb','+12% bulan ini','text-success']];
        foreach($hcards as $c): ?>
        <div class="col-6 col-xl-3">
            <div class="stat-card">
                <div class="stat-icon" style="background:<?= $c[4] ?>;"><i class="bi <?= $c[2] ?>" style="color:<?= $c[3] ?>;"></i></div>
                <div>
                    <div class="stat-value"><?= $c[1] ?></div>
                    <div class="stat-label"><?= $c[0] ?></div>
                    <div class="stat-change <?= $c[6] ?>"><?= $c[5] ?></div>
                </div>
            </div>
        </div>
        <?php endforeach; ?>
    </div>
    <div class="row g-3">
        <!-- Todo -->
        <div class="col-12 col-lg-4">
            <div class="content-card h-100">
                <div class="card-hdr">
                    <h5><i class="bi bi-check2-square me-2" style="color:#4f46e5;"></i>Todo List</h5>
                    <button class="btn-o" style="padding:3px 9px;font-size:0.73rem;"><i class="bi bi-plus"></i> Tambah</button>
                </div>
                <?php $todos=[['Review PO #2024-010',false,'#4f46e5'],['Follow up vendor PT. Maju Jaya',false,'#d97706'],['Upload expense Januari',true,'#16a34a'],['Approve overtime Budi S.',false,'#dc2626'],['Update skillmap Q1',true,'#16a34a']];
                foreach($todos as $t): ?>
                <div class="todo-item">
                    <div class="todo-dot" style="background:<?= $t[2] ?>;"></div>
                    <span style="font-size:0.82rem;color:<?= $t[1]?'#9ca3af':'#374151' ?>;text-decoration:<?= $t[1]?'line-through':'none' ?>;"><?= $t[0] ?></span>
                </div>
                <?php endforeach; ?>
            </div>
        </div>
        <!-- Pending List -->
        <div class="col-12 col-lg-4">
            <div class="content-card h-100">
                <div class="card-hdr">
                    <h5><i class="bi bi-hourglass me-2" style="color:#d97706;"></i>Pending List</h5>
                    <span class="bs bs-yellow">8 Item</span>
                </div>
                <?php $pends=[['PO-2024-008','Purchase Order','Ahmad F.'],['OT-2024-012','Overtime','Siti R.'],['EXP-2024-005','Expense','Budi S.'],['QUO-2024-003','Quotation','Dewi A.']];
                foreach($pends as $p): ?>
                <div class="todo-item">
                    <div style="flex:1;">
                        <div style="font-size:0.81rem;font-weight:600;color:#374151;"><?= $p[0] ?></div>
                        <div style="font-size:0.71rem;color:#9ca3af;"><?= $p[1] ?> &bull; <?= $p[2] ?></div>
                    </div>
                    <span class="bs bs-yellow">Pending</span>
                </div>
                <?php endforeach; ?>
            </div>
        </div>
        <!-- Aktivitas + Status -->
        <div class="col-12 col-lg-4">
            <div class="content-card mb-3">
                <div class="card-hdr"><h5><i class="bi bi-clock-history me-2" style="color:#818cf8;"></i>Aktivitas Terbaru</h5></div>
                <?php $acts=[['bi-cart-check','#16a34a','PO #2024-007 disetujui','5 mnt lalu'],['bi-person-plus','#4f46e5','Vendor baru: CV. Abadi','1 jam lalu'],['bi-exclamation-circle','#dc2626','PO #2024-005 overdue','2 jam lalu']];
                foreach($acts as $a): ?>
                <div class="todo-item">
                    <div style="width:28px;height:28px;background:<?= $a[1] ?>18;border-radius:8px;display:flex;align-items:center;justify-content:center;flex-shrink:0;"><i class="bi <?= $a[0] ?>" style="color:<?= $a[1] ?>;font-size:0.82rem;"></i></div>
                    <div style="flex:1;"><div style="font-size:0.79rem;color:#374151;"><?= $a[2] ?></div><div style="font-size:0.68rem;color:#aaa;"><?= $a[3] ?></div></div>
                </div>
                <?php endforeach; ?>
            </div>
            <div class="content-card">
                <div class="card-hdr"><h5><i class="bi bi-pie-chart-fill me-2" style="color:#818cf8;"></i>Status</h5></div>
                <?php $sts=[['Approved',13,24,'#16a34a'],['Pending',8,24,'#d97706'],['Overdue',3,24,'#dc2626']];
                foreach($sts as $s): $p=round($s[1]/$s[2]*100); ?>
                <div class="mb-2">
                    <div class="d-flex justify-content-between mb-1">
                        <span style="font-size:0.76rem;color:#555;"><?= $s[0] ?></span>
                        <span style="font-size:0.76rem;font-weight:600;color:<?= $s[3] ?>;"><?= $s[1] ?> (<?= $p ?>%)</span>
                    </div>
                    <div class="prog"><div class="prog-bar" style="width:<?= $p ?>%;background:<?= $s[3] ?>;"></div></div>
                </div>
                <?php endforeach; ?>
            </div>
        </div>
    </div>
</div>

<!-- ======== ATTENDANCE DASHBOARD ======== -->
<div class="page" id="page-att-db">
    <div class="mb-4"><div class="page-heading">Attendance — Dashboard</div><div class="page-sub">Ringkasan kehadiran karyawan</div></div>
    <div class="row g-3 mb-4">
        <?php $ac=[['Hadir Hari Ini',42,'bi-person-check-fill','#4f46e5','#eef2ff'],['Terlambat',5,'bi-alarm-fill','#d97706','#fffbeb'],['Absen',3,'bi-person-x-fill','#dc2626','#fef2f2'],['Izin/Sakit',2,'bi-file-medical','#7c3aed','#f5f3ff']];
        foreach($ac as $c): ?>
        <div class="col-6 col-xl-3">
            <div class="stat-card">
                <div class="stat-icon" style="background:<?= $c[4] ?>;"><i class="bi <?= $c[2] ?>" style="color:<?= $c[3] ?>;"></i></div>
                <div><div class="stat-value"><?= $c[1] ?></div><div class="stat-label"><?= $c[0] ?></div></div>
            </div>
        </div>
        <?php endforeach; ?>
    </div>
    <div class="content-card">
        <div class="card-hdr"><h5><i class="bi bi-bar-chart me-2" style="color:#818cf8;"></i>Grafik Kehadiran Bulanan (%)</h5></div>
        <div class="chart-wrap">
            <?php $months=['Jan','Feb','Mar','Apr','Mei','Jun','Jul','Ags','Sep','Okt','Nov','Des'];
            $vals=[88,91,85,93,90,87,94,89,92,86,90,88];
            foreach($months as $i=>$m): ?>
            <div class="chart-bar" style="height:<?= $vals[$i] ?>%;"><span class="bar-lbl"><?= $m ?></span></div>
            <?php endforeach; ?>
        </div>
    </div>
</div>

<!-- ======== ATTENDANCE LIST ======== -->
<div class="page" id="page-att-list">
    <div class="mb-4 d-flex justify-content-between align-items-start flex-wrap gap-2">
        <div><div class="page-heading">Attendance — Data Absensi</div><div class="page-sub">Daftar kehadiran karyawan</div></div>
        <div class="d-flex gap-2 no-print">
            <input type="month" class="finp" style="width:auto;" value="<?= date('Y-m') ?>">
            <button class="btn-p"><i class="bi bi-download"></i> Export</button>
        </div>
    </div>
    <div class="content-card">
        <div class="card-hdr">
            <h5><i class="bi bi-table me-2" style="color:#818cf8;"></i>Data Absensi</h5>
            <input type="text" class="finp" placeholder="Cari nama..." style="width:170px;">
        </div>
        <div class="table-responsive">
            <table class="table tbl align-middle">
                <thead><tr><th>NPK</th><th>Nama</th><th>Tanggal</th><th>Jam Masuk</th><th>Jam Keluar</th><th>Status</th></tr></thead>
                <tbody>
                    <?php $ar=[['XJ001','Muhammad Nurkholiq Akbar','22 Feb 2025','08:00','17:05','Hadir'],['XJ002','Panji Nur Cahyo','22 Feb 2025','08:15','17:00','Terlambat'],['XJ003','Amirullah Wisnu Nugroho','22 Feb 2025','-','-','Absen'],['XJ004','Klaudius Haryo Avellino Kurniawan','22 Feb 2025','07:55','17:10','Hadir']];
                    $ab=['Hadir'=>'bs-green','Terlambat'=>'bs-yellow','Absen'=>'bs-red'];
                    foreach($ar as $r): ?>
                    <tr><td><?= $r[0] ?></td><td><strong><?= $r[1] ?></strong></td><td><?= $r[2] ?></td><td><?= $r[3] ?></td><td><?= $r[4] ?></td><td><span class="bs <?= $ab[$r[5]] ?>"><?= $r[5] ?></span></td></tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<!-- ======== OVERTIME DASHBOARD ======== -->
<div class="page" id="page-ot-db">
    <div class="mb-4"><div class="page-heading">Overtime — Dashboard</div><div class="page-sub">Ringkasan pengajuan lembur</div></div>
    <div class="row g-3 mb-4">
        <?php $oc=[['Total Pengajuan',18,'bi-clock-fill','#4f46e5','#eef2ff'],['Disetujui',12,'bi-check-circle-fill','#16a34a','#f0fdf4'],['Pending',4,'bi-hourglass-split','#d97706','#fffbeb'],['Ditolak',2,'bi-x-circle-fill','#dc2626','#fef2f2']];
        foreach($oc as $c): ?>
        <div class="col-6 col-xl-3">
            <div class="stat-card">
                <div class="stat-icon" style="background:<?= $c[4] ?>;"><i class="bi <?= $c[2] ?>" style="color:<?= $c[3] ?>;"></i></div>
                <div><div class="stat-value"><?= $c[1] ?></div><div class="stat-label"><?= $c[0] ?></div></div>
            </div>
        </div>
        <?php endforeach; ?>
    </div>
    <div class="content-card">
        <div class="card-hdr"><h5><i class="bi bi-table me-2" style="color:#818cf8;"></i>Riwayat Overtime</h5></div>
        <div class="table-responsive">
            <table class="table tbl align-middle">
                <thead><tr><th>No</th><th>Nama</th><th>Tanggal</th><th>Durasi</th><th>Alasan</th><th>Status</th></tr></thead>
                <tbody>
                    <tr><td>OT-001</td><td><strong>Muhammad Nurkholiq Akbar</strong></td><td>20 Feb 2025</td><td>2 jam</td><td>Deadline PO</td><td><span class="bs bs-green">Disetujui</span></td></tr>
                    <tr><td>OT-002</td><td><strong>Panji Nur Cahyo</strong></td><td>21 Feb 2025</td><td>3 jam</td><td>Laporan bulanan</td><td><span class="bs bs-yellow">Pending</span></td></tr>
                    <tr><td>OT-003</td><td><strong>Amirullah Wisnu Nugroho</strong></td><td>22 Feb 2025</td><td>1 jam</td><td>Meeting vendor</td><td><span class="bs bs-red">Ditolak</span></td></tr>
                </tbody>
            </table>
        </div>
    </div>
</div>

<!-- ======== OVERTIME BUDGET ======== -->
<?php include BASE_PATH . '/app/views/overtime/budgetovertime.php'; ?>

<!-- ======== OVERTIME FORM ======== -->
<?php include BASE_PATH . '/app/views/overtime/formpengajuanot.php'; ?>

<!-- ======== EXPENSE DASHBOARD ======== -->
<div class="page" id="page-exp-db">
    <div class="mb-4"><div class="page-heading">Expense — Dashboard</div><div class="page-sub">Ringkasan pengeluaran</div></div>
    <div class="row g-3 mb-4">
        <?php $ec=[['Total Expense','Rp 12,4 jt','bi-cash-stack','#4f46e5','#eef2ff'],['Bulan Ini','Rp 3,2 jt','bi-calendar-month','#16a34a','#f0fdf4'],['Pending Approval','5','bi-hourglass','#d97706','#fffbeb'],['Kategori Aktif','6','bi-tags','#7c3aed','#f5f3ff']];
        foreach($ec as $c): ?>
        <div class="col-6 col-xl-3">
            <div class="stat-card">
                <div class="stat-icon" style="background:<?= $c[4] ?>;"><i class="bi <?= $c[2] ?>" style="color:<?= $c[3] ?>;"></i></div>
                <div><div class="stat-value" style="font-size:1.1rem;"><?= $c[1] ?></div><div class="stat-label"><?= $c[0] ?></div></div>
            </div>
        </div>
        <?php endforeach; ?>
    </div>
    <div class="content-card">
        <div class="card-hdr"><h5><i class="bi bi-bar-chart me-2" style="color:#818cf8;"></i>Pengeluaran per Kategori</h5></div>
        <div class="row g-3 mt-1">
            <?php $cats=[['Transport','Rp 2.100.000','#4f46e5',65],['Makan','Rp 890.000','#16a34a',28],['ATK','Rp 450.000','#d97706',14],['Lainnya','Rp 320.000','#7c3aed',10]];
            foreach($cats as $cat): ?>
            <div class="col-6 col-md-3">
                <div style="padding:12px;border-radius:10px;background:#f8f9fa;text-align:center;">
                    <div style="font-size:0.75rem;color:#6b7280;"><?= $cat[0] ?></div>
                    <div style="font-size:0.92rem;font-weight:700;color:#111827;margin:4px 0;"><?= $cat[1] ?></div>
                    <div class="prog"><div class="prog-bar" style="width:<?= $cat[3] ?>%;background:<?= $cat[2] ?>;"></div></div>
                </div>
            </div>
            <?php endforeach; ?>
        </div>
    </div>
</div>

<!-- ======== EXPENSE LIST ======== -->
<div class="page" id="page-exp-list">
    <div class="mb-4 d-flex justify-content-between align-items-center">
        <div><div class="page-heading">Expense — Kategori & Detail</div><div class="page-sub">Kelola kategori dan item pengeluaran</div></div>
        <button class="btn-p" onclick="document.getElementById('modalCat').style.display='flex'"><i class="bi bi-plus"></i> Tambah Kategori</button>
    </div>
    <div class="row g-3">
        <?php $expCats=[
            ['Transport','bi-car-front-fill','#4f46e5',[['Bensin','Rp 150.000'],['Tol','Rp 45.000'],['Parkir','Rp 20.000']]],
            ['Konsumsi','bi-cup-hot-fill','#16a34a',[['Makan siang','Rp 75.000'],['Snack meeting','Rp 120.000']]],
            ['ATK','bi-pencil-fill','#d97706',[['Kertas A4','Rp 85.000'],['Tinta printer','Rp 200.000']]],
        ];
        foreach($expCats as $cat): ?>
        <div class="col-12 col-md-4">
            <div class="content-card h-100">
                <div class="card-hdr">
                    <h5><i class="bi <?= $cat[1] ?> me-2" style="color:<?= $cat[2] ?>;"></i><?= $cat[0] ?></h5>
                    <div class="d-flex gap-1">
                        <button class="btn-o" style="padding:3px 8px;font-size:0.7rem;"><i class="bi bi-plus"></i> Item</button>
                        <button class="btn-d" style="padding:3px 7px;font-size:0.7rem;"><i class="bi bi-trash"></i></button>
                    </div>
                </div>
                <?php foreach($cat[3] as $item): ?>
                <div class="todo-item">
                    <div style="flex:1;font-size:0.81rem;color:#374151;"><?= $item[0] ?></div>
                    <div style="font-size:0.81rem;font-weight:600;color:#111827;"><?= $item[1] ?></div>
                    <button class="btn-d" style="padding:2px 6px;font-size:0.68rem;margin-left:5px;"><i class="bi bi-x"></i></button>
                </div>
                <?php endforeach; ?>
            </div>
        </div>
        <?php endforeach; ?>
    </div>
    <div class="modal-overlay" id="modalCat">
        <div class="modal-box">
            <h6 style="font-weight:700;margin-bottom:16px;">Tambah Kategori Expense</h6>
            <label class="flbl">Nama Kategori</label>
            <input type="text" class="finp mb-3" placeholder="e.g. Transport">
            <div class="d-flex gap-2 justify-content-end">
                <button class="btn-o" onclick="document.getElementById('modalCat').style.display='none'">Batal</button>
                <button class="btn-p">Simpan</button>
            </div>
        </div>
    </div>
</div>

<!-- ======== SKILLMAP DASHBOARD ======== -->
<div class="page" id="page-sk-db">
    <div class="mb-4"><div class="page-heading">Skillmap — Dashboard</div><div class="page-sub">Peta kompetensi karyawan</div></div>
    <div class="row g-3 mb-4">
        <?php $skc=[['Total Karyawan',52,'bi-people-fill','#4f46e5','#eef2ff'],['Skill Terdaftar',18,'bi-diagram-3','#16a34a','#f0fdf4'],['Avg Kompetensi','3.4','bi-star-fill','#d97706','#fffbeb'],['Perlu Pelatihan',7,'bi-mortarboard-fill','#dc2626','#fef2f2']];
        foreach($skc as $c): ?>
        <div class="col-6 col-xl-3">
            <div class="stat-card">
                <div class="stat-icon" style="background:<?= $c[4] ?>;"><i class="bi <?= $c[2] ?>" style="color:<?= $c[3] ?>;"></i></div>
                <div><div class="stat-value"><?= $c[1] ?></div><div class="stat-label"><?= $c[0] ?></div></div>
            </div>
        </div>
        <?php endforeach; ?>
    </div>
    <div class="content-card">
        <div class="card-hdr"><h5><i class="bi bi-bar-chart-fill me-2" style="color:#818cf8;"></i>Level Kompetensi per Skill</h5></div>
        <div class="row g-3 mt-1">
            <?php $skills=[['Negotiation',4.2,'#4f46e5'],['Excel/Data',3.8,'#16a34a'],['SRM',3.5,'#d97706'],['Leadership',2.9,'#7c3aed'],['Communication',4.0,'#16a34a'],['Procurement',3.7,'#4f46e5']];
            foreach($skills as $s): ?>
            <div class="col-12 col-md-6">
                <div class="d-flex align-items-center gap-3">
                    <div style="width:120px;font-size:0.78rem;color:#374151;flex-shrink:0;"><?= $s[0] ?></div>
                    <div style="flex:1;"><div class="prog"><div class="prog-bar" style="width:<?= ($s[1]/5)*100 ?>%;background:<?= $s[2] ?>;"></div></div></div>
                    <div style="width:30px;font-size:0.8rem;font-weight:700;color:<?= $s[2] ?>;text-align:right;"><?= $s[1] ?></div>
                </div>
            </div>
            <?php endforeach; ?>
        </div>
    </div>
</div>

<!-- ======== SKILLMAP LIST ======== -->
<div class="page" id="page-sk-list">
    <div class="mb-4 d-flex justify-content-between align-items-center">
        <div><div class="page-heading">Skillmap — Data Skill</div><div class="page-sub">Daftar nama dan nilai kompetensi karyawan</div></div>
        <button class="btn-p"><i class="bi bi-plus"></i> Tambah Data</button>
    </div>
    <div class="content-card">
        <div class="card-hdr">
            <h5><i class="bi bi-list-stars me-2" style="color:#818cf8;"></i>Data Skillmap</h5>
            <input type="text" class="finp" placeholder="Cari nama..." style="width:170px;">
        </div>
        <div class="table-responsive">
            <table class="table tbl align-middle">
                <thead><tr><th>NPK</th><th>Nama</th><th>Divisi</th><th>Skill Utama</th><th>Level</th><th>Score</th><th>Aksi</th></tr></thead>
                <tbody>
                    <?php $srows=[['XJ001','Muhammad Nurkholiq Akbar','Procurement','Negotiation',4,4.2],['XJ002','Panji Nur Cahyo','HR','Leadership',3,3.5],['XJ003','Amirullah Wisnu Nugroho','Finance','Excel/Data',4,3.8],['XJ004','Klaudius Haryo Avellino Kurniawan','Procurement','SRM',3,3.5]];
                    foreach($srows as $r): $stars=str_repeat('★',$r[4]).str_repeat('☆',5-$r[4]); ?>
                    <tr>
                        <td><?= $r[0] ?></td><td><strong><?= $r[1] ?></strong></td><td><?= $r[2] ?></td><td><?= $r[3] ?></td>
                        <td style="color:#d97706;"><?= $stars ?></td>
                        <td><span style="font-weight:700;color:#4f46e5;"><?= $r[5] ?>/5.0</span></td>
                        <td>
                            <button class="btn-o" style="padding:3px 9px;font-size:0.71rem;">Edit</button>
                            <button class="btn-d" style="padding:3px 7px;font-size:0.71rem;margin-left:3px;"><i class="bi bi-trash"></i></button>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<!-- ======== DRAWING DASHBOARD ======== -->
<div class="page" id="page-drw-db">
    <div class="mb-4"><div class="page-heading">Drawing — Dashboard</div><div class="page-sub">Distribusi drawing ke supplier</div></div>
    <div class="row g-3 mb-4">
        <?php $dc=[['Total Drawing',84,'bi-file-earmark-ruled','#4f46e5','#eef2ff'],['Sudah Dikirim',61,'bi-send-check','#16a34a','#f0fdf4'],['Belum Dikirim',15,'bi-send-exclamation','#d97706','#fffbeb'],['Supplier Aktif',12,'bi-building','#7c3aed','#f5f3ff']];
        foreach($dc as $c): ?>
        <div class="col-6 col-xl-3">
            <div class="stat-card">
                <div class="stat-icon" style="background:<?= $c[4] ?>;"><i class="bi <?= $c[2] ?>" style="color:<?= $c[3] ?>;"></i></div>
                <div><div class="stat-value"><?= $c[1] ?></div><div class="stat-label"><?= $c[0] ?></div></div>
            </div>
        </div>
        <?php endforeach; ?>
    </div>
    <div class="content-card">
        <div class="card-hdr"><h5><i class="bi bi-building me-2" style="color:#818cf8;"></i>Distribusi per Supplier</h5></div>
        <div class="d-flex flex-column gap-3 mt-1">
            <?php $sups=[['PT. Maju Jaya',18,'#4f46e5'],['CV. Sukses Makmur',12,'#16a34a'],['PT. Karya Mandiri',9,'#d97706'],['CV. Prima Teknik',7,'#7c3aed'],['PT. Global Mitra',6,'#dc2626']];
            foreach($sups as $s): ?>
            <div class="d-flex align-items-center gap-3">
                <div style="width:160px;font-size:0.79rem;color:#374151;flex-shrink:0;"><?= $s[0] ?></div>
                <div style="flex:1;"><div class="prog"><div class="prog-bar" style="width:<?= ($s[1]/20)*100 ?>%;background:<?= $s[2] ?>;"></div></div></div>
                <div style="width:24px;font-size:0.79rem;font-weight:700;color:<?= $s[2] ?>;text-align:right;"><?= $s[1] ?></div>
            </div>
            <?php endforeach; ?>
        </div>
    </div>
</div>

<!-- ======== DRAWING LIST ======== -->
<div class="page" id="page-drw-list">
    <div class="mb-4 d-flex justify-content-between align-items-center">
        <div><div class="page-heading">Drawing — Data Drawing</div><div class="page-sub">Kelola data drawing distribusi ke supplier</div></div>
        <button class="btn-p"><i class="bi bi-plus"></i> Tambah Drawing</button>
    </div>
    <div class="content-card">
        <div class="card-hdr">
            <h5><i class="bi bi-table me-2" style="color:#818cf8;"></i>Daftar Drawing</h5>
            <input type="text" class="finp" placeholder="Cari nomor drawing..." style="width:190px;">
        </div>
        <div class="table-responsive">
            <table class="table tbl align-middle">
                <thead><tr><th>No. Drawing</th><th>Nama Part</th><th>Supplier</th><th>Tgl Kirim</th><th>Revisi</th><th>Status</th><th>Aksi</th></tr></thead>
                <tbody>
                    <?php $dr=[['DRW-001','Cover Housing','PT. Maju Jaya','10 Jan 2025','Rev.2','Dikirim'],['DRW-002','Bracket Assy','CV. Sukses Makmur','12 Jan 2025','Rev.1','Dikirim'],['DRW-003','Shaft Pin','PT. Karya Mandiri','-','-','Belum'],['DRW-004','Base Plate','CV. Prima Teknik','15 Feb 2025','Rev.3','Dikirim']];
                    $ds=['Dikirim'=>'bs-green','Belum'=>'bs-yellow'];
                    foreach($dr as $r): ?>
                    <tr>
                        <td><strong><?= $r[0] ?></strong></td><td><?= $r[1] ?></td><td><?= $r[2] ?></td><td><?= $r[3] ?></td><td><?= $r[4] ?></td>
                        <td><span class="bs <?= $ds[$r[5]] ?>"><?= $r[5] ?></span></td>
                        <td>
                            <button class="btn-o" style="padding:3px 9px;font-size:0.71rem;" onclick="showPage('drw-receipt',null)"><i class="bi bi-printer"></i> Cetak</button>
                            <button class="btn-d" style="padding:3px 7px;font-size:0.71rem;margin-left:3px;"><i class="bi bi-trash"></i></button>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<!-- ======== DRAWING RECEIPT ======== -->
<div class="page" id="page-drw-receipt">
    <div class="mb-4 d-flex justify-content-between align-items-center no-print">
        <div><div class="page-heading">Drawing — Form Tanda Terima</div><div class="page-sub">Cetak tanda terima drawing ke supplier</div></div>
        <button class="btn-p" onclick="window.print()"><i class="bi bi-printer"></i> Print / Cetak</button>
    </div>
    <div class="content-card" id="printArea">
        <div style="text-align:center;margin-bottom:20px;padding-bottom:16px;border-bottom:2px solid #111827;">
            <div style="font-size:1.05rem;font-weight:800;color:#111827;letter-spacing:1px;">TANDA TERIMA DRAWING</div>
            <div style="font-size:0.78rem;color:#6b7280;margin-top:3px;">PT. BEST — Buyer Efficiency System Tools</div>
        </div>
        <div class="row g-3 mb-4">
            <div class="col-6"><label class="flbl">No. Tanda Terima</label><input type="text" class="finp" value="TTD-<?= date('Ymd') ?>-001"></div>
            <div class="col-6"><label class="flbl">Tanggal</label><input type="date" class="finp" value="<?= date('Y-m-d') ?>"></div>
            <div class="col-6"><label class="flbl">Nama Supplier</label><input type="text" class="finp" placeholder="Nama supplier..."></div>
            <div class="col-6"><label class="flbl">PIC Penerima</label><input type="text" class="finp" placeholder="Nama penerima..."></div>
        </div>
        <label class="flbl mb-2">Daftar Drawing yang Diserahkan</label>
        <div class="table-responsive mb-4">
            <table class="table tbl align-middle" style="border:1px solid #e5e7eb;">
                <thead><tr><th>No</th><th>No. Drawing</th><th>Nama Part</th><th>Revisi</th><th>Jumlah</th><th>Keterangan</th></tr></thead>
                <tbody>
                    <tr><td>1</td><td>DRW-001</td><td>Cover Housing</td><td>Rev.2</td><td>1 lembar</td><td>—</td></tr>
                    <tr><td>2</td><td>DRW-002</td><td>Bracket Assy</td><td>Rev.1</td><td>1 lembar</td><td>—</td></tr>
                    <tr><td>3</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
                </tbody>
            </table>
        </div>
        <div class="row g-3">
            <div class="col-6" style="text-align:center;">
                <div style="border-top:1px solid #374151;margin-top:60px;padding-top:8px;font-size:0.78rem;color:#374151;">Yang Menyerahkan</div>
            </div>
            <div class="col-6" style="text-align:center;">
                <div style="border-top:1px solid #374151;margin-top:60px;padding-top:8px;font-size:0.78rem;color:#374151;">Yang Menerima</div>
            </div>
        </div>
    </div>
</div>

<!-- ======== QUOTATION DASHBOARD ======== -->
<div class="page" id="page-quo-db">
    <div class="mb-4"><div class="page-heading">Quotation — Dashboard</div><div class="page-sub">Ringkasan penawaran harga</div></div>
    <div class="row g-3 mb-4">
        <?php $qc=[['Total Quotation',34,'bi-file-earmark-text','#4f46e5','#eef2ff'],['Open',12,'bi-envelope-open','#16a34a','#f0fdf4'],['In Review',8,'bi-hourglass-split','#d97706','#fffbeb'],['Closed',14,'bi-check-circle','#6b7280','#f1f5f9']];
        foreach($qc as $c): ?>
        <div class="col-6 col-xl-3">
            <div class="stat-card">
                <div class="stat-icon" style="background:<?= $c[4] ?>;"><i class="bi <?= $c[2] ?>" style="color:<?= $c[3] ?>;"></i></div>
                <div><div class="stat-value"><?= $c[1] ?></div><div class="stat-label"><?= $c[0] ?></div></div>
            </div>
        </div>
        <?php endforeach; ?>
    </div>
    <div class="content-card">
        <div class="card-hdr"><h5><i class="bi bi-bar-chart me-2" style="color:#818cf8;"></i>Trend Quotation Bulanan</h5></div>
        <div class="chart-wrap">
            <?php $qv=[5,7,4,9,6,8,11,7,9,6,8,9];
            foreach($months as $i=>$m): ?>
            <div class="chart-bar" style="height:<?= ($qv[$i]/12)*100 ?>%;background:linear-gradient(180deg,#818cf8,#4f46e5);"><span class="bar-lbl"><?= $m ?></span></div>
            <?php endforeach; ?>
        </div>
    </div>
</div>

<!-- ======== QUOTATION LIST ======== -->
<div class="page" id="page-quo-list">
    <div class="mb-4 d-flex justify-content-between align-items-center">
        <div><div class="page-heading">Quotation — Data List</div><div class="page-sub">Daftar penawaran harga dari vendor</div></div>
        <button class="btn-p"><i class="bi bi-plus"></i> Buat Quotation</button>
    </div>
    <div class="content-card">
        <div class="card-hdr">
            <h5><i class="bi bi-list-ul me-2" style="color:#818cf8;"></i>Daftar Quotation</h5>
            <input type="text" class="finp" placeholder="Cari quotation..." style="width:180px;">
        </div>
        <div class="table-responsive">
            <table class="table tbl align-middle">
                <thead><tr><th>No. Quotation</th><th>Vendor</th><th>Item</th><th>Tgl Terima</th><th>Nilai</th><th>Status</th><th>Aksi</th></tr></thead>
                <tbody>
                    <tr><td><strong>QUO-2025-001</strong></td><td>PT. Maju Jaya</td><td>Bracket Assy x50</td><td>01 Feb 2025</td><td>Rp 12.500.000</td><td><span class="bs bs-green">Open</span></td><td><button class="btn-o" style="padding:3px 9px;font-size:0.71rem;">Detail</button></td></tr>
                    <tr><td><strong>QUO-2025-002</strong></td><td>CV. Sukses Makmur</td><td>Cover Housing x20</td><td>05 Feb 2025</td><td>Rp 4.800.000</td><td><span class="bs bs-yellow">In Review</span></td><td><button class="btn-o" style="padding:3px 9px;font-size:0.71rem;">Detail</button></td></tr>
                    <tr><td><strong>QUO-2025-003</strong></td><td>PT. Karya Mandiri</td><td>Shaft Pin x100</td><td>10 Feb 2025</td><td>Rp 8.200.000</td><td><span class="bs bs-gray">Closed</span></td><td><button class="btn-o" style="padding:3px 9px;font-size:0.71rem;">Detail</button></td></tr>
                </tbody>
            </table>
        </div>
    </div>
</div>

<!-- ======== INVENTORY DASHBOARD ======== -->
<div class="page" id="page-inv-db">
    <div class="mb-4"><div class="page-heading">Inventory ATK — Dashboard</div><div class="page-sub">Ringkasan stok alat tulis kantor</div></div>
    <div class="row g-3 mb-4">
        <?php $ic=[['Total Item',48,'bi-box-seam','#4f46e5','#eef2ff'],['Stok Aman',35,'bi-check-circle','#16a34a','#f0fdf4'],['Stok Menipis',9,'bi-exclamation-triangle','#d97706','#fffbeb'],['Stok Habis',4,'bi-x-circle','#dc2626','#fef2f2']];
        foreach($ic as $c): ?>
        <div class="col-6 col-xl-3">
            <div class="stat-card">
                <div class="stat-icon" style="background:<?= $c[4] ?>;"><i class="bi <?= $c[2] ?>" style="color:<?= $c[3] ?>;"></i></div>
                <div><div class="stat-value"><?= $c[1] ?></div><div class="stat-label"><?= $c[0] ?></div></div>
            </div>
        </div>
        <?php endforeach; ?>
    </div>
    <div class="row g-3">
        <div class="col-12 col-lg-6">
            <div class="content-card h-100">
                <div class="card-hdr"><h5><i class="bi bi-bar-chart me-2" style="color:#818cf8;"></i>Top Item Keluar Bulan Ini</h5></div>
                <?php $ti=[['Kertas A4',320,'#4f46e5'],['Pulpen',85,'#16a34a'],['Sticky Note',60,'#d97706'],['Spidol',45,'#7c3aed'],['Amplop',38,'#dc2626']];
                foreach($ti as $t): ?>
                <div class="d-flex align-items-center gap-3 mb-2">
                    <div style="width:90px;font-size:0.77rem;color:#374151;"><?= $t[0] ?></div>
                    <div style="flex:1;"><div class="prog"><div class="prog-bar" style="width:<?= ($t[1]/320)*100 ?>%;background:<?= $t[2] ?>;"></div></div></div>
                    <div style="width:30px;font-size:0.77rem;font-weight:600;color:<?= $t[2] ?>;text-align:right;"><?= $t[1] ?></div>
                </div>
                <?php endforeach; ?>
            </div>
        </div>
        <div class="col-12 col-lg-6">
            <div class="content-card h-100">
                <div class="card-hdr"><h5><i class="bi bi-arrow-left-right me-2" style="color:#818cf8;"></i>Transaksi Terbaru</h5></div>
                <?php $tr=[['Kertas A4','Keluar','50 rim','#dc2626','bi-arrow-up-right'],['Pulpen Pilot','Masuk','2 box','#16a34a','bi-arrow-down-left'],['Tinta Printer','Keluar','3 pcs','#dc2626','bi-arrow-up-right'],['Staples','Masuk','5 pcs','#16a34a','bi-arrow-down-left']];
                foreach($tr as $t): ?>
                <div class="todo-item">
                    <div style="width:28px;height:28px;background:<?= $t[3] ?>18;border-radius:8px;display:flex;align-items:center;justify-content:center;flex-shrink:0;"><i class="bi <?= $t[4] ?>" style="color:<?= $t[3] ?>;font-size:0.8rem;"></i></div>
                    <div style="flex:1;font-size:0.8rem;color:#374151;"><?= $t[0] ?></div>
                    <span class="bs" style="background:<?= $t[3] ?>18;color:<?= $t[3] ?>;"><?= $t[1] ?></span>
                    <span style="font-size:0.75rem;color:#6b7280;margin-left:5px;"><?= $t[2] ?></span>
                </div>
                <?php endforeach; ?>
            </div>
        </div>
    </div>
</div>

<!-- ======== INVENTORY IN/OUT ======== -->
<div class="page" id="page-inv-io">
    <div class="mb-4"><div class="page-heading">Inventory ATK — Barang Masuk/Keluar</div><div class="page-sub">Input transaksi stok ATK</div></div>
    <div class="row g-3">
        <div class="col-12 col-md-5">
            <div class="content-card">
                <div class="card-hdr"><h5><i class="bi bi-arrow-left-right me-2" style="color:#818cf8;"></i>Input Transaksi</h5></div>
                <div class="row g-3">
                    <div class="col-12"><label class="flbl">Jenis Transaksi</label>
                        <select class="finp"><option>Barang Masuk</option><option>Barang Keluar</option></select>
                    </div>
                    <div class="col-12"><label class="flbl">Nama Barang</label>
                        <select class="finp"><option>Kertas A4</option><option>Pulpen Pilot</option><option>Sticky Note</option><option>Spidol Board</option><option>Tinta Printer</option></select>
                    </div>
                    <div class="col-6"><label class="flbl">Jumlah</label><input type="number" class="finp" placeholder="0" min="1"></div>
                    <div class="col-6"><label class="flbl">Satuan</label>
                        <select class="finp"><option>Rim</option><option>Pcs</option><option>Box</option><option>Lusin</option></select>
                    </div>
                    <div class="col-12"><label class="flbl">Tanggal</label><input type="date" class="finp" value="<?= date('Y-m-d') ?>"></div>
                    <div class="col-12"><label class="flbl">Keterangan</label><input type="text" class="finp" placeholder="Opsional..."></div>
                    <div class="col-12 d-flex gap-2">
                        <button class="btn-p"><i class="bi bi-save"></i> Simpan</button>
                        <button class="btn-o"><i class="bi bi-arrow-counterclockwise"></i> Reset</button>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-12 col-md-7">
            <div class="content-card">
                <div class="card-hdr"><h5><i class="bi bi-table me-2" style="color:#818cf8;"></i>Riwayat Transaksi</h5></div>
                <div class="table-responsive">
                    <table class="table tbl align-middle">
                        <thead><tr><th>Tanggal</th><th>Barang</th><th>Jenis</th><th>Jumlah</th><th>Oleh</th></tr></thead>
                        <tbody>
                            <tr><td>22 Feb</td><td>Kertas A4</td><td><span class="bs bs-red">Keluar</span></td><td>50 rim</td><td>Admin</td></tr>
                            <tr><td>21 Feb</td><td>Pulpen Pilot</td><td><span class="bs bs-green">Masuk</span></td><td>2 box</td><td>Gudang</td></tr>
                            <tr><td>20 Feb</td><td>Tinta Printer</td><td><span class="bs bs-red">Keluar</span></td><td>3 pcs</td><td>Admin</td></tr>
                            <tr><td>19 Feb</td><td>Staples</td><td><span class="bs bs-green">Masuk</span></td><td>5 pcs</td><td>Gudang</td></tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- ======== INVENTORY LOW STOCK ======== -->
<div class="page" id="page-inv-low">
    <div class="mb-4 d-flex justify-content-between align-items-center">
        <div><div class="page-heading">Inventory ATK — Stok Menipis</div><div class="page-sub">Barang yang perlu segera di-restock</div></div>
        <button class="btn-p"><i class="bi bi-download"></i> Export</button>
    </div>
    <div class="content-card">
        <div class="card-hdr"><h5><i class="bi bi-exclamation-triangle-fill me-2" style="color:#d97706;"></i>Daftar Stok Menipis / Habis</h5></div>
        <div class="table-responsive">
            <table class="table tbl align-middle">
                <thead><tr><th>Nama Barang</th><th>Satuan</th><th>Stok Saat Ini</th><th>Stok Minimum</th><th>Status</th><th>Aksi</th></tr></thead>
                <tbody>
                    <?php $low=[['Kertas A4','Rim',2,10,'Kritis'],['Tinta Printer','Pcs',1,5,'Kritis'],['Spidol Board','Pcs',3,8,'Menipis'],['Sticky Note','Pack',2,6,'Menipis'],['Amplop','Pcs',8,20,'Menipis'],['Map Plastik','Pcs',0,10,'Habis'],['Klip Kertas','Box',0,5,'Habis']];
                    $lb=['Kritis'=>'bs-red','Menipis'=>'bs-yellow','Habis'=>'bs-black'];
                    foreach($low as $r): ?>
                    <tr>
                        <td><strong><?= $r[0] ?></strong></td><td><?= $r[1] ?></td>
                        <td style="font-weight:700;color:<?= $r[2]==0?'#dc2626':($r[2]<=3?'#d97706':'#374151') ?>;"><?= $r[2] ?></td>
                        <td><?= $r[3] ?></td>
                        <td><span class="bs <?= $lb[$r[4]] ?>"><?= $r[4] ?></span></td>
                        <td><button class="btn-o" style="padding:3px 9px;font-size:0.71rem;"><i class="bi bi-cart-plus"></i> Restock</button></td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<!-- ======== PENGATURAN ======== -->
<div class="page" id="page-settings">
    <div class="mb-4"><div class="page-heading">Pengaturan</div><div class="page-sub">Konfigurasi akun dan sistem</div></div>
    <div class="content-card" style="max-width:480px;">
        <div class="card-hdr"><h5><i class="bi bi-person-fill me-2" style="color:#818cf8;"></i>Informasi Akun</h5></div>
        <div class="row g-3">
            <div class="col-12"><label class="flbl">Nama</label><input type="text" class="finp" value="<?= htmlspecialchars($name) ?>"></div>
            <div class="col-12"><label class="flbl">NPK</label><input type="text" class="finp" value="<?= htmlspecialchars($npk) ?>" readonly style="background:#f8f9fa;"></div>
            <div class="col-12"><label class="flbl">Role</label><input type="text" class="finp" value="<?= htmlspecialchars($role) ?>" readonly style="background:#f8f9fa;"></div>
            <div class="col-12"><button class="btn-p"><i class="bi bi-save"></i> Simpan Perubahan</button></div>
        </div>
    </div>
</div>

</div><!-- /main-content -->

<script src="/best-root/public/bootstrap-5.3.8/js/bootstrap.bundle.min.js"></script>
<script>
const pageTitles = {
    'home':'Home',
    'att-db':'Attendance — Dashboard',
    'att-list':'Attendance — Data Absensi',
    'ot-db':'Overtime — Dashboard',
    'ot-form':'Overtime — Form Pengajuan',
    'ot-budget':'Overtime — Budget', 
    'exp-db':'Expense — Dashboard',
    'exp-list':'Expense — Kategori & Detail',
    'sk-db':'Skillmap — Dashboard',
    'sk-list':'Skillmap — Data Skill',
    'drw-db':'Drawing — Dashboard',
    'drw-list':'Drawing — Data Drawing',
    'drw-receipt':'Drawing — Tanda Terima',
    'quo-db':'Quotation — Dashboard',
    'quo-list':'Quotation — Data List',
    'inv-db':'Inventory ATK — Dashboard',
    'inv-io':'Inventory ATK — Barang Masuk/Keluar',
    'inv-low':'Inventory ATK — Stok Menipis',
    'settings':'Pengaturan'
};



// Data structure untuk menyimpan tab yang aktif
let activeTabs = [{
    id: 'home',
    parent: null,
    child: null,
    label: 'Home'
}];

// Tambahkan fungsi ini setelah deklarasi activeTabs
function saveTabs() {
    localStorage.setItem('activeTabs', JSON.stringify(activeTabs));
}

// FUNGSI BARU - Navigasi berbasis URL
function navigateToPage(element) {
    const pageId = element.dataset.page;
    if (!pageId) return false;
    
    // Update URL tanpa reload
    const url = new URL(window.location);
    url.searchParams.set('page', pageId);
    window.history.pushState({}, '', url);
    
    // Load halaman
    loadPage(pageId);
    
    return false; // Mencegah link default
}

// Load page berdasarkan ID
function loadPage(pageId) {
    console.log('Loading page:', pageId);
    
    // Hapus class active dari semua page
    document.querySelectorAll('.page').forEach(p => p.classList.remove('active'));
    
    // Tampilkan page yang dipilih
    const targetPage = document.getElementById('page-' + pageId);
    if (targetPage) {
        targetPage.classList.add('active'); // <-- INI PENTING
        
        // Update page title
        document.getElementById('pageTitle').textContent = pageTitles[pageId] || pageId;
        
        // Update active state di navigation
        updateNavActiveState(pageId);
        
        // Update tabs
        addTab(pageId);
        
        // Trigger custom event untuk halaman yang dimuat
        window.dispatchEvent(new CustomEvent('pageLoaded', { detail: { pageId: pageId } }));
    } else {
        console.error('Page not found:', pageId);
        // Fallback ke home
        document.getElementById('page-home').classList.add('active');
        document.getElementById('pageTitle').textContent = 'Home';
    }
}

// Initialize dari URL
function initFromURL() {
    const urlParams = new URLSearchParams(window.location.search);
    const pageId = urlParams.get('page') || 'home';
    
    console.log('Init from URL, pageId:', pageId); // Untuk debugging
    
    // Validasi pageId
    const validPages = Object.keys(pageTitles);
    if (validPages.includes(pageId)) {
        // HAPUS SEMUA CLASS ACTIVE DULU
        document.querySelectorAll('.page').forEach(p => p.classList.remove('active'));
        
        // SET HALAMAN BARU
        loadPage(pageId);
    } else {
        loadPage('home');
    }
}

// Handle browser back/forward
window.addEventListener('popstate', function() {
    initFromURL();
});

// Override showPage lama (untuk kompatibilitas)
function showPage(id, el) {
    // Update URL
    const url = new URL(window.location);
    url.searchParams.set('page', id);
    window.history.pushState({}, '', url);
    
    loadPage(id);
    
    // Close user dropdown
    closeUD();
}

// Mapping menu parent dan child
const menuMapping = {
    'att-db': { parent: 'Attendance', child: 'Dashboard', parentIcon: 'bi-calendar-check-fill' },
    'att-list': { parent: 'Attendance', child: 'Data Absensi', parentIcon: 'bi-calendar-check-fill' },
    'ot-db': { parent: 'Overtime', child: 'Dashboard', parentIcon: 'bi-clock-history' },
    'ot-form': { parent: 'Overtime', child: 'Form Pengajuan', parentIcon: 'bi-clock-history' },
    'ot-budget': { parent: 'Overtime', child: 'Budget Overtime', parentIcon: 'bi-clock-history' },
    'exp-db': { parent: 'Expense', child: 'Dashboard', parentIcon: 'bi-wallet2' },
    'exp-list': { parent: 'Expense', child: 'Kategori & Detail', parentIcon: 'bi-wallet2' },
    'sk-db': { parent: 'Skillmap', child: 'Dashboard', parentIcon: 'bi-diagram-3-fill' },
    'sk-list': { parent: 'Skillmap', child: 'Data Skill', parentIcon: 'bi-diagram-3-fill' },
    'drw-db': { parent: 'Drawing', child: 'Dashboard', parentIcon: 'bi-file-earmark-ruled-fill' },
    'drw-list': { parent: 'Drawing', child: 'Data Drawing', parentIcon: 'bi-file-earmark-ruled-fill' },
    'drw-receipt': { parent: 'Drawing', child: 'Form Tanda Terima', parentIcon: 'bi-file-earmark-ruled-fill' },
    'quo-db': { parent: 'Quotation', child: 'Dashboard', parentIcon: 'bi-file-earmark-text-fill' },
    'quo-list': { parent: 'Quotation', child: 'Data Quotation', parentIcon: 'bi-file-earmark-text-fill' },
    'inv-db': { parent: 'Inventory ATK', child: 'Dashboard Stock', parentIcon: 'bi-box-seam-fill' },
    'inv-io': { parent: 'Inventory ATK', child: 'Barang Masuk/Keluar', parentIcon: 'bi-box-seam-fill' },
    'inv-low': { parent: 'Inventory ATK', child: 'Stock Menipis', parentIcon: 'bi-box-seam-fill' },
    'settings': { parent: 'Sistem', child: 'Pengaturan', parentIcon: 'bi-gear-fill' }
};

// Fungsi untuk render tabs
function renderTabs() {
    const tabList = document.getElementById('tabList');
    const pageTitle = document.getElementById('pageTitle');
    
    if (!tabList) return;
    
    // Sembunyikan page title jika ada tab
    if (activeTabs.length > 0) {
        pageTitle.classList.add('hidden');
    } else {
        pageTitle.classList.remove('hidden');
    }
    
    // Dapatkan ID halaman yang sedang aktif dari URL
    const urlParams = new URLSearchParams(window.location.search);
    const activeId = urlParams.get('page') || 'home';
    
    let html = '';
    
    activeTabs.forEach((tab, index) => {
        const isActive = tab.id === activeId;
        const menuInfo = menuMapping[tab.id] || { parent: 'Menu', child: tab.label, parentIcon: 'bi-folder' };
        
        // Gunakan href dengan query parameter
        const href = `?page=${tab.id}`;
        
        // Tentukan apakah tab ini bisa ditutup
        // Home tab TIDAK BISA ditutup, tab lain BISA ditutup
        const canClose = tab.id !== 'home'; // Hanya home yang tidak bisa ditutup
        
        if (index === 0 && tab.id === 'home') {
            html += `
                <div class="tab-item ${isActive ? 'active' : ''}" 
                    data-tab-id="${tab.id}"
                    title="Home">
                    <a href="${href}" style="text-decoration:none;color:inherit;display:flex;align-items:center;gap:4px;flex:1;" onclick="return handleTabClick(event, '${tab.id}')">
                        <span class="tab-icon"><i class="bi bi-house-fill"></i></span>
                        <span class="tab-content">
                            <span class="tab-parent">Home</span>
                        </span>
                    </a>
                    ${canClose ? 
                        `<span class="tab-close" onclick="closeTab('${tab.id}', event)" title="Tutup tab"><i class="bi bi-x"></i></span>` : 
                        ''}
                </div>
            `;
        } else {
            // Buat title lengkap
            const fullTitle = `${menuInfo.parent} › ${menuInfo.child}`;
            
            html += `
                <div class="tab-item ${isActive ? 'active' : ''}" 
                    data-tab-id="${tab.id}"
                    title="${fullTitle}">
                    <a href="${href}" style="text-decoration:none;color:inherit;display:flex;align-items:center;gap:4px;flex:1;" onclick="return handleTabClick(event, '${tab.id}')">
                        <span class="tab-icon"><i class="bi ${menuInfo.parentIcon}"></i></span>
                        <span class="tab-content">
                            <span class="tab-parent">${menuInfo.parent}</span>
                            <span class="tab-separator"><i class="bi bi-chevron-right"></i></span>
                            <span class="tab-child">${menuInfo.child}</span>
                        </span>
                    </a>
                    ${canClose ? 
                        `<span class="tab-close" onclick="closeTab('${tab.id}', event)" title="Tutup tab"><i class="bi bi-x"></i></span>` : 
                        ''}
                </div>
            `;
        }
    });
    
    tabList.innerHTML = html;
    updateScrollIndicators();
}

// Handle tab click tanpa reload
function handleTabClick(event, pageId) {
    event.preventDefault();
    
    // Update URL
    const url = new URL(window.location);
    url.searchParams.set('page', pageId);
    window.history.pushState({}, '', url);
    
    // Load page
    loadPage(pageId);
    
    return false;
}

// switchToTab
function switchToTab(id) {
    // Update URL
    const url = new URL(window.location);
    url.searchParams.set('page', id);
    window.history.pushState({}, '', url);
    
    loadPage(id);
}

function updateNavActiveState(id) {
    document.querySelectorAll('.nav-item-link, .nav-sub-link').forEach(e => e.classList.remove('active'));
    
    // Find and activate the corresponding nav item
    if (id === 'home') {
        const homeLink = document.querySelector('.nav-item-link[onclick*="home"]');
        if (homeLink) homeLink.classList.add('active');
    } else {
        // Try to find sublink first
        const subLink = Array.from(document.querySelectorAll('.nav-sub-link')).find(el => 
            el.getAttribute('onclick') && el.getAttribute('onclick').includes(id)
        );
        
        if (subLink) {
            subLink.classList.add('active');
            // Activate parent
            const parentItem = subLink.closest('.nav-item')?.querySelector('.nav-item-link');
            if (parentItem) {
                parentItem.classList.add('active');
                // Open parent submenu
                const submenu = parentItem.nextElementSibling;
                if (submenu && !submenu.classList.contains('open')) {
                    submenu.classList.add('open');
                    parentItem.classList.add('open');
                }
            }
        }
    }
}

function closeTab(id, event) {
    event.stopPropagation();
    
    // JANGAN biarkan home tab ditutup
    if (id === 'home') {
        console.log('Home tab tidak bisa ditutup');
        return;
    }
    
    // Hapus tab dari array (kecuali home)
    const index = activeTabs.findIndex(tab => tab.id === id);
    if (index > -1) {
        activeTabs.splice(index, 1);
        
        // SIMPAN KE LOCALSTORAGE
        saveTabs();
    }
    
    renderTabs();
    
    // Jika tab yang aktif ditutup, pindah ke home
    const urlParams = new URLSearchParams(window.location.search);
    const activeId = urlParams.get('page') || 'home';
    
    if (activeId === id) {
        // Pindah ke home
        switchToTab('home');
    }
}

function openNewTab() {
    showPage('home', null);
}

function initTabScroll() {
    const tabContainer = document.querySelector('.tab-container');
    const tabList = document.getElementById('tabList');
    
    if (!tabContainer || !tabList) return;
    
    // Variable untuk tracking scroll
    let isScrolling = false;
    let scrollTimeout;
    
    // Fungsi untuk scroll horizontal dengan wheel
    tabContainer.addEventListener('wheel', function(e) {
        // Cegah scroll vertical default
        e.preventDefault();
        
        // Atur kecepatan scroll
        const scrollAmount = e.deltaY * 1.5; // Bisa disesuaikan
        
        // Scroll container
        tabContainer.scrollLeft += scrollAmount;
        
        // Tampilkan scrollbar sementara saat scrolling
        tabContainer.style.overflowX = 'auto';
        isScrolling = true;
        
        // Clear timeout sebelumnya
        clearTimeout(scrollTimeout);
        
        // Set timeout untuk menyembunyikan scrollbar setelah berhenti scroll
        scrollTimeout = setTimeout(() => {
            if (window.innerWidth > 768) { // Hanya di desktop
                tabContainer.style.overflowX = 'hidden';
            }
            isScrolling = false;
        }, 1000);
    }, { passive: false });
    
    // Fitur auto-scroll saat mendekati tepi (opsional)
    let autoScrollInterval;
    const scrollThreshold = 50; // Jarak dari tepi untuk auto-scroll
    
    tabContainer.addEventListener('mousemove', function(e) {
        if (!isScrolling) {
            const rect = tabContainer.getBoundingClientRect();
            const mouseX = e.clientX - rect.left;
            const containerWidth = rect.width;
            
            // Hentikan interval sebelumnya
            if (autoScrollInterval) {
                clearInterval(autoScrollInterval);
                autoScrollInterval = null;
            }
            
            // Auto-scroll jika mouse mendekati tepi kanan
            if (mouseX > containerWidth - scrollThreshold && tabContainer.scrollLeft < tabContainer.scrollWidth - containerWidth) {
                const speed = ((mouseX - (containerWidth - scrollThreshold)) / scrollThreshold) * 5;
                autoScrollInterval = setInterval(() => {
                    tabContainer.scrollLeft += speed;
                }, 20);
            }
            // Auto-scroll jika mouse mendekati tepi kiri
            else if (mouseX < scrollThreshold && tabContainer.scrollLeft > 0) {
                const speed = ((scrollThreshold - mouseX) / scrollThreshold) * 5;
                autoScrollInterval = setInterval(() => {
                    tabContainer.scrollLeft -= speed;
                }, 20);
            }
        }
    });
    
    // Hentikan auto-scroll saat mouse keluar
    tabContainer.addEventListener('mouseleave', function() {
        if (autoScrollInterval) {
            clearInterval(autoScrollInterval);
            autoScrollInterval = null;
        }
    });
    
    // Fitur untuk scroll dengan touchpad (gesture 2 jari)
    let touchStartX = 0;
    let touchScrollLeft = 0;
    
    tabContainer.addEventListener('touchstart', function(e) {
        touchStartX = e.touches[0].clientX;
        touchScrollLeft = tabContainer.scrollLeft;
    }, { passive: true });
    
    tabContainer.addEventListener('touchmove', function(e) {
        if (e.cancelable) {
            e.preventDefault(); // Cegah scroll vertical saat scroll horizontal
        }
        const touchX = e.touches[0].clientX;
        const diff = touchStartX - touchX;
        tabContainer.scrollLeft = touchScrollLeft + diff;
    }, { passive: false });
    
    // Tampilkan scrollbar saat container di-hover (opsional)
    tabContainer.addEventListener('mouseenter', function() {
        if (window.innerWidth > 768) {
            tabContainer.style.overflowX = 'auto';
        }
    });
    
    tabContainer.addEventListener('mouseleave', function() {
        if (!isScrolling && window.innerWidth > 768) {
            setTimeout(() => {
                if (!isScrolling) {
                    tabContainer.style.overflowX = 'hidden';
                }
            }, 500);
        }
    });
}

// Fungsi untuk update indikator scroll
function updateScrollIndicators() {
    const container = document.querySelector('.tab-container');
    if (!container) return;
    
    const canScrollLeft = container.scrollLeft > 0;
    const canScrollRight = container.scrollLeft < container.scrollWidth - container.clientWidth;
    
    container.classList.toggle('can-scroll-left', canScrollLeft);
    container.classList.toggle('can-scroll-right', canScrollRight);
}

// Keyboard shortcut untuk tabs
document.addEventListener('keydown', function(e) {
    if (e.ctrlKey && e.key === 't') {
        e.preventDefault();
        openNewTab();
    }
    
    // Ctrl+W to close current tab (kecuali home)
    if (e.ctrlKey && e.key === 'w') {
        e.preventDefault();
        const activePage = document.querySelector('.page.active');
        if (activePage) {
            const activeId = activePage.id.replace('page-', '');
            // Jangan close jika activeId adalah home
            if (activeId !== 'home') {
                closeTab(activeId, { stopPropagation: () => {} });
            }
        }
    }
});

function addTab(id) {
    // Pastikan home selalu ada di array
    const homeExists = activeTabs.some(tab => tab.id === 'home');
    if (!homeExists) {
        // Tambahkan home di awal jika belum ada
        activeTabs.unshift({
            id: 'home',
            parent: null,
            child: null,
            label: 'Home'
        });
    }
    
    // Cek apakah tab sudah ada (selain home)
    const existingIndex = activeTabs.findIndex(tab => tab.id === id);
    
    if (existingIndex === -1 && id !== 'home') {
        // Tambah tab baru (selain home)
        const menuInfo = menuMapping[id] || { parent: 'Menu', child: pageTitles[id] || id };
        activeTabs.push({
            id: id,
            parent: menuInfo.parent,
            child: menuInfo.child,
            label: pageTitles[id] || id
        });
        
        // SIMPAN KE LOCALSTORAGE
        saveTabs();
    }
    
    renderTabs();
}

function toggleSidebar() {
    const s = document.getElementById('sidebar');
    const n = document.getElementById('navbar');
    const m = document.getElementById('main-content');
    const i = document.getElementById('toggleIcon');
    s.classList.toggle('collapsed');
    n.classList.toggle('collapsed');
    m.classList.toggle('collapsed');
    const c = s.classList.contains('collapsed');
    i.className = c ? 'bi bi-chevron-compact-right' : 'bi bi-chevron-compact-left';
    if (c) {
        document.querySelectorAll('.nav-submenu.open').forEach(x => x.classList.remove('open'));
        document.querySelectorAll('.nav-item-link.has-sub.open').forEach(x => x.classList.remove('open'));
    }
}

function toggleSub(el) {
    const sub = el.nextElementSibling;
    const wasOpen = sub.classList.contains('open');
    
    // Tutup semua submenu lain
    document.querySelectorAll('.nav-submenu.open').forEach(x => {
        if (x !== sub) x.classList.remove('open');
    });
    document.querySelectorAll('.nav-item-link.has-sub.open').forEach(x => {
        if (x !== el) x.classList.remove('open');
    });
    
    // Toggle current submenu
    if (!wasOpen) {
        sub.classList.add('open');
        el.classList.add('open');
    } else {
        sub.classList.remove('open');
        el.classList.remove('open');
    }
}

function toggleUD() {
    document.getElementById('userDropdownMenu').classList.toggle('show');
    document.getElementById('chevronIcon').classList.toggle('rotated');
}
function closeUD() {
    document.getElementById('userDropdownMenu').classList.remove('show');
    document.getElementById('chevronIcon').classList.remove('rotated');
}
document.addEventListener('click', e => {
    const w = document.getElementById('userDropdownWrapper');
    if (w && !w.contains(e.target)) closeUD();
});
window.addEventListener('pageshow', e => { if (e.persisted) location.reload(); });

// Fungsi untuk cek apakah user sudah pernah scroll di session ini
function hasUserScrolledTabs() {
    return sessionStorage.getItem('hasScrolledTabs') === 'true';
}

// Tandai bahwa user sudah melakukan scroll
function markUserHasScrolled() {
    sessionStorage.setItem('hasScrolledTabs', 'true');
}

// Fungsi untuk menampilkan tooltip (hanya jika perlu)
function showScrollTooltipIfNeeded() {
    const container = document.querySelector('.tab-container');
    if (!container) return;
    
    // Cek apakah ada scroll (tab melebihi container)
    const hasScroll = container.scrollWidth > container.clientWidth;
    
    // Cek apakah user sudah pernah scroll di session ini
    const alreadyScrolled = hasUserScrolledTabs();
    
    // Tampilkan tooltip hanya jika:
    // 1. Ada scroll (tab banyak)
    // 2. User BELUM pernah melakukan scroll di session ini
    if (hasScroll && !alreadyScrolled) {
        showScrollTooltip();
    }
}

// Fungsi untuk menampilkan tooltip
function showScrollTooltip() {
    // Hapus tooltip lama
    const oldTooltip = document.querySelector('.scroll-tooltip-global');
    if (oldTooltip) oldTooltip.remove();
    
    // Buat tooltip baru
    const tooltip = document.createElement('div');
    tooltip.className = 'scroll-tooltip-global';
    tooltip.innerHTML = '<i class="bi bi-arrow-left-right"></i> Scroll di sini untuk tab lainnya';
    
    // Dapatkan posisi tab container
    const tabContainer = document.querySelector('.tab-container');
    const rect = tabContainer.getBoundingClientRect();
    
    // Styling - posisi absolute ke body
    tooltip.style.cssText = `
        position: absolute;
        top: ${rect.bottom + window.scrollY + 5}px;
        left: 50%;
        transform: translateX(-50%);
        background: linear-gradient(135deg, #4f46e5, #818cf8);
        color: white;
        padding: 6px 16px;
        border-radius: 30px;
        font-size: 0.7rem;
        font-weight: 500;
        white-space: nowrap;
        z-index: 10000;
        box-shadow: 0 4px 12px rgba(79, 70, 229, 0.4);
        border: 1px solid rgba(255,255,255,0.3);
        pointer-events: none;
        animation: fadeInUp 0.3s ease;
    `;
    
    document.body.appendChild(tooltip);
    
    // Hilangkan setelah 3 detik
    setTimeout(() => {
        if (tooltip && tooltip.parentNode) {
            tooltip.style.animation = 'fadeOut 0.3s ease';
            setTimeout(() => tooltip.remove(), 300);
        }
    }, 3000);
}

// Deteksi saat user melakukan scroll
function initScrollDetection() {
    const container = document.querySelector('.tab-container');
    if (!container) return;
    
    container.addEventListener('scroll', function() {
        // Jika user melakukan scroll dan belum pernah scroll sebelumnya
        if (!hasUserScrolledTabs()) {
            markUserHasScrolled();
            
            // Hapus tooltip jika sedang muncul
            const tooltip = document.querySelector('.scroll-tooltip');
            if (tooltip) {
                tooltip.style.animation = 'fadeOut 0.3s ease';
                setTimeout(() => tooltip.remove(), 300);
            }
            
            // Opsional: tampilkan pesan sukses
            showSuccessMessage();
        }
    });
    
    // Deteksi scroll dengan mouse wheel
    container.addEventListener('wheel', function() {
        if (!hasUserScrolledTabs()) {
            // Beri sedikit waktu untuk mendeteksi scroll
            setTimeout(() => {
                if (container.scrollLeft > 0) {
                    markUserHasScrolled();
                }
            }, 100);
        }
    });
}

// Opsional: Pesan sukses setelah pertama kali scroll
function showSuccessMessage() {
    const container = document.querySelector('.tab-container');
    if (!container) return;
    
    const successMsg = document.createElement('div');
    successMsg.className = 'scroll-success';
    successMsg.innerHTML = '<i class="bi bi-check-circle-fill"></i> Mantap! Sekarang Anda bisa scroll kapan saja';
    
    successMsg.style.cssText = `
        position: absolute;
        bottom: -25px;
        left: 50%;
        transform: translateX(-50%);
        background: linear-gradient(135deg, #10b981, #34d399);
        color: white;
        padding: 4px 12px;
        border-radius: 20px;
        font-size: 0.65rem;
        font-weight: 500;
        white-space: nowrap;
        z-index: 1000;
        box-shadow: 0 2px 8px rgba(16, 185, 129, 0.3);
        border: 1px solid rgba(255,255,255,0.2);
        pointer-events: none;
        animation: fadeInUp 0.3s ease;
    `;
    
    container.appendChild(successMsg);
    
    setTimeout(() => {
        if (successMsg && successMsg.parentNode) {
            successMsg.style.animation = 'fadeOut 0.3s ease';
            setTimeout(() => successMsg.remove(), 300);
        }
    }, 2000);
}

// Event listener untuk DOMContentLoaded
document.addEventListener('DOMContentLoaded', function() {
    
    // LOAD TABS DARI LOCALSTORAGE
    const savedTabs = localStorage.getItem('activeTabs');
    if (savedTabs) {
        try {
            const parsed = JSON.parse(savedTabs);
            if (Array.isArray(parsed) && parsed.length > 0) {
                activeTabs = parsed;
                
                // PASTIKAN HOME SELALU ADA DI ARRAY
                const homeExists = activeTabs.some(tab => tab.id === 'home');
                if (!homeExists) {
                    activeTabs.unshift({
                        id: 'home',
                        parent: null,
                        child: null,
                        label: 'Home'
                    });
                }
            }
        } catch (e) {
            console.log('Gagal load tabs:', e);
            // Reset ke default jika error
            activeTabs = [{
                id: 'home',
                parent: null,
                child: null,
                label: 'Home'
            }];
        }
    }
    
    // Render tabs
    renderTabs();
    
    // Inisialisasi dari URL
    initFromURL();
    
    // Inisialisasi scroll
    initTabScroll();
    initScrollDetection();
    
    // Update indicators saat scroll
    const container = document.querySelector('.tab-container');
    if (container) {
        container.addEventListener('scroll', updateScrollIndicators);
        window.addEventListener('resize', updateScrollIndicators);
    }
    
    // Tampilkan tooltip jika perlu
    setTimeout(() => {
        showScrollTooltipIfNeeded();
    }, 1000);
});
</script>
</body>
</html>