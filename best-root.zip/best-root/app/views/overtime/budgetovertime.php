<?php
/**
 * Budget Overtime - Versi Kompleks dengan Member & Multiplier
 */

use app\models\otbudget;
use app\models\otmember;
use app\models\otmultiplier;

$tahun_ini = (int)date('Y');
$otbudget = new otbudget();
$otmember = new otmember();
$otmultiplier = new otmultiplier();

// Ambil data budget tahun ini
$ot_budget_db = $otbudget->getByTahun($tahun_ini);
$_chart = $otbudget->toArrayBulanan($ot_budget_db);
$_summary = $otbudget->getSummary($tahun_ini);

$ot_budget_per_bulan = $_chart['jam'];
$ot_amount_per_bulan = $_chart['amount'];
$ot_target_amount_per_bulan = $_chart['target_amount'];
$ot_target_jam_per_bulan = $_chart['target_jam'];
$ot_target_percent_per_bulan = $_chart['target_percent'];

$total_jam_budget = (float)$_summary['total_jam'];
$total_amount_budget = (float)$_summary['total_amount'];
$total_target_amount = (float)$_summary['total_target_amount'];
$total_target_jam = (float)$_summary['total_target_jam'];

// Ambil data member dan multiplier
$members = $otmember->getAll();
$avg_rate = $otmember->getAverageRate();
$multiplier = $otmultiplier->getByTahun($tahun_ini);

$nama_bulan = ['Januari','Februari','Maret','April','Mei','Juni',
               'Juli','Agustus','September','Oktober','November','Desember'];
?>
<style>
    /* Modal Member - 60% dari lebar viewport */
    #modalotmember .modal-box {
        max-width: 85vw !important;
        width: 85vw !important;
        min-width: 1000px;
        max-height: 95vh;
        display: flex;
        flex-direction: column;
        padding: 20px;
    }

    /* Container tabel dengan scroll */
    #modalotmember .table-responsive {
        max-height: calc(85vh - 250px);
        overflow-y: auto;
        border: 1px solid #e5e7eb;
        border-radius: 8px;
    }

    /* Styling tabel member */
    #memberTable {
        width: 100%;
        border-collapse: collapse;
    }

    #memberTable th {
        position: sticky;
        top: 0;
        background: #f8fafc;
        z-index: 10;
        padding: 12px 8px;
        font-size: 0.85rem;
        font-weight: 600;
        color: #374151;
        border-bottom: 2px solid #e5e7eb;
    }

    #memberTable td {
        padding: 10px 8px;
        border-bottom: 1px solid #f0f0f0;
        vertical-align: middle;
    }

    #memberTable input, 
    #memberTable select {
        width: 100%;
        padding: 8px 10px;
        font-size: 0.8rem;
        border: 1px solid #e5e7eb;
        border-radius: 6px;
    }

    #memberTable input:focus,
    #memberTable select:focus {
        border-color: var(--primary);
        outline: none;
        box-shadow: 0 0 0 2px rgba(79,70,229,0.1);
    }

    /* Mode selector */
    .mode-btn {
        position: relative;
        padding-right: 30px !important; /* Beri ruang untuk ikon pensil */
        margin-right: 8px;
        margin-bottom: 5px;
    }

    .mode-btn .btn-p, .mode-btn .btn-o {
        position: relative;
    }

    .mode-edit-icon {
        position: absolute;
        right: 8px;
        top: 50%;
        transform: translateY(-50%);
        cursor: pointer;
        width: 20px;
        height: 20px;
        display: inline-flex;
        align-items: center;
        justify-content: center;
        border-radius: 4px;
        transition: all 0.2s;
        z-index: 5;
    }

    .mode-btn-group {
    display: inline-flex;
    align-items: center;
    margin-right: 8px;
    margin-bottom: 5px;
    }

    .mode-btn-group .btn:first-child {
        border-top-right-radius: 0;
        border-bottom-right-radius: 0;
    }

    .mode-btn-group .btn:last-child {
        border-top-left-radius: 0;
        border-bottom-left-radius: 0;
        border-left: 1px solid rgba(0,0,0,0.1);
    }

    .mode-btn-group .btn-p:last-child {
        border-left-color: rgba(255,255,255,0.2);
    }

    .mode-edit-icon:hover {
        background: rgba(255,255,255,0.3);
    }

    /* Untuk mode aktif */
    .btn-p .mode-edit-icon {
        color: white;
    }

    .btn-p .mode-edit-icon:hover {
        background: rgba(255,255,255,0.2);
    }

    /* Untuk mode tidak aktif */
    .btn-o .mode-edit-icon {
        color: var(--primary);
    }

    .btn-o .mode-edit-icon:hover {
        background: var(--primary-hover-bg);
    }

    /* Tombol Mode Baru dengan warna berbeda */
    .btn-mode-baru {
        background: linear-gradient(135deg, #10b981, #059669) !important;
        color: white !important;
        border: none !important;
        box-shadow: 0 2px 6px rgba(16, 185, 129, 0.3);
        transition: all 0.2s;
    }

    .btn-mode-baru:hover {
        background: linear-gradient(135deg, #059669, #047857) !important;
        transform: translateY(-1px);
        box-shadow: 0 4px 8px rgba(16, 185, 129, 0.4);
    }

    .btn-mode-baru i {
        color: white;
    }

    /* Atau alternatif dengan warna ungu */
    .btn-mode-baru-ungu {
        background: linear-gradient(135deg, #8b5cf6, #7c3aed) !important;
        color: white !important;
        border: none !important;
        box-shadow: 0 2px 6px rgba(139, 92, 246, 0.3);
    }

    .btn-mode-baru-ungu:hover {
        background: linear-gradient(135deg, #7c3aed, #6d28d9) !important;
        transform: translateY(-1px);
        box-shadow: 0 4px 8px rgba(139, 92, 246, 0.4);
    }

    /* Atau dengan warna orange */
    .btn-mode-baru-orange {
        background: linear-gradient(135deg, #f59e0b, #d97706) !important;
        color: white !important;
        border: none !important;
        box-shadow: 0 2px 6px rgba(245, 158, 11, 0.3);
    }

    .btn-mode-baru-orange:hover {
        background: linear-gradient(135deg, #d97706, #b45309) !important;
        transform: translateY(-1px);
        box-shadow: 0 4px 8px rgba(245, 158, 11, 0.4);
    }

        /* Tombol Hapus Mode */
    .mode-delete-icon {
        display: inline-flex;
        align-items: center;
        justify-content: center;
        width: 28px;
        height: 28px;
        border-radius: 4px;
        cursor: pointer;
        transition: all 0.2s;
        color: #dc2626;
        background: transparent;
        margin-left: 2px;
    }

    .mode-delete-icon:hover {
        background: #fee2e2;
        color: #b91c1c;
    }

    .mode-delete-icon i {
        font-size: 0.9rem;
    }

    /* Untuk mode aktif */
    .btn-p .mode-delete-icon {
        color: #fff;
        background: rgba(255,255,255,0.1);
    }

    .btn-p .mode-delete-icon:hover {
        background: rgba(220, 38, 38, 0.8);
        color: white;
    }

    /* Group button dengan 3 bagian */
    .mode-btn-group-triple {
        display: inline-flex;
        align-items: center;
        margin-right: 8px;
        margin-bottom: 5px;
    }

    .mode-btn-group-triple .btn:first-child {
        border-top-right-radius: 0;
        border-bottom-right-radius: 0;
        border-right: 0;
    }

    .mode-btn-group-triple .btn.mode-edit-btn {
        border-radius: 0;
        border-right: 0;
        padding: 6px 8px;
    }

    .mode-btn-group-triple .btn.mode-delete-btn {
        border-top-left-radius: 0;
        border-bottom-left-radius: 0;
        padding: 6px 8px;
    }

    .mode-btn-group-triple .btn-p.mode-delete-btn {
        border-left-color: rgba(255,255,255,0.2);
    }

    /* Container mode buttons */
    .mode-list-container {
        display: flex;
        flex-wrap: wrap;
        gap: 8px;
        align-items: center;
    }

    .mode-selector {
        background: #f8fafc;
        border-radius: 8px;
        padding: 16px;
        margin-bottom: 16px;
        border: 1px solid #e5e7eb;
    }

    .mode-badge {
        display: inline-flex;
        align-items: center;
        padding: 6px 16px;
        background: var(--primary);
        color: white;
        border-radius: 20px;
        font-size: 0.75rem;
        font-weight: 500;
        margin-right: 8px;
    }

    /* NPK Suggestions */
    .npk-suggestions {
        position: absolute;
        background: white;
        border: 1px solid #e5e7eb;
        border-radius: 6px;
        max-height: 150px;
        overflow-y: auto;
        width: 100%;
        z-index: 1000;
        box-shadow: 0 4px 12px rgba(0,0,0,0.1);
    }

    .npk-suggestions div {
        padding: 6px 10px;
        cursor: pointer;
        font-size: 0.75rem;
    }

    .npk-suggestions div:hover {
        background: var(--primary-hover-bg);
        color: var(--primary);
    }

    /* Import modal */
    #importUsersModal .modal-box {
        max-width: 60vw !important;
        width: 60vw !important;
        min-width: 700px;
        max-height: 80vh;
        display: flex;
        flex-direction: column;
        padding: 24px;
    }

    #importUsersModal .table-responsive {
        max-height: calc(80vh - 200px);
        overflow-y: auto;
        border: 1px solid #e5e7eb;
        border-radius: 8px;
    }

    #importUsersModal table th {
        font-size: 0.85rem;
        padding: 12px 8px;
    }

    #importUsersModal table td {
        padding: 10px 8px;
        font-size: 0.85rem;
    }

    .user-check-col {
        width: 50px;
        text-align: center;
    }
    
    .user-check-col input[type="checkbox"] {
        width: 18px;
        height: 18px;
        cursor: pointer;
    }

    .btn-sm {
        padding: 6px 12px !important;
        font-size: 0.85rem !important;
    }

    /* Search input */
    #memberSearch, #userSearch {
        padding: 8px 12px;
        font-size: 0.85rem;
        width: 250px !important; /* Lebih lebar */
    }

    /* Footer info */
    #modalotmember .mt-3,
    #importUsersModal .mt-3 {
        margin-top: 20px !important;
        font-size: 0.85rem;
    }

    /* Styling untuk tabel dengan sticky header dan kolom aksi sticky */
    #page-ot-budget .table {
        margin-bottom: 0;
        border-collapse: separate;
        border-spacing: 0;
    }

    #page-ot-budget .table tbody tr td {
        padding: 1px 8px !important;  /* Padding vertikal 2px, horizontal 8px */
        line-height: 1.2;             /* Line height lebih kecil */
        height: 30px;                 /* Atur tinggi minimal (opsional) */
    }

    #page-ot-budget .table thead th {
        border-bottom: 2px solid #dee2e6;
        font-weight: 600;
        color:rgb(255, 255, 255);
        vertical-align: middle;
    }

    #page-ot-budget .table tbody td {
        vertical-align: middle;
        background: white;
        padding: 4px 8px !important;
        line-height: 0.5
    }

    /* Kolom aksi sticky di kanan */
    #page-ot-budget .table tbody td:last-child {
        background: white;
        box-shadow: -4px 0 8px rgba(0,0,0,0.05);
    }

    /* Hover effect untuk baris */
    #page-ot-budget .table tbody tr:hover td {
        background-color: #f8fafc;
    }

    #page-ot-budget .table tbody tr:hover td:last-child {
        background-color: #f8fafc;
    }

    /* Badge styling */
    #page-ot-budget .badge {
        font-size: 0.7rem;
        font-weight: 500;
        padding: 4px 8px;
    }

    /* Scrollbar styling */
    #page-ot-budget .position-relative::-webkit-scrollbar {
        width: 8px;
        height: 8px;
    }

    #page-ot-budget .position-relative::-webkit-scrollbar-track {
        background: #f1f1f1;
        border-radius: 4px;
    }

    #page-ot-budget .position-relative::-webkit-scrollbar-thumb {
        background: #cbd5e0;
        border-radius: 4px;
    }

    #page-ot-budget .position-relative::-webkit-scrollbar-thumb:hover {
        background: #94a3b8;
    }

    /* Responsive untuk layar kecil */
    @media (max-width: 1200px) {
        #modalotmember .modal-box {
            max-width: 90vw !important;
            min-width: auto;
        }
        
        #importUsersModal .modal-box {
            max-width: 80vw !important;
            min-width: auto;
        }
    }

    @media (max-width: 768px) {
        #modalotmember .modal-box {
            max-width: 95vw !important;
            width: 95vw !important;
        }
        
        #importUsersModal .modal-box {
            max-width: 90vw !important;
            width: 90vw !important;
        }
        
        #memberSearch, #userSearch {
            width: 180px !important;
        }
    }
</style>

<head>
    <link href="/best-root/public/bootstrap-5.3.8/css/bootstrap.min.css" rel="stylesheet">

    <!-- Bootstrap JS (opsional, untuk komponen interaktif) -->
    <script src="/best-root/public/bootstrap-5.3.8/js/bootstrap.bundle.min.js"></script>
</head>
<body>
    <!-- ======== OVERTIME BUDGET KOMPLEKS ======== -->
    <div class="page" id="page-ot-budget">
        <div class="mb-4 d-flex justify-content-between align-items-start flex-wrap gap-2">
            <div>
                <div class="page-heading">Overtime — Budget Kompleks</div>
                <div class="page-sub">Kelola budget dengan member, rate, dan multiplier</div>
            </div>
            <div class="d-flex gap-2">
                <button class="btn-o" onclick="otb_openMultiplierModal()">
                    <i class="bi bi-sliders2"></i> Set Multiplier
                </button>
                <button class="btn-p" onclick="otb_openMemberModal()">
                    <i class="bi bi-people"></i> Kelola Member
                </button>
                <button class="btn-p" onclick="otb_openModal()">
                    <i class="bi bi-plus"></i> Set Budget
                </button>
            </div>
        </div>

        <!-- Info Rate & Multiplier -->
        <div class="row g-3 mb-3">
            <!-- Card 1: Rata-rata Rate -->
            <div class="col-6 col-lg-3">
                <div class="stat-card">
                    <div class="stat-icon" style="background:#eef2ff;">
                        <i class="bi bi-calculator" style="color:#4f46e5;"></i>
                    </div>
                    <div>
                        <div class="stat-value" id="stat-avg-rate">Rp <?= number_format($avg_rate, 0, ',', '.') ?></div>
                        <div class="stat-label">Rata-rata Rate/Jam</div>
                        <div class="stat-change text-primary">Dari <?= count($members) ?> member</div>
                    </div>
                </div>
            </div>
            
            <!-- Card 2: Multiplier -->
            <div class="col-6 col-lg-3">
                <div class="stat-card">
                    <div class="stat-icon" style="background:#f0fdf4;">
                        <i class="bi bi-arrow-repeat" style="color:#16a34a;"></i>
                    </div>
                    <div>
                        <div class="stat-value" id="stat-multiplier"><?= $multiplier ?>x</div>
                        <div class="stat-label">Multiplier</div>
                        <div class="stat-change text-success">Tahun <?= $tahun_ini ?></div>
                    </div>
                </div>
            </div>
            
            <!-- Card 3: Total Target Amount -->
            <div class="col-6 col-lg-3">
                <div class="stat-card">
                    <div class="stat-icon" style="background:#fffbeb;">
                        <i class="bi bi-flag" style="color:#d97706;"></i>
                    </div>
                    <div>
                        <div class="stat-value" id="stat-target-amount">Rp <?= number_format($total_target_amount, 0, ',', '.') ?></div>
                        <div class="stat-label">Total Target Amount</div>
                        <div class="stat-change" style="color:#d97706;" id="stat-target-percent"><?= round(($total_target_amount / max($total_amount_budget, 1)) * 100, 1) ?>% dari budget</div>
                    </div>
                </div>
            </div>
            
            <!-- Card 4: Total Target Jam -->
            <div class="col-6 col-lg-3">
                <div class="stat-card">
                    <div class="stat-icon" style="background:#f5f3ff;">
                        <i class="bi bi-clock-history" style="color:#7c3aed;"></i>
                    </div>
                    <div>
                        <div class="stat-value" id="stat-target-jam"><?= number_format($total_target_jam, 0) ?> jam</div>
                        <div class="stat-label">Total Target Jam</div>
                        <div class="stat-change" style="color:#7c3aed;">Target jam member</div>
                    </div>
                </div>
            </div>
        </div>
        <!-- Tabel Budget per Bulan dengan Bootstrap -->
        <div class="content-card">
            <div class="card-hdr">
                <h5><i class="bi bi-table me-2" style="color:#818cf8;"></i>Rincian Budget & Target — <?= $tahun_ini ?></h5>
            </div>
            
            <!-- Container dengan posisi relative untuk header sticky -->
            <div class="position-relative" style="max-height: 600px; overflow: auto;">
                <!-- Tabel dengan border vertical (dari Bootstrap) dan border horizontal tipis (custom) -->
                <table class="table table-bordered table-hover align-middle table-sm" style="font-size:0.75rem; min-width: 1200px; border-collapse: collapse;">
                    <thead style="position: sticky; top: 0; z-index: 10; background: #f8fafc;">
                        <tr>
                            <th style="width: 80px; background: #818cf8; color: white;">Bulan</th>
                            <th style="width: 100px; background: #818cf8; color: white;">Budget Jam</th>
                            <th style="width: 120px; background: #818cf8; color: white;">Budget Amount</th>
                            <th style="width: 80px; background: #818cf8; color: white;">Target %</th>
                            <th style="width: 120px; background: #818cf8; color: white;">Target Amount</th>
                            <th style="width: 100px; background: #818cf8; color: white;">Target Jam</th>
                            <th style="width: 100px; background: #818cf8; color: white;">Realisasi Jam*</th>
                            <th style="width: 100px; background: #818cf8; color: white;">Achievement %</th>
                            <th style="width: 120px; background: #818cf8; color: white; position: sticky; right: 0;">Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php 
                        foreach ($nama_bulan as $i => $bln): 
                            $jam_budget = $ot_budget_per_bulan[$i];
                            $amount_budget = $ot_amount_per_bulan[$i];
                            $target_percent = $ot_target_percent_per_bulan[$i];
                            $target_amount = $ot_target_amount_per_bulan[$i];
                            $target_jam = $ot_target_jam_per_bulan[$i];
                            $realisasi = $total_realisasi[$i] ?? 0;
                            $achievement = $target_jam > 0 ? round(($realisasi / $target_jam) * 100, 1) : 0;
                            $isEmpty = $jam_budget == 0 && $amount_budget == 0;
                        ?>
                        <tr>
                            <td><strong><?= $bln ?></strong></td>
                            <td class="budget-jam-<?= $i ?>"><?= $isEmpty ? '<span class="text-muted">—</span>' : number_format($jam_budget, 0) . ' jam' ?></td>
                            <td class="budget-amount-<?= $i ?>"><?= $isEmpty ? '<span class="text-muted">—</span>' : 'Rp ' . number_format($amount_budget, 0, ',', '.') ?></td>
                            <td class="target-percent-<?= $i ?>"><?= $isEmpty ? '<span class="text-muted">—</span>' : $target_percent . '%' ?></td>
                            <td class="target-amount-<?= $i ?>"><?= $isEmpty ? '<span class="text-muted">—</span>' : 'Rp ' . number_format($target_amount, 0, ',', '.') ?></td>
                            <td class="target-jam-<?= $i ?>"><?= $isEmpty ? '<span class="text-muted">—</span>' : number_format($target_jam, 1) . ' jam' ?></td>
                            <td><?= $isEmpty ? '<span class="text-muted">—</span>' : number_format($realisasi, 0) . ' jam' ?></td>
                            <td>
                                <?php if (!$isEmpty && $target_jam > 0): ?>
                                    <span class="badge <?= $achievement >= 100 ? 'bg-success' : ($achievement >= 80 ? 'bg-warning' : 'bg-danger') ?>">
                                        <?= $achievement ?>%
                                    </span>
                                <?php else: ?>
                                    <span class="text-muted">—</span>
                                <?php endif; ?>
                            </td>
                            <td style="position: sticky; right: 0; background: white;">
                                <div class="d-flex gap-1">
                                    <button class="btn btn-sm btn-outline-primary" style="padding:2px 6px;font-size:0.7rem;"
                                        onclick="otb_openModal(<?= $i + 1 ?>, <?= $jam_budget ?>, <?= $amount_budget ?>, <?= $target_percent ?>, <?= $target_amount ?>, <?= $target_jam ?>)"
                                        title="Edit Budget">
                                        <i class="bi bi-pencil"></i>
                                    </button>
                                    
                                    <?php if (!$isEmpty): ?>
                                    <button class="btn btn-sm btn-outline-info" style="padding:2px 6px;font-size:0.7rem;"
                                        onclick="otb_openMemberTargetModal(<?= $i + 1 ?>)"
                                        title="Target Member">
                                        <i class="bi bi-people"></i>
                                    </button>
                                    
                                    <button class="btn btn-sm btn-outline-danger" style="padding:2px 6px;font-size:0.7rem;"
                                        onclick="otb_confirmDelete(<?= $i + 1 ?>, '<?= $bln ?>')"
                                        title="Hapus Budget Bulan Ini">
                                        <i class="bi bi-trash"></i>
                                    </button>
                                    <?php endif; ?>
                                </div>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
            
            <!-- Footer dengan summary -->
            <div class="mt-3 d-flex justify-content-between align-items-center">
                <div class="text-muted" style="font-size:0.7rem;">
                    <i class="bi bi-info-circle"></i>
                    * Realisasi jam diambil dari pengajuan yang sudah disetujui
                </div>
                <div class="bg-light p-2 rounded" style="font-size:0.75rem;">
                    <strong>Total Budget:</strong> Rp <?= number_format($total_amount_budget, 0, ',', '.') ?> | 
                    <strong>Total Target:</strong> Rp <?= number_format($total_target_amount, 0, ',', '.') ?>
                </div>
            </div>
        </div>
    <!-- MODAL: Set Budget -->
    <div class="modal-overlay" id="modalotbudget" style="display:none;">
        <div class="modal-box" style="max-width:550px; width:100%; max-height:80vh; display:flex; flex-direction:column;">
            <!-- Header - Fixed -->
            <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:15px; padding-bottom:10px; border-bottom:2px solid #f0f0f0; flex-shrink:0;">
                <h5 style="font-weight:700; margin:0; color:#374151; font-size:1.1rem;">
                    <i class="bi bi-wallet2 me-2" style="color:#4f46e5;"></i>
                    Set Budget & Target
                </h5>
                <button onclick="otb_closeModal()" style="background:none; border:none; font-size:1.3rem; cursor:pointer; color:#9ca3af; hover:color:#374151;">×</button>
            </div>
            
            <!-- Scrollable Content -->
            <div style="overflow-y:auto; flex:1; padding-right:5px;">
                <!-- Form Grid 2 Kolom -->
                <div class="row g-2"> <!-- Kurangi gap -->
                    <!-- Kolom Kiri -->
                    <div class="col-md-6">
                        <div class="mb-2"> <!-- Kurangi margin bottom -->
                            <label class="flbl" style="font-size:0.75rem;">
                                <i class="bi bi-calendar3 me-1" style="color:#4f46e5;"></i>
                                Tahun
                            </label>
                            <input type="number" class="finp" id="otb_tahun" value="<?= $tahun_ini ?>" min="2020" max="2099" style="padding:6px 10px; font-size:0.8rem;">
                        </div>
                        
                        <div class="mb-2">
                            <label class="flbl" style="font-size:0.75rem;">
                                <i class="bi bi-calendar-month me-1" style="color:#4f46e5;"></i>
                                Bulan
                            </label>
                            <select class="finp" id="otb_bulan" style="padding:6px 10px; font-size:0.8rem;">
                                <?php foreach ($nama_bulan as $i => $bln): ?>
                                <option value="<?= $i + 1 ?>"><?= $bln ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        
                        <div class="mb-2">
                            <label class="flbl" style="font-size:0.75rem;">
                                <i class="bi bi-cash-stack me-1" style="color:#4f46e5;"></i>
                                Budget Amount (Rp)
                            </label>
                            <input type="number" class="finp" id="otb_amount" min="0" step="1000" 
                                placeholder="Contoh: 1000000" oninput="otb_hitungTarget()" 
                                style="padding:6px 10px; font-size:0.8rem;">
                        </div>
                    </div>
                    
                    <!-- Kolom Kanan -->
                    <div class="col-md-6">
                        <div class="mb-2">
                            <label class="flbl" style="font-size:0.75rem;">
                                <i class="bi bi-diagram-3 me-1" style="color:#4f46e5;"></i>
                                Mode Member
                            </label>
                            <select class="finp" id="otb_mode_member" onchange="otb_changeMode()" style="padding:6px 10px; font-size:0.8rem;">
                                <option value="">-- Pilih Mode --</option>
                            </select>
                        </div>
                        
                        <div class="mb-2">
                            <label class="flbl" style="font-size:0.75rem;">
                                <i class="bi bi-percent me-1" style="color:#4f46e5;"></i>
                                Target %
                            </label>
                            <div class="d-flex align-items-center gap-2">
                                <input type="number" class="finp" id="otb_target_percent" min="0" max="100" 
                                    step="0.1" value="80" oninput="otb_hitungTarget()" 
                                    style="padding:6px 10px; font-size:0.8rem; flex:1;">
                                <span style="font-size:0.9rem; color:#6b7280;">%</span>
                            </div>
                        </div>
                        
                        <div class="mb-2">
                            <label class="flbl" style="font-size:0.75rem;">
                                <i class="bi bi-pencil me-1" style="color:#4f46e5;"></i>
                                Keterangan
                            </label>
                            <textarea class="finp" id="otb_keterangan" rows="1" placeholder="Opsional..." 
                                    style="padding:6px 10px; font-size:0.8rem;"></textarea>
                        </div>
                    </div>
                </div>
                
                <!-- Info Rate & Multiplier - Compact -->
                <div class="row g-2 my-1">
                    <div class="col-12">
                        <div style="background: linear-gradient(135deg, #f8fafc, #f1f5f9); border-radius:8px; padding:10px; border:1px solid #e5e7eb;">
                            <div class="row">
                                <div class="col-6 text-center border-end">
                                    <div style="font-size:0.65rem; color:#6b7280;">
                                        <i class="bi bi-calculator me-1"></i>Rata-rata Rate
                                    </div>
                                    <div style="font-size:1rem; font-weight:600; color:#4f46e5;" id="otb_avg_rate_display">
                                        Rp <?= number_format($avg_rate, 0, ',', '.') ?>
                                    </div>
                                </div>
                                <div class="col-6 text-center">
                                    <div style="font-size:0.65rem; color:#6b7280;">
                                        <i class="bi bi-arrow-repeat me-1"></i>Multiplier
                                    </div>
                                    <div style="font-size:1rem; font-weight:600; color:#16a34a;" id="otb_multiplier_display">
                                        <?= $multiplier ?>x
                                    </div>
                                </div>
                            </div>
                            <div class="mt-1 text-center">
                                <span style="font-size:0.6rem; color:#6b7280; background:white; padding:2px 8px; border-radius:12px;">
                                    <i class="bi bi-info-circle me-1"></i>
                                    Target = Amount × % / (Rate × Multiplier)
                                </span>
                            </div>
                        </div>
                    </div>
                </div>
                
                <!-- Hasil Perhitungan - Compact -->
                <div class="row g-2 mt-1">
                    <div class="col-6">
                        <div style="background:#f0fdf4; border-radius:8px; padding:10px; border:1px solid #dcfce7;">
                            <div style="font-size:0.65rem; color:#16a34a;">
                                <i class="bi bi-check-circle-fill me-1"></i>Target Amount
                            </div>
                            <div style="font-size:1rem; font-weight:600; color:#166534;" id="otb_target_amount_display">
                                Rp 0
                            </div>
                            <input type="hidden" id="otb_target_amount" value="0">
                        </div>
                    </div>
                    <div class="col-6">
                        <div style="background:#eef2ff; border-radius:8px; padding:10px; border:1px solid #e0e7ff;">
                            <div style="font-size:0.65rem; color:#4f46e5;">
                                <i class="bi bi-clock-fill me-1"></i>Target Jam
                            </div>
                            <div style="font-size:1rem; font-weight:600; color:#3730a3;" id="otb_target_jam_display">
                                0 jam
                            </div>
                            <input type="hidden" id="otb_target_jam" value="0">
                        </div>
                    </div>
                </div>
            </div>
            
            <!-- Footer - Fixed -->
            <div class="d-flex gap-2 justify-content-end mt-3 pt-2" style="border-top:1px solid #f0f0f0; flex-shrink:0;">
                <button class="btn-o" onclick="otb_closeModal()" style="padding:5px 15px; font-size:0.8rem;">
                    <i class="bi bi-x-lg me-1"></i>Batal
                </button>
                <button class="btn-p" onclick="otb_simpan()" style="padding:5px 20px; font-size:0.8rem;">
                    <i class="bi bi-check2 me-1"></i>Simpan
                </button>
            </div>
        </div>
    </div>

    <!-- MODAL: Kelola Member dengan Mode -->
    <div class="modal-overlay" id="modalotmember" style="display:none;">
        <div class="modal-box">
            <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:18px;">
                <h6 style="font-weight:700;margin:0;">
                    <i class="bi bi-people me-2" style="color:#4f46e5;"></i>
                    Kelola Member & Rate
                </h6>
                <button onclick="otb_closeMemberModal()" style="background:none;border:none;font-size:1.1rem;cursor:pointer;">×</button>
            </div>
            
            <!-- Mode Selector -->
            <div class="mode-selector">
                <div class="d-flex align-items-center gap-3 flex-wrap">
                    <div class="d-flex align-items-center gap-2">
                        <i class="bi bi-diagram-3" style="color:#4f46e5;"></i>
                        <span style="font-weight:600;font-size:0.85rem;">Data Mode:</span>
                    </div>
                    <div class="d-flex gap-2 flex-wrap" id="modeList">
                        <!-- Mode akan di-load via JavaScript -->
                    </div>
                    <button class="btn btn-sm btn-mode-baru" onclick="otb_addMode()" style="margin-left:auto;">
                        <i class="bi bi-plus"></i> Mode Baru
                    </button>
                </div>
                
                <!-- Info Mode Aktif -->
                <div class="mt-2 d-flex align-items-center gap-3" id="modeInfo">
                    <span class="mode-badge" id="activeModeBadge">Mode: Default</span>
                    <span style="font-size:0.75rem;color:#6b7280;" id="modePeriod"></span>
                    <span style="font-size:0.75rem;color:#6b7280;" id="memberCount"></span>
                </div>
            </div>
            
            <!-- Toolbar -->
            <div class="d-flex justify-content-between align-items-center mb-3">
                <div class="d-flex gap-2">
                    <button class="btn-p btn-sm" onclick="otb_addMemberRow()">
                        <i class="bi bi-plus"></i> Tambah Member
                    </button>
                    <button class="btn-o btn-sm" onclick="otb_importFromUsers()">
                        <i class="bi bi-download"></i> Import dari Users
                    </button>
                    <button class="btn-o btn-sm" onclick="otb_duplicateMode()">
                        <i class="bi bi-copy"></i> Duplikasi Mode
                    </button>
                </div>
                <div class="d-flex gap-2">
                    <input type="text" class="finp" placeholder="Cari member..." 
                        style="width:200px;font-size:0.8rem;" 
                        id="memberSearch" onkeyup="otb_searchMember()">
                </div>
            </div>
            
            <!-- Table Member -->
            <div class="table-responsive">
                <table class="table" id="memberTable">
                    <thead>
                        <tr>
                            <th width="15%">NPK</th>
                            <th width="30%">Nama</th>
                            <th width="20%">Rate/Jam (Rp)</th>
                            <th width="15%">Status</th>
                            <th width="20%">Aksi</th>
                        </tr>
                    </thead>
                    <tbody id="memberTableBody">
                        <!-- Akan diisi via JavaScript -->
                    </tbody>
                </table>
            </div>
            
            <!-- Footer -->
            <div class="d-flex justify-content-between align-items-center mt-3">
                <div style="font-size:0.75rem;color:#6b7280;">
                    <i class="bi bi-info-circle"></i>
                    Total Member: <span id="totalMemberCount">0</span> | 
                    Rata-rata Rate: Rp <span id="avgRateDisplay">0</span>
                </div>
                <div class="d-flex gap-2">
                    <button class="btn-o" onclick="otb_closeMemberModal()">Batal</button>
                    <button class="btn-p" onclick="otb_simpanMembers()">
                        <i class="bi bi-save"></i> Simpan Mode Ini
                    </button>
                    <button class="btn-p" onclick="otb_saveAllModes()">
                        <i class="bi bi-cloud-check"></i> Simpan Semua Mode
                    </button>
                </div>
            </div>
        </div>
    </div>

    <!-- MODAL: Import dari Users -->
    <div class="modal-overlay" id="importUsersModal" style="display:none;">
        <div class="modal-box" style="max-width:500px;">
            <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:18px;">
                <h6 style="font-weight:700;margin:0;">
                    <i class="bi bi-person-plus me-2" style="color:#4f46e5;"></i>
                    Import dari Users
                </h6>
                <button onclick="otb_closeImportModal()" style="background:none;border:none;font-size:1.1rem;">×</button>
            </div>
            
            <div class="mb-3">
                <input type="text" class="finp" placeholder="Cari user..." 
                    id="userSearch" onkeyup="otb_searchUsers()">
            </div>
            
            <div class="table-responsive" style="max-height:300px;">
                <table class="table table-sm">
                    <thead>
                        <tr>
                            <th class="user-check-col"><input type="checkbox" id="selectAllUsers" onchange="otb_toggleSelectAll()"></th>
                            <th>NPK</th>
                            <th>Nama</th>
                            <th>Role</th>
                        </tr>
                    </thead>
                    <tbody id="userListBody">
                        <!-- Akan diisi via JavaScript -->
                    </tbody>
                </table>
            </div>
            
            <div class="d-flex gap-2 justify-content-end mt-3">
                <button class="btn-o" onclick="otb_closeImportModal()">Batal</button>
                <button class="btn-p" onclick="otb_importSelectedUsers()">
                    <i class="bi bi-check2"></i> Import Selected
                </button>
            </div>
        </div>
    </div>

    <!-- MODAL: Tambah/Edit Mode -->
    <div class="modal-overlay" id="addModeModal" style="display:none;">
        <div class="modal-box" style="max-width:400px;">
            <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:18px;">
                <h6 style="font-weight:700;margin:0;">
                    <i class="bi bi-diagram-3 me-2" style="color:#4f46e5;"></i>
                    <span id="modeModalTitle">Tambah Mode Baru</span>
                </h6>
                <button onclick="otb_closeModeModal()" style="background:none;border:none;font-size:1.1rem;">×</button>
            </div>
            
            <div class="row g-3">
                <div class="col-12">
                    <label class="flbl">Nama Mode</label>
                    <input type="text" class="finp" id="modeName" 
                        placeholder="Contoh: Jan-Feb 2025">
                </div>
                <div class="col-6">
                    <label class="flbl">Periode Mulai</label>
                    <input type="month" class="finp" id="modeStart">
                </div>
                <div class="col-6">
                    <label class="flbl">Periode Selesai</label>
                    <input type="month" class="finp" id="modeEnd">
                </div>
                <div class="col-12">
                    <label class="flbl">Keterangan</label>
                    <textarea class="finp" id="modeDescription" rows="2"></textarea>
                </div>
            </div>
            
            <div class="d-flex gap-2 justify-content-end mt-3">
                <button class="btn-o" onclick="otb_closeModeModal()">Batal</button>
                <button class="btn-p" onclick="otb_saveMode()">
                    <i class="bi bi-save"></i> Simpan Mode
                </button>
            </div>
        </div>
    </div>

    <!-- MODAL: Set Multiplier -->
    <div class="modal-overlay" id="modalOTMultiplier" style="display:none;">
        <div class="modal-box" style="max-width:350px;">
            <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:18px;">
                <h6 style="font-weight:700;margin:0;"><i class="bi bi-sliders2 me-2" style="color:#4f46e5;"></i>Set Multiplier</h6>
                <button onclick="otb_closeMultiplierModal()" style="background:none;border:none;font-size:1.1rem;cursor:pointer;">×</button>
            </div>
            <div class="row g-3">
                <div class="col-12">
                    <label class="flbl">Tahun</label>
                    <input type="number" class="finp" id="otb_mult_tahun" 
                        value="<?= $tahun_ini ?>" min="2020" max="2099"
                        onchange="otb_loadMultiplierData()">
                    <small class="text-muted">* Bisa diisi untuk tahun berjalan atau tahun depan</small>
                </div>
                <div class="col-12">
                    <label class="flbl">Multiplier (x)</label>
                    <input type="number" class="finp" id="otb_multiplier" 
                        value="<?= $multiplier ?? 1.5 ?>" min="1" max="3" step="0.1">
                    <small class="text-muted">Contoh: 1.5 (1.5x), 2 (2x)</small>
                </div>
                <div class="col-12">
                    <label class="flbl">Keterangan</label>
                    <textarea class="finp" id="otb_mult_keterangan" rows="2">Multiplier tahun <?= $tahun_ini ?></textarea>
                </div>
            </div>
            <div class="d-flex gap-2 justify-content-end mt-3">
                <button class="btn-o" onclick="otb_closeMultiplierModal()">Batal</button>
                <button class="btn-p" onclick="otb_simpanMultiplier()"><i class="bi bi-check2"></i> Simpan</button>
            </div>
        </div>
    </div>

    <!-- MODAL: Target per Member -->
    <div class="modal-overlay" id="modalotmemberTarget" style="display:none;">
        <div class="modal-box" style="max-width:500px;">
            <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:18px;">
                <h6 style="font-weight:700;margin:0;"><i class="bi bi-people me-2" style="color:#4f46e5;"></i>Target Jam per Member</h6>
                <button onclick="otb_closeMemberTargetModal()" style="background:none;border:none;font-size:1.1rem;">×</button>
            </div>
            <div id="memberTargetList" class="mb-3" style="max-height:300px;overflow-y:auto;">
                <!-- Akan diisi via JavaScript -->
            </div>
            <div class="d-flex gap-2 justify-content-end">
                <button class="btn-o" onclick="otb_closeMemberTargetModal()">Tutup</button>
                <button class="btn-p" onclick="otb_simpanMemberTargets()"><i class="bi bi-save"></i> Simpan Target</button>
            </div>
        </div>
    </div>
</body>

<script>
// Data dari PHP
const OTB_MEMBERS = <?= json_encode($members) ?: '[]' ?>;
const OTB_AVG_RATE = <?= $avg_rate ?: 0 ?>;
const OTB_MULTIPLIER = <?= $multiplier ?: 1.5 ?>;

// Debug untuk cek data
console.log('Data dari PHP:', {
    members: OTB_MEMBERS,
    avg_rate: OTB_AVG_RATE,
    multiplier: OTB_MULTIPLIER,
    members_count: OTB_MEMBERS ? OTB_MEMBERS.length : 0
});

// Inisialisasi chart
function loadPage(pageId) {
    console.log('Loading page:', pageId);
    
    // Hapus class active dari semua page
    document.querySelectorAll('.page').forEach(p => p.classList.remove('active'));
    
    // Tampilkan page yang dipilih
    const targetPage = document.getElementById('page-' + pageId);
    if (targetPage) {
        targetPage.classList.add('active');
        
        // Update page title
        document.getElementById('pageTitle').textContent = pageTitles[pageId] || pageId;
        
        // Update active state di navigation
        updateNavActiveState(pageId);
        
        // Update tabs
        addTab(pageId);
        
        // Inisialisasi komponen khusus halaman
        if (pageId === 'ot-budget' && typeof initCharts === 'function') {
            // Beri sedikit waktu agar DOM siap
            setTimeout(() => {
                initCharts();
                refreshBudgetData();
            }, 100);
        }
        
        // Trigger custom event untuk halaman yang dimuat
        window.dispatchEvent(new CustomEvent('pageLoaded', { detail: { pageId: pageId } }));
    } else {
        console.error('Page not found:', pageId);
        document.getElementById('page-home').classList.add('active');
        document.getElementById('pageTitle').textContent = 'Home';
    }
}

// Fungsi inisialisasi chart
function initCharts() {
    // Hanya inisialisasi jika chart belum ada
    if (!window.budgetJamChart) {
        const ctxJam = document.getElementById('chartBudgetJam');
        const ctxAmount = document.getElementById('chartBudgetAmount');
        
        if (ctxJam) {
            window.budgetJamChart = new Chart(ctxJam.getContext('2d'), {
                type: 'bar',
                data: {
                    labels: <?= json_encode(array_map(fn($b) => substr($b, 0, 3), $nama_bulan)) ?>,
                    datasets: [{
                        label: 'Budget Jam',
                        data: <?= json_encode($ot_budget_per_bulan) ?>,
                        backgroundColor: '#4f46e5bb',
                        borderColor: '#4f46e5',
                        borderWidth: 1.5,
                        borderRadius: 5,
                        barPercentage: 0.6,
                    }]
                },
                options: {
                    responsive: true, maintainAspectRatio: false,
                    plugins: { legend: { display: false } },
                    scales: {
                        x: { grid: { display: false }, ticks: { font: { size: 10 }, color: '#6b7280' } },
                        y: {
                            beginAtZero: true, grid: { color: '#f3f4f6' },
                            ticks: { font: { size: 10 }, color: '#6b7280', callback: v => v + 'h' }
                        }
                    }
                }
            });
        }
        
        if (ctxAmount) {
            window.budgetAmountChart = new Chart(ctxAmount.getContext('2d'), {
                type: 'bar',
                data: {
                    labels: <?= json_encode(array_map(fn($b) => substr($b, 0, 3), $nama_bulan)) ?>,
                    datasets: [{
                        label: 'Budget Amount',
                        data: <?= json_encode($ot_amount_per_bulan) ?>,
                        backgroundColor: '#16a34abb',
                        borderColor: '#16a34a',
                        borderWidth: 1.5,
                        borderRadius: 5,
                        barPercentage: 0.6,
                    }]
                },
                options: {
                    responsive: true, maintainAspectRatio: false,
                    plugins: { legend: { display: false } },
                    scales: {
                        x: { grid: { display: false }, ticks: { font: { size: 10 }, color: '#6b7280' } },
                        y: {
                            beginAtZero: true, grid: { color: '#f3f4f6' },
                            ticks: {
                                font: { size: 10 }, color: '#6b7280',
                                callback: v => 'Rp ' + (v >= 1000000
                                    ? (v / 1000000).toFixed(1) + 'jt'
                                    : (v / 1000).toFixed(0) + 'rb')
                            }
                        }
                    },
                    plugins: {
                        tooltip: {
                            callbacks: {
                                label: ctx => 'Rp ' + ctx.parsed.y.toLocaleString('id-ID')
                            }
                        }
                    }
                }
            });
        }
    }
}

// Fungsi refresh data budget
function refreshBudgetData() {
    const tahun = document.getElementById('otb_tahun')?.value || <?= $tahun_ini ?>;
    
    // Tampilkan loading state di card
    showLoadingState();
    
    fetch(`/best-root/public/overtime/budget/data?tahun=${tahun}`)
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                // Update semua elemen dengan data dari server
                updateAllData(data);
            }
        })
        .catch(error => {
            console.error('Error refresh data:', error);
            hideLoadingState();
        });
}

// Fungsi untuk update semua data sekaligus
function updateAllData(data) {
    // Update tabel
    updateBudgetTable(data.rows, data.chart);
    
    // Update summary cards dengan data dari server
    const statCards = document.querySelectorAll('#page-ot-budget .stat-card');
    
    if (statCards.length >= 4) {
        // Card 1: Rata-rata Rate
        const avgRate = (data.avg_rate && data.avg_rate > 0) 
        ? data.avg_rate 
        : (window.OTB_AVG_RATE > 0 ? window.OTB_AVG_RATE : OTB_AVG_RATE);
        const rateValueEl = statCards[0].querySelector('.stat-value');
        if (rateValueEl) {
            if (avgRate > 0) {  // ← tambahkan guard ini
                rateValueEl.innerHTML = formatCurrency(avgRate);
            }
            // jika 0, biarkan tampilan PHP yang sudah benar
        }
        
        // Card 2: Multiplier
        const multiplierValueEl = statCards[1].querySelector('.stat-value');
        if (multiplierValueEl && data.multiplier) {
            multiplierValueEl.innerHTML = formatMultiplier(data.multiplier);
            window.OTB_MULTIPLIER = data.multiplier;
        }
        
        // Card 3: Total Target Amount
        const targetAmountEl = statCards[2].querySelector('.stat-value');
        if (targetAmountEl && data.summary?.total_target_amount !== undefined) {
            targetAmountEl.innerHTML = formatCurrency(data.summary.total_target_amount);
        }
        
        // Card 4: Total Target Jam
        const targetJamEl = statCards[3].querySelector('.stat-value');
        if (targetJamEl && data.summary?.total_target_jam !== undefined) {
            targetJamEl.innerHTML = formatNumber(data.summary.total_target_jam) + ' jam';
        }
        
        // Update persentase
        const percentEl = statCards[2].querySelector('.stat-change');
        if (percentEl && data.summary?.total_amount > 0) {
            const percent = ((data.summary.total_target_amount / data.summary.total_amount) * 100).toFixed(1);
            percentEl.innerHTML = percent + '% dari budget';
        }
    }
    
    // Update charts
    updateCharts(data.chart);
    
    // Update window variables
    if (data.avg_rate > 0) {
        window.OTB_AVG_RATE = data.avg_rate;
    }
    
    // Sembunyikan loading
    hideLoadingState();
}

// Fungsi loading state
function showLoadingState() {
    // Tambahkan class loading ke card dan tabel
    document.querySelectorAll('#page-ot-budget .stat-card').forEach(card => {
        card.classList.add('loading');
    });
    document.querySelector('#page-ot-budget .table-responsive')?.classList.add('loading');
}

function hideLoadingState() {
    // Hapus class loading
    document.querySelectorAll('#page-ot-budget .stat-card').forEach(card => {
        card.classList.remove('loading');
    });
    document.querySelector('#page-ot-budget .table-responsive')?.classList.remove('loading');
}

// Fungsi khusus untuk update tampilan rate
function updateRateDisplay() {
    const currentAvgRate = window.OTB_AVG_RATE || OTB_AVG_RATE;
    const currentMode = memberModes.modes[memberModes.currentMode];
    const totalMembers = currentMode?.members?.length || 0;
    
    console.log('updateRateDisplay - currentAvgRate:', currentAvgRate, 'totalMembers:', totalMembers);
    
    // Update card Rata-rata Rate
    const rateCards = document.querySelectorAll('#page-ot-budget .stat-card');
    if (rateCards.length >= 1) {
        const rateValueEl = rateCards[0].querySelector('.stat-value');
        if (rateValueEl) {
            // Hanya update jika rate valid (> 0), biarkan nilai PHP jika belum siap
            if (currentAvgRate > 0) {
                rateValueEl.innerHTML = 'Rp ' + Math.round(currentAvgRate).toLocaleString('id-ID');
            }
        }
        
        const rateLabelEl = rateCards[0].querySelector('.stat-change');
        if (rateLabelEl && totalMembers > 0) {
            rateLabelEl.innerHTML = `Dari ${totalMembers} member`;
            rateLabelEl.className = 'stat-change text-primary';
        }
    }
}

// Fungsi update tabel
function updateBudgetTable(rows, chart) {
    // Update setiap baris tabel
    for (let i = 0; i < 12; i++) {
        const jamCell = document.querySelector(`.budget-jam-${i}`);
        const amountCell = document.querySelector(`.budget-amount-${i}`);
        const targetPercentCell = document.querySelector(`.target-percent-${i}`);
        const targetAmountCell = document.querySelector(`.target-amount-${i}`);
        const targetJamCell = document.querySelector(`.target-jam-${i}`);
        
        if (jamCell && amountCell) {
            const jam = chart.jam[i] || 0;
            const amount = chart.amount[i] || 0;
            const targetPercent = chart.target_percent[i] || 0;
            const targetAmount = chart.target_amount[i] || 0;
            const targetJam = chart.target_jam[i] || 0;
            const isEmpty = jam === 0 && amount === 0;
            
            jamCell.innerHTML = isEmpty ? '—' : jam.toLocaleString() + ' jam';
            amountCell.innerHTML = isEmpty ? '—' : 'Rp ' + amount.toLocaleString('id-ID');
            targetPercentCell.innerHTML = isEmpty ? '—' : targetPercent + '%';
            targetAmountCell.innerHTML = isEmpty ? '—' : 'Rp ' + targetAmount.toLocaleString('id-ID');
            targetJamCell.innerHTML = isEmpty ? '—' : targetJam.toFixed(1) + ' jam';
        }
    }
}

// Fungsi update summary cards
function updateSummaryCards(summary) {
    // Semua elemen stat-card
    const statCards = document.querySelectorAll('#page-ot-budget .stat-card');
    
    if (statCards.length >= 4) {
        // Card 1: Rata-rata Rate
        const rateValueEl = statCards[0].querySelector('.stat-value');
        if (rateValueEl) {
            const avgRate = window.OTB_AVG_RATE || OTB_AVG_RATE || 0;
            // Hanya update jika rate valid (> 0), biarkan nilai PHP jika belum siap
            if (avgRate > 0) {
                rateValueEl.innerHTML = formatCurrency(avgRate);
            }
        }
        
        // Update label jumlah member
        const currentMode = memberModes.modes[memberModes.currentMode];
        const totalMembers = currentMode?.members?.length || 0;
        const rateLabelEl = statCards[0].querySelector('.stat-change');
        if (rateLabelEl && totalMembers > 0) {
            rateLabelEl.innerHTML = `Dari ${totalMembers} member`;
            rateLabelEl.className = 'stat-change text-primary';
        }
        
        // Card 2: Multiplier - GUNAKAN formatMultiplier!
        if (summary && summary.multiplier !== undefined) {
            const multiplierValueEl = statCards[1].querySelector('.stat-value');
            if (multiplierValueEl) {
                multiplierValueEl.innerHTML = formatMultiplier(summary.multiplier);
            }
        } else {
            // Fallback ke window.OTB_MULTIPLIER
            const multiplierValueEl = statCards[1].querySelector('.stat-value');
            if (multiplierValueEl) {
                multiplierValueEl.innerHTML = formatMultiplier(window.OTB_MULTIPLIER || OTB_MULTIPLIER);
            }
        }
        
        // Card 3: Total Target Amount - GUNAKAN formatCurrency!
        if (summary && summary.total_target_amount !== undefined) {
            const targetAmountEl = statCards[2].querySelector('.stat-value');
            if (targetAmountEl) {
                targetAmountEl.innerHTML = formatCurrency(summary.total_target_amount);
            }
            
            // Update persentase
            const percentEl = statCards[2].querySelector('.stat-change');
            if (percentEl && summary.total_amount > 0) {
                const percent = ((summary.total_target_amount / summary.total_amount) * 100).toFixed(1);
                percentEl.innerHTML = percent + '% dari budget';
                percentEl.style.color = '#d97706';
            }
        }
        
        // Card 4: Total Target Jam - GUNAKAN formatNumber!
        if (summary && summary.total_target_jam !== undefined) {
            const targetJamEl = statCards[3].querySelector('.stat-value');
            if (targetJamEl) {
                targetJamEl.innerHTML = formatNumber(summary.total_target_jam) + ' jam';
            }
        }
    }
}

// Fungsi update charts
function updateCharts(chart) {
    // Update chart jam
    if (window.budgetJamChart) {
        window.budgetJamChart.data.datasets[0].data = chart.jam;
        window.budgetJamChart.update();
    }
    
    // Update chart amount
    if (window.budgetAmountChart) {
        window.budgetAmountChart.data.datasets[0].data = chart.amount;
        window.budgetAmountChart.update();
    }
}

// Fungsi notifikasi
function showNotification(message, type = 'success') {
    // Hapus notifikasi lama
    const oldNotif = document.querySelector('.notification');
    if (oldNotif) oldNotif.remove();
    
    // Buat notifikasi baru
    const notification = document.createElement('div');
    notification.className = `notification notification-${type}`;
    notification.innerHTML = `
        <i class="bi bi-${type === 'success' ? 'check-circle-fill' : 'info-circle-fill'}"></i>
        <span>${message}</span>
    `;
    
    notification.style.cssText = `
        position: fixed;
        top: 20px;
        right: 20px;
        background: ${type === 'success' ? '#10b981' : '#3b82f6'};
        color: white;
        padding: 12px 20px;
        border-radius: 8px;
        font-size: 0.9rem;
        z-index: 10000;
        display: flex;
        align-items: center;
        gap: 10px;
        box-shadow: 0 4px 12px rgba(0,0,0,0.15);
        animation: slideIn 0.3s ease;
    `;
    
    document.body.appendChild(notification);
    
    // Hapus setelah 3 detik
    setTimeout(() => {
        notification.style.animation = 'slideOut 0.3s ease';
        setTimeout(() => notification.remove(), 300);
    }, 3000);
}

// Tambahkan CSS untuk animasi
const style = document.createElement('style');
style.textContent = `
    @keyframes slideIn {
        from { transform: translateX(100%); opacity: 0; }
        to { transform: translateX(0); opacity: 1; }
    }
    @keyframes slideOut {
        from { transform: translateX(0); opacity: 1; }
        to { transform: translateX(100%); opacity: 0; }
    }
`;
document.head.appendChild(style);

// ── FUNGSI UTAMA ──────────────────────────────────────────────

// Hitung target amount dan target jam
function otb_hitungTarget() {
    console.log('otb_hitungTarget dipanggil'); // Untuk debug
    
    const amount = parseFloat(document.getElementById('otb_amount').value) || 0;
    const percent = parseFloat(document.getElementById('otb_target_percent').value) || 0;
    const targetAmount = (amount * percent / 100);
    
    console.log('Amount:', amount, 'Percent:', percent, 'Target Amount:', targetAmount);
    
    // Update input hidden
    document.getElementById('otb_target_amount').value = targetAmount.toFixed(0);
    
    // Update display
    document.getElementById('otb_target_amount_display').innerHTML = 'Rp ' + targetAmount.toLocaleString('id-ID');
    
    // Ambil rate dan multiplier
    const currentRate = window.OTB_AVG_RATE || OTB_AVG_RATE;
    const currentMultiplier = window.OTB_MULTIPLIER || OTB_MULTIPLIER;
    
    console.log('Current Rate:', currentRate, 'Current Multiplier:', currentMultiplier);
    
    // Hitung target jam
    if (targetAmount > 0 && currentRate > 0 && currentMultiplier > 0) {
        const targetJam = targetAmount / (currentRate * currentMultiplier);
        document.getElementById('otb_target_jam').value = targetJam.toFixed(1);
        document.getElementById('otb_target_jam_display').innerHTML = targetJam.toFixed(1) + ' jam';
        console.log('Target Jam:', targetJam);
    } else {
        document.getElementById('otb_target_jam').value = 0;
        document.getElementById('otb_target_jam_display').innerHTML = '0 jam';
    }
}

// Buka modal budget
function otb_openModal(bulan = null, jam = 0, amount = 0, targetPercent = 80, targetAmount = 0, targetJam = 0) {
    // TAMBAHKAN: Update rate dari mode aktif terlebih dahulu
    const currentAvgRate = calculateAvgRateFromMode(memberModes.currentMode);
    window.OTB_AVG_RATE = currentAvgRate;
    
    // Update dropdown mode member
    updateBudgetModeDropdown();
    
    if (bulan) {
        document.getElementById('otb_bulan').value = bulan;
        document.getElementById('otb_amount').value = amount;
        document.getElementById('otb_target_percent').value = targetPercent;
        document.getElementById('otb_target_amount').value = targetAmount;
        document.getElementById('otb_target_jam').value = targetJam;
        
        // Set mode ke current mode
        const modeSelect = document.getElementById('otb_mode_member');
        if (modeSelect) {
            modeSelect.value = memberModes.currentMode;
        }
        
        // Update rate display sesuai mode
        otb_changeMode();
    } else {
        document.getElementById('otb_amount').value = '';
        document.getElementById('otb_target_percent').value = 80;
        document.getElementById('otb_target_amount').value = 0;
        document.getElementById('otb_target_jam').value = 0;
        
        // Set mode ke current mode untuk budget baru
        const modeSelect = document.getElementById('otb_mode_member');
        if (modeSelect) {
            modeSelect.value = memberModes.currentMode;
        }
        
        // Update rate display sesuai mode
        otb_changeMode();
    }
    
    // Hitung target (akan 0 jika amount kosong)
    otb_hitungTarget();
    
    document.getElementById('modalotbudget').style.display = 'flex';
}

function otb_closeModal() {
    document.getElementById('modalotbudget').style.display = 'none';
}

// Update dropdown mode member di modal budget
function updateBudgetModeDropdown() {
    const modeSelect = document.getElementById('otb_mode_member');
    if (!modeSelect) return;
    
    let options = '<option value="">-- Pilih Mode Member --</option>';
    
    Object.keys(memberModes.modes).forEach(modeId => {
        const mode = memberModes.modes[modeId];
        const memberCount = mode.members?.length || 0;
        const selected = (modeId === memberModes.currentMode) ? 'selected' : '';
        
        options += `<option value="${modeId}" ${selected}>${mode.name} (${memberCount} member)</option>`;
    });
    
    modeSelect.innerHTML = options;
}

// Hitung rata-rata rate dari mode yang dipilih
function calculateAvgRateFromMode(modeId) {
    console.log('calculateAvgRateFromMode untuk mode:', modeId);
    
    const mode = memberModes.modes[modeId];
    if (!mode) {
        console.log('Mode tidak ditemukan, pakai OTB_AVG_RATE:', OTB_AVG_RATE);
        return OTB_AVG_RATE;
    }
    
    console.log('Mode members:', mode.members);
    
    if (!mode.members || mode.members.length === 0) {
        console.log('Mode kosong, pakai OTB_AVG_RATE:', OTB_AVG_RATE);
        return OTB_AVG_RATE;
    }
    
    // Filter member yang aktif dan punya rate > 0
    const validRates = mode.members.filter(m => {
        const rate = parseFloat(m.rate_per_hour) || 0;
        const isActive = m.is_active == 1 || m.is_active === true || m.is_active === undefined;
        return rate > 0 && isActive;
    });

    console.log('Valid rates:', validRates);
    
    if (validRates.length === 0) {
        console.log('Tidak ada rate valid, pakai OTB_AVG_RATE:', OTB_AVG_RATE);
        return OTB_AVG_RATE;
    }
    
    const totalRate = validRates.reduce((sum, m) => sum + (parseFloat(m.rate_per_hour) || 0), 0);
    const avgRate = totalRate / validRates.length;
    console.log('Total rate:', totalRate, 'Avg rate:', avgRate);
    
    return avgRate;
}

// Di bagian akhir script, pastikan rate tidak ditimpa
document.addEventListener('DOMContentLoaded', function() {
    console.log('DOM Content Loaded');
    console.log('OTB_MEMBERS:', OTB_MEMBERS);
    console.log('OTB_AVG_RATE:', OTB_AVG_RATE);
    
    // Set nilai awal window.OTB_AVG_RATE hanya jika valid (> 0)
    if (OTB_AVG_RATE > 0) {
        window.OTB_AVG_RATE = OTB_AVG_RATE;
    }
    
    // Inisialisasi mode members
    setTimeout(() => {
        loadMemberModes();
        
        // Pastikan statistik utama terupdate
        setTimeout(() => {
            updateMainPageStats();
            updateRateDisplay();
        }, 1000);
    }, 500);
    
    // Proteksi tambahan: ketika halaman selesai loading
    window.addEventListener('load', function() {
        setTimeout(() => {
            updateRateDisplay();
        }, 2000);
    });
});

// Update statistik di halaman utama
function updateMainPageStats() {
    console.log('updateMainPageStats dipanggil');
    
    // Hitung rate dari mode aktif
    const currentAvgRate = calculateAvgRateFromMode(memberModes.currentMode);
    window.OTB_AVG_RATE = currentAvgRate;
    
    // Dapatkan total member dari mode aktif
    const currentMode = memberModes.modes[memberModes.currentMode];
    const totalMembers = currentMode?.members?.length || 0;
    
    console.log('Current Avg Rate:', currentAvgRate, 'Total Members:', totalMembers);
    
    // Update card Rata-rata Rate (card pertama)
    const rateCards = document.querySelectorAll('#page-ot-budget .stat-card');
    if (rateCards.length >= 1) {
        const rateValueEl = rateCards[0].querySelector('.stat-value');
        if (rateValueEl) {
            // Hanya update jika rate valid (> 0), biarkan nilai PHP jika belum siap
            if (currentAvgRate > 0) {
                rateValueEl.innerHTML = 'Rp ' + Math.round(currentAvgRate).toLocaleString('id-ID');
            }
        }
        
        const rateLabelEl = rateCards[0].querySelector('.stat-change');
        if (rateLabelEl && totalMembers > 0) {
            rateLabelEl.innerHTML = `Dari ${totalMembers} member`;
            rateLabelEl.className = 'stat-change text-primary';
        }
    }
    
    // Update card Multiplier (card kedua)
    if (rateCards.length >= 2) {
        const multValueEl = rateCards[1].querySelector('.stat-value');
        if (multValueEl) {
            const multValue = window.OTB_MULTIPLIER || OTB_MULTIPLIER || 1.5;
            multValueEl.innerHTML = (Number.isInteger(multValue) ? multValue : multValue.toFixed(1)) + 'x';
        }
    }
    
    // Refresh data budget untuk update target amount dan jam
    // Hanya refresh jika rate sudah valid agar tidak flash ke 0
    if (currentAvgRate > 0) {
        refreshBudgetData();
    }
}

// Saat mode berubah
function otb_changeMode() {
    const modeId = document.getElementById('otb_mode_member').value;
    
    if (modeId) {
        const avgRate = calculateAvgRateFromMode(modeId);
        document.getElementById('otb_avg_rate_display').innerHTML = 'Rp ' + Math.round(avgRate).toLocaleString('id-ID');
        window.OTB_AVG_RATE = avgRate;
    } else {
        document.getElementById('otb_avg_rate_display').innerHTML = 'Rp ' + Math.round(OTB_AVG_RATE).toLocaleString('id-ID');
    }
    
    otb_hitungTarget();
}

// Simpan budget
function otb_simpan() {
    const tahun = document.getElementById('otb_tahun').value;
    const bulan = document.getElementById('otb_bulan').value;
    const amount = document.getElementById('otb_amount').value;
    const targetPercent = document.getElementById('otb_target_percent').value;
    const targetAmount = document.getElementById('otb_target_amount').value;
    const targetJam = document.getElementById('otb_target_jam').value;
    const keterangan = document.getElementById('otb_keterangan').value;
    const modeId = document.getElementById('otb_mode_member').value;

    if (!amount || amount <= 0) {
        alert('Budget amount harus diisi dan lebih dari 0.');
        return;
    }

    fetch('/best-root/public/overtime/budget/store', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
            tahun: parseInt(tahun),
            bulan: parseInt(bulan),
            jam: parseFloat(targetJam) || 0,
            amount: parseFloat(amount),
            target_percent: parseFloat(targetPercent),
            target_amount: parseFloat(targetAmount),
            target_jam: parseFloat(targetJam),
            mode_id: modeId,
            keterangan: keterangan
        })
    })
    .then(r => r.json())
    .then(d => {
        if (d.success) {
            otb_closeModal();
            
            // Refresh data dan pastikan multiplier tetap
            refreshBudgetData();
            
            // Pastikan multiplier display tidak berubah
            const multiplierDisplay = document.getElementById('stat-multiplier');
            if (multiplierDisplay) {
                const multValue = window.OTB_MULTIPLIER || OTB_MULTIPLIER;
                multiplierDisplay.innerHTML = (Number.isInteger(multValue) ? multValue : multValue.toFixed(1)) + 'x';
            }
            
            showNotification('Budget berhasil disimpan!', 'success');
        } else {
            alert('Gagal: ' + d.message);
        }
    })
    .catch(error => {
        console.error('Error:', error);
        alert('Kesalahan koneksi ke server.');
    });
}

// Buka modal member
function otb_openMemberModal() {
    document.getElementById('modalotmember').style.display = 'flex';
}

function otb_closeMemberModal() {
    document.getElementById('modalotmember').style.display = 'none';
}

// (fungsi otb_addMemberRow dan otb_deleteMember ada di bagian fitur mode di bawah)

// Simpan members mode aktif
function otb_simpanMembers() {
    console.log('otb_simpanMembers dipanggil'); // Debug
    
    const currentMode = memberModes.modes[memberModes.currentMode];
    const members = [];
    
    document.querySelectorAll('#memberTableBody tr').forEach(row => {
        if (row.style.display !== 'none' && row.cells.length > 1) {
            const npk = row.querySelector('.npk-input')?.value;
            const name = row.querySelector('.name-input')?.value;
            const rate = row.querySelector('.rate-input')?.value;
            const status = row.querySelector('.status-select')?.value;
            
            if (npk && name) {
                members.push({
                    id: row.dataset.id,
                    npk: npk,
                    name: name,
                    rate_per_hour: parseFloat(rate) || 0,
                    is_active: parseInt(status)
                });
            }
        }
    });
    
    currentMode.members = members;
    saveModesToLocal();
    updateMemberStats(members);
    
    // Update global average rate
    const newAvgRate = calculateAvgRateFromMode(memberModes.currentMode);
    window.OTB_AVG_RATE = newAvgRate;
    
    // Kirim ke server untuk mode aktif
    otb_syncModeToServer(memberModes.currentMode);
    
    showNotification(`Mode "${currentMode.name}" berhasil disimpan!`, 'success');
}

// Buka modal multiplier
function otb_openMultiplierModal() {
    console.log('otb_openMultiplierModal dipanggil');
    const modal = document.getElementById('modalOTMultiplier');
    
    if (modal) {
        modal.style.display = 'flex';
    } else {
        alert('Modal multiplier tidak ditemukan!');
        return;
    }
    
    // Load data multiplier setelah modal terbuka
    otb_loadMultiplierData();
}

// Load data multiplier berdasarkan tahun yang dipilih
function otb_loadMultiplierData() {
    const tahun = document.getElementById('otb_mult_tahun').value;
    
    fetch(`/best-root/public/overtime/budget/multiplier?tahun=${tahun}`)
        .then(response => response.json())
        .then(data => {
            if (data.success && data.multiplier) {
                document.getElementById('otb_multiplier').value = data.multiplier;
                document.getElementById('otb_mult_keterangan').value = data.keterangan || '';
            }
        })
        .catch(error => console.log('Menggunakan default value'));
}

function otb_closeMultiplierModal() {
    const modal = document.getElementById('modalOTMultiplier');
    if (modal) {
        modal.style.display = 'none';
    }
}

// Simpan multiplier
function otb_simpanMultiplier() {
    // Ambil nilai dari form
    const tahun = document.getElementById('otb_mult_tahun').value;
    const multiplier = document.getElementById('otb_multiplier').value;
    const keterangan = document.getElementById('otb_mult_keterangan').value;
    
    // Validasi
    if (!tahun || tahun < 2020 || tahun > 2099) {
        alert('Tahun tidak valid!');
        return;
    }
    
    if (!multiplier || multiplier < 1 || multiplier > 3) {
        alert('Multiplier harus antara 1 - 3');
        return;
    }
    
    // Tampilkan loading
    const simpanBtn = event.target;
    const originalText = simpanBtn.innerHTML;
    simpanBtn.innerHTML = '<i class="bi bi-hourglass"></i> Menyimpan...';
    simpanBtn.disabled = true;
    
    // Kirim ke server
    fetch('/best-root/public/overtime/budget/save-multiplier', {
        method: 'POST',
        headers: { 
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({ 
            tahun: parseInt(tahun), 
            multiplier: parseFloat(multiplier), 
            keterangan: keterangan 
        })
    })
    .then(response => {
        if (!response.ok) {
            throw new Error('Network response was not ok');
        }
        return response.json();
    })
    .then(data => {
        if (data.success) {
            otb_closeMultiplierModal();
            
            // Update multiplier di memory
            window.OTB_MULTIPLIER = parseFloat(multiplier);
            
            // Update tampilan multiplier di card
            const multiplierEls = document.querySelectorAll('.stat-value');
            if (multiplierEls[1]) {
                multiplierEls[1].innerHTML = parseFloat(multiplier).toFixed(1) + 'x';
            }
            
            // Refresh data
            refreshBudgetData();
            showNotification('Multiplier berhasil disimpan!', 'success');
        } else {
            alert('Gagal: ' + (data.message || 'Terjadi kesalahan'));
        }
    })
    .catch(error => {
        console.error('Error:', error);
        alert('Kesalahan koneksi ke server. Pastikan server sedang berjalan.');
    })
    .finally(() => {
        // Kembalikan tombol ke keadaan semula
        simpanBtn.innerHTML = originalText;
        simpanBtn.disabled = false;
    });
}

// Buka modal target member
function otb_openMemberTargetModal(bulan) {
    const bulanNama = ['Januari','Februari','Maret','April','Mei','Juni',
                       'Juli','Agustus','September','Oktober','November','Desember'][bulan-1];
    
    let html = `<h6 class="mb-3">Target Jam untuk Bulan ${bulanNama}</h6>`;
    
    OTB_MEMBERS.forEach(member => {
        html += `
            <div class="mb-2 p-2 border rounded">
                <div class="fw-bold">${member.name} (${member.npk})</div>
                <div class="d-flex align-items-center gap-2">
                    <span style="font-size:0.8rem;">Rate: Rp ${member.rate_per_hour.toLocaleString()}</span>
                    <input type="number" class="form-control form-control-sm" 
                           style="width:120px;" 
                           placeholder="Target jam" 
                           step="0.5" 
                           data-member-id="${member.id}"
                           data-member-name="${member.name}">
                </div>
            </div>
        `;
    });
    
    document.getElementById('memberTargetList').innerHTML = html;
    document.getElementById('modalotmemberTarget').dataset.bulan = bulan;
    document.getElementById('modalotmemberTarget').style.display = 'flex';
}

function otb_closeMemberTargetModal() {
    document.getElementById('modalotmemberTarget').style.display = 'none';
}

function otb_simpanMemberTargets() {
    const bulan = document.getElementById('modalotmemberTarget').dataset.bulan;
    const inputs = document.querySelectorAll('#memberTargetList input[data-member-id]');
    const targets = [];
    
    inputs.forEach(input => {
        const jam = parseFloat(input.value) || 0;
        if (jam > 0) {
            targets.push({
                member_id: input.dataset.memberId,
                jam: jam
            });
        }
    });
    
    console.log('Target for month', bulan, ':', targets);
    alert('Fitur simpan target member akan diimplementasikan');
    otb_closeMemberTargetModal();
}

// Hapus budget
function otb_hapus(bulan) {
    if (!confirm('Hapus budget bulan ini?')) return;
    
    fetch('/best-root/public/overtime/budget/delete', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ tahun: <?= $tahun_ini ?>, bulan: bulan })
    })
    .then(r => r.json())
    .then(d => {
        if (d.success) {
            refreshBudgetData();
            showNotification('Budget berhasil dihapus!', 'success');
        } else {
            alert('Gagal: ' + d.message);
        }
    })
    .catch(error => {
        console.error('Error:', error);
        alert('Kesalahan koneksi ke server.');
    });
}

// ============================================
// FITUR MODE MEMBER
// ============================================

// Data Structure untuk menyimpan modes
let memberModes = {
    currentMode: 'default',
    modes: {
        'default': {
            name: 'Default',
            startDate: null,
            endDate: null,
            members: [],
            description: 'Mode default'
        }
    }
};

// Load members awal dari PHP dengan validasi
if (OTB_MEMBERS && OTB_MEMBERS.length > 0) {
    console.log('Mengisi default mode dengan OTB_MEMBERS:', OTB_MEMBERS.length, 'member');
    memberModes.modes.default.members = OTB_MEMBERS.map(member => ({
        ...member,
        rate_per_hour: parseFloat(member.rate_per_hour) || 0
    }));
} else {
    console.log('OTB_MEMBERS kosong atau tidak valid');
}

// (mapping rate_per_hour sudah dilakukan di blok if di atas)

// Load dari localStorage dan server
function loadMemberModes() {
    console.log('loadMemberModes dipanggil');
    console.log('OTB_MEMBERS dari PHP:', OTB_MEMBERS);
    
    // Load dari localStorage dulu (cepat)
    const saved = localStorage.getItem('memberModes');
    if (saved) {
        try {
            const parsed = JSON.parse(saved);
            memberModes.currentMode = parsed.currentMode || 'default';
            
            // Merge dengan mempertahankan default mode
            memberModes.modes = { ...memberModes.modes, ...parsed.modes };
            
            // Pastikan default mode punya members dari PHP jika kosong
            if ((!memberModes.modes.default.members || memberModes.modes.default.members.length === 0) 
                && OTB_MEMBERS && OTB_MEMBERS.length > 0) {
                console.log('Mengisi default mode dengan OTB_MEMBERS');
                memberModes.modes.default.members = OTB_MEMBERS;
            }
        } catch (e) {
            console.log('Error loading modes, using default');
        }
    } else {
        // Jika tidak ada di localStorage, gunakan OTB_MEMBERS untuk default
        if (OTB_MEMBERS && OTB_MEMBERS.length > 0) {
            console.log('Inisialisasi default mode dengan OTB_MEMBERS');
            memberModes.modes.default.members = OTB_MEMBERS;
        } else {
            console.log('OTB_MEMBERS kosong, default mode tetap kosong');
        }
    }
    
    renderModeList();
    loadMembersForCurrentMode();
    
    // Load dari server untuk data terbaru
    loadModesFromServer().then(() => {
        // Update average rate setelah load dari server
        const currentAvgRate = calculateAvgRateFromMode(memberModes.currentMode);
        window.OTB_AVG_RATE = currentAvgRate;
        console.log('Average rate setelah load server:', currentAvgRate);
        
        // Update display di halaman utama
        updateMainPageStats();
        
        // Update display di modal budget jika terbuka
        const avgDisplay = document.getElementById('otb_avg_rate_display');
        if (avgDisplay) {
            avgDisplay.innerHTML = 'Rp ' + Math.round(currentAvgRate).toLocaleString('id-ID');
        }
    });
    
    // Update dropdown mode di modal budget
    updateBudgetModeDropdown();
}

// Render daftar mode
function renderModeList() {
    const modeList = document.getElementById('modeList');
    if (!modeList) return;
    
    // Bersihkan container
    modeList.innerHTML = '';
    modeList.className = 'mode-list-container';
    
    let html = '';
    
    // Loop untuk setiap mode
    Object.keys(memberModes.modes).forEach(modeId => {
        const mode = memberModes.modes[modeId];
        const isActive = memberModes.currentMode === modeId;
        const memberCount = mode.members?.length || 0;
        
        if (modeId === 'default') {
            // Mode Default - tanpa tombol edit dan hapus
            html += `
                <button class="btn ${isActive ? 'btn-p' : 'btn-o'} btn-sm" 
                        onclick="otb_switchMode('${modeId}')"
                        style="margin-right:4px; margin-bottom:5px;">
                    ${mode.name} (${memberCount})
                </button>
            `;
        } else {
            // Mode kustom - dengan tombol edit dan hapus (3 bagian)
            html += `
                <div class="mode-btn-group-triple" style="display:inline-flex; align-items:center; margin-right:8px; margin-bottom:5px;">
                    <!-- Tombol Mode (untuk switch) -->
                    <button class="btn ${isActive ? 'btn-p' : 'btn-o'} btn-sm" 
                            onclick="otb_switchMode('${modeId}')"
                            style="border-top-right-radius:0; border-bottom-right-radius:0; border-right:0;">
                        ${mode.name} (${memberCount})
                    </button>
                    
                    <!-- Tombol Edit -->
                    <button class="btn ${isActive ? 'btn-p' : 'btn-o'} btn-sm mode-edit-btn" 
                            onclick="otb_editMode('${modeId}', event)"
                            style="border-radius:0; border-right:0; padding:6px 8px;"
                            title="Edit Mode">
                        <i class="bi bi-pencil-square"></i>
                    </button>
                    
                    <!-- Tombol Hapus -->
                    <button class="btn ${isActive ? 'btn-p' : 'btn-o'} btn-sm mode-delete-btn" 
                            onclick="otb_deleteMode('${modeId}', event)"
                            style="border-top-left-radius:0; border-bottom-left-radius:0; padding:6px 8px;"
                            title="Hapus Mode">
                        <i class="bi bi-trash"></i>
                    </button>
                </div>
            `;
        }
    });
    
    modeList.innerHTML = html;
    
    // Update badge mode aktif
    const activeMode = memberModes.modes[memberModes.currentMode];
    if (activeMode) {
        document.getElementById('activeModeBadge').innerHTML = `Mode: ${activeMode.name}`;
        
        let periodText = '';
        if (activeMode.startDate && activeMode.endDate) {
            periodText = `${activeMode.startDate} s/d ${activeMode.endDate}`;
        } else if (activeMode.startDate) {
            periodText = `Mulai ${activeMode.startDate}`;
        } else if (activeMode.endDate) {
            periodText = `Sampai ${activeMode.endDate}`;
        }
        document.getElementById('modePeriod').innerHTML = periodText || '';
        
        // Update member count
        const avgRate = calculateAvgRateFromMode(memberModes.currentMode);
        document.getElementById('memberCount').innerHTML = `Total: ${activeMode.members?.length || 0} member | Rata-rate: Rp ${Math.round(avgRate).toLocaleString()}`;
    }
}

// Hapus mode
function otb_deleteMode(modeId, event) {
    event.stopPropagation();
    
    // Konfirmasi hapus
    if (!confirm(`Apakah Anda yakin ingin menghapus mode "${memberModes.modes[modeId].name}"?`)) {
        return;
    }
    
    console.log('Menghapus mode:', modeId);
    
    // Hapus dari memory
    delete memberModes.modes[modeId];
    
    // Jika mode yang dihapus adalah mode aktif, pindah ke default
    if (memberModes.currentMode === modeId) {
        memberModes.currentMode = 'default';
    }
    
    // Simpan ke localStorage
    saveModesToLocal();
    
    // Kirim ke server
    fetch('/best-root/public/overtime/budget/delete-mode', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ mode_id: modeId })
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            showNotification('Mode berhasil dihapus!', 'success');
        } else {
            showNotification('Gagal menghapus mode di server: ' + data.message, 'error');
        }
    })
    .catch(error => {
        console.error('Error deleting mode:', error);
        showNotification('Gagal menghapus mode di server', 'error');
    })
    .finally(() => {
        // Update tampilan
        renderModeList();
        loadMembersForCurrentMode();
        updateBudgetModeDropdown();
        
        // Update average rate
        const newAvgRate = calculateAvgRateFromMode(memberModes.currentMode);
        window.OTB_AVG_RATE = newAvgRate;
    });
}

// Switch mode
function otb_switchMode(modeId) {
    memberModes.currentMode = modeId;
    saveModesToLocal();
    loadMembersForCurrentMode();
    renderModeList();
}

// Load members untuk mode aktif
function loadMembersForCurrentMode() {
    const currentMode = memberModes.modes[memberModes.currentMode];
    const members = currentMode?.members || [];
    
    renderMemberTable(members);
    updateMemberStats(members);
}

// Render tabel member
function renderMemberTable(members) {
    const tbody = document.getElementById('memberTableBody');
    if (!tbody) return;
    
    if (members.length === 0) {
        tbody.innerHTML = `
            <tr>
                <td colspan="5" class="text-center py-4" style="color:#9ca3af;">
                    <i class="bi bi-people fs-4 d-block mb-2"></i>
                    Belum ada member. Klik "Tambah Member" atau "Import dari Users"
                </td>
            </tr>
        `;
        return;
    }
    
    let html = '';
    members.forEach((member, index) => {
        const memberId = member.id || member.member_id || 'new_' + index;
        html += `
            <tr data-id="${memberId}" data-index="${index}">
                <td style="position:relative;">
                    <input type="text" class="form-control form-control-sm npk-input" 
                           value="${member.npk || ''}" 
                           placeholder="NPK" 
                           onkeyup="otb_searchUserByNPK(this, ${index})"
                           onblur="setTimeout(() => hideSuggestions(${index}), 200)">
                    <div class="npk-suggestions" id="suggestions-${index}" style="display:none;"></div>
                </td>
                <td>
                    <input type="text" class="form-control form-control-sm name-input" 
                           value="${member.name || ''}" 
                           placeholder="Nama" 
                           readonly>
                </td>
                <td>
                    <input type="number" class="form-control form-control-sm rate-input" 
                           value="${member.rate_per_hour || ''}" 
                           placeholder="Rate" step="1000" 
                           onchange="otb_updateAvgRate()">
                </td>
                <td>
                    <select class="form-select form-select-sm status-select">
                        <option value="1" ${member.is_active == 1 ? 'selected' : ''}>Aktif</option>
                        <option value="0" ${member.is_active == 0 ? 'selected' : ''}>Nonaktif</option>
                    </select>
                </td>
                <td>
                    <div class="d-flex gap-1">
                        <button class="btn btn-sm btn-outline-primary" onclick="otb_saveMember(this)" title="Simpan">
                            <i class="bi bi-check-lg"></i>
                        </button>
                        <button class="btn btn-sm btn-outline-danger" onclick="otb_deleteMember(this)" title="Hapus">
                            <i class="bi bi-trash"></i>
                        </button>
                    </div>
                </td>
            </tr>
        `;
    });
    
    tbody.innerHTML = html;
    updateMemberStats(members);
}

// Hide suggestions
function hideSuggestions(index) {
    setTimeout(() => {
        const suggestions = document.getElementById(`suggestions-${index}`);
        if (suggestions) suggestions.style.display = 'none';
    }, 200);
}

// Auto-complete NPK dari tabel users
function otb_searchUserByNPK(input, index) {
    const npk = input.value.trim();
    
    if (npk.length < 2) {
        document.getElementById(`suggestions-${index}`).style.display = 'none';
        return;
    }
    
    // Fetch users dari server
    fetch(`/best-root/public/users/search?q=${encodeURIComponent(npk)}`)
        .then(response => response.json())
        .then(users => {
            if (users && users.length > 0) {
                let suggestions = '';
                users.forEach(user => {
                    suggestions += `
                        <div onclick="otb_selectUser('${user.npk}', '${user.name.replace(/'/g, "\\'")}', ${index})">
                            <strong>${user.npk}</strong> - ${user.name}
                        </div>
                    `;
                });
                
                const suggestionsDiv = document.getElementById(`suggestions-${index}`);
                if (suggestionsDiv) {
                    suggestionsDiv.innerHTML = suggestions;
                    suggestionsDiv.style.display = 'block';
                }
            } else {
                document.getElementById(`suggestions-${index}`).style.display = 'none';
            }
        })
        .catch(error => console.log('Error searching users:', error));
}

// Pilih user dari suggestions
function otb_selectUser(npk, name, index) {
    const row = document.querySelector(`#memberTableBody tr[data-index="${index}"]`);
    if (row) {
        row.querySelector('.npk-input').value = npk;
        row.querySelector('.name-input').value = name;
        document.getElementById(`suggestions-${index}`).style.display = 'none';
        
        // Auto-fill rate default
        otb_getUserRate(npk, index);
    }
}

// Ambil rate user dari database
function otb_getUserRate(npk, index) {
    fetch(`/best-root/public/users/get-rate?npk=${encodeURIComponent(npk)}`)
        .then(response => response.json())
        .then(data => {
            if (data.success && data.rate) {
                const row = document.querySelector(`#memberTableBody tr[data-index="${index}"]`);
                if (row) {
                    row.querySelector('.rate-input').value = data.rate;
                    otb_updateAvgRate();
                }
            }
        })
        .catch(error => console.log('Using default rate'));
}

// Import dari users
function otb_importFromUsers() {
    // Tampilkan loading
    document.getElementById('userListBody').innerHTML = `
        <tr>
            <td colspan="4" class="text-center py-3">
                <div class="spinner-border spinner-border-sm text-primary" role="status"></div>
                Loading users...
            </td>
        </tr>
    `;
    
    document.getElementById('importUsersModal').style.display = 'flex';
    
    // Load users dari server
    fetch('/best-root/public/users/get-all')
        .then(response => {
            if (!response.ok) {
                throw new Error('Network response was not ok');
            }
            return response.json();
        })
        .then(users => {
            console.log('Users loaded:', users); // Untuk debugging
            
            if (users && users.length > 0) {
                let html = '';
                users.forEach(user => {
                    html += `
                        <tr>
                            <td class="text-center">
                                <input type="checkbox" class="user-check" 
                                       data-npk="${user.npk}" 
                                       data-name="${user.name.replace(/'/g, "\\'")}" 
                                       data-role="${user.role || ''}">
                            </td>
                            <td>${user.npk}</td>
                            <td>${user.name}</td>
                            <td>${user.role || '-'}</td>
                        </tr>
                    `;
                });
                document.getElementById('userListBody').innerHTML = html;
            } else {
                document.getElementById('userListBody').innerHTML = `
                    <tr>
                        <td colspan="4" class="text-center py-3 text-muted">
                            <i class="bi bi-exclamation-circle me-2"></i>
                            Tidak ada data users
                        </td>
                    </tr>
                `;
            }
        })
        .catch(error => {
            console.error('Error loading users:', error);
            document.getElementById('userListBody').innerHTML = `
                <tr>
                    <td colspan="4" class="text-center py-3 text-danger">
                        <i class="bi bi-exclamation-triangle-fill me-2"></i>
                        Gagal load users: ${error.message}
                        <br>
                        <small>Pastikan server berjalan dan endpoint /users/get-all tersedia</small>
                    </td>
                </tr>
            `;
        });
}

// Import selected users

// Fungsi helper untuk format angka
function formatNumber(num) {
    if (num === undefined || num === null) return '0';
    return Math.round(num).toLocaleString('id-ID');
}

function formatMultiplier(mult) {
    if (mult === undefined || mult === null) return '1.5x';
    return (Number.isInteger(mult) ? mult : mult.toFixed(1)) + 'x';
}

function formatCurrency(amount) {
    if (amount === undefined || amount === null) return 'Rp 0';
    return 'Rp ' + Math.round(amount).toLocaleString('id-ID');
}

// Search users di modal import
function otb_searchUsers() {
    const searchText = document.getElementById('userSearch').value.toLowerCase();
    const rows = document.querySelectorAll('#userListBody tr');
    
    rows.forEach(row => {
        const npk = row.cells[1]?.innerText.toLowerCase() || '';
        const name = row.cells[2]?.innerText.toLowerCase() || '';
        
        if (npk.includes(searchText) || name.includes(searchText)) {
            row.style.display = '';
        } else {
            row.style.display = 'none';
        }
    });
}

// Toggle select all users
function otb_toggleSelectAll() {
    const selectAll = document.getElementById('selectAllUsers').checked;
    document.querySelectorAll('.user-check').forEach(cb => {
        cb.checked = selectAll;
    });
}

// Close import modal
function otb_closeImportModal() {
    document.getElementById('importUsersModal').style.display = 'none';
}

// Import selected users
function otb_importSelectedUsers() {
    const checkboxes = document.querySelectorAll('.user-check:checked');
    
    if (checkboxes.length === 0) {
        alert('Pilih minimal 1 user');
        return;
    }
    
    const selectedUsers = [];
    checkboxes.forEach(cb => {
        selectedUsers.push({
            npk: cb.dataset.npk,
            name: cb.dataset.name,
            rate_per_hour: parseInt(cb.dataset.rate) || 50000,
            is_active: 1
        });
    });
    
    // Tambahkan ke mode aktif
    const currentMode = memberModes.modes[memberModes.currentMode];
    if (!currentMode.members) currentMode.members = [];
    
    // Merge tanpa duplikat berdasarkan NPK
    const existingNpks = new Set(currentMode.members.map(m => m.npk));
    let addedCount = 0;
    
    selectedUsers.forEach(user => {
        if (!existingNpks.has(user.npk)) {
            currentMode.members.push(user);
            addedCount++;
        }
    });
    
    loadMembersForCurrentMode();
    saveModesToLocal();
    otb_closeImportModal();
    
    showNotification(`${addedCount} member berhasil diimport!`, 'success');
}

// Tambah row member baru
function otb_addMemberRow() {
    const currentMode = memberModes.modes[memberModes.currentMode];
    if (!currentMode.members) currentMode.members = [];
    
    // Tambah member kosong
    currentMode.members.push({
        npk: '',
        name: '',
        rate_per_hour: 50000,
        is_active: 1
    });
    
    loadMembersForCurrentMode();
}

// Delete member
function otb_deleteMember(btn) {
    if (!confirm('Hapus member ini?')) return;
    
    const row = btn.closest('tr');
    const index = row.dataset.index;
    
    const currentMode = memberModes.modes[memberModes.currentMode];
    if (currentMode.members && index !== undefined) {
        currentMode.members.splice(index, 1);
        loadMembersForCurrentMode();
        saveModesToLocal();
        showNotification('Member berhasil dihapus', 'success');
    }
}

// Save single member
function otb_saveMember(btn) {
    const row = btn.closest('tr');
    const index = row.dataset.index;
    
    const npk = row.querySelector('.npk-input').value.trim();
    const name = row.querySelector('.name-input').value.trim();
    const rate = parseFloat(row.querySelector('.rate-input').value) || 0;
    const status = parseInt(row.querySelector('.status-select').value);
    
    if (!npk || !name) {
        alert('NPK dan Nama harus diisi');
        return;
    }
    
    const currentMode = memberModes.modes[memberModes.currentMode];
    if (currentMode.members && index !== undefined) {
        currentMode.members[index] = {
            ...currentMode.members[index],
            npk: npk,
            name: name,
            rate_per_hour: rate,
            is_active: status
        };
        
        saveModesToLocal();
        updateMemberStats(currentMode.members);
        showNotification('Member berhasil disimpan', 'success');
    }
}

// Update statistik member
function updateMemberStats(members) {
    const total = members.length;
    const validRates = members.filter(m => m.rate_per_hour > 0);
    const avgRate = validRates.length > 0 
        ? validRates.reduce((sum, m) => sum + (parseFloat(m.rate_per_hour) || 0), 0) / validRates.length 
        : 0;
    
    document.getElementById('totalMemberCount').innerText = total;
    document.getElementById('avgRateDisplay').innerText = Math.round(avgRate).toLocaleString();
    document.getElementById('memberCount').innerHTML = `Total: ${total} member | Rata-rate: Rp ${Math.round(avgRate).toLocaleString()}`;
    
    // Update global average rate
    if (total > 0 && validRates.length > 0) {
        window.OTB_AVG_RATE = avgRate;
    }
}

// Update average rate (dipanggil saat rate berubah)
function otb_updateAvgRate() {
    const currentMode = memberModes.modes[memberModes.currentMode];
    if (currentMode?.members) {
        updateMemberStats(currentMode.members);
    }
}

// Search member
function otb_searchMember() {
    const searchText = document.getElementById('memberSearch').value.toLowerCase();
    const rows = document.querySelectorAll('#memberTableBody tr');
    
    rows.forEach(row => {
        if (row.cells.length > 1) {
            const npk = row.querySelector('.npk-input')?.value.toLowerCase() || '';
            const name = row.querySelector('.name-input')?.value.toLowerCase() || '';
            
            if (npk.includes(searchText) || name.includes(searchText)) {
                row.style.display = '';
            } else {
                row.style.display = 'none';
            }
        }
    });
}

// Duplicate current mode
function otb_duplicateMode() {
    const currentMode = memberModes.modes[memberModes.currentMode];
    if (!currentMode) return;
    
    const newModeId = 'mode_' + Date.now();
    memberModes.modes[newModeId] = {
        name: currentMode.name + ' (Copy)',
        startDate: currentMode.startDate,
        endDate: currentMode.endDate,
        members: JSON.parse(JSON.stringify(currentMode.members)), // Deep copy
        description: 'Duplikasi dari ' + currentMode.name
    };
    
    saveModesToLocal();
    renderModeList();
    showNotification('Mode berhasil diduplikasi', 'success');
}

// Tambah mode baru
function otb_addMode() {
    document.getElementById('modeModalTitle').innerText = 'Tambah Mode Baru';
    document.getElementById('modeName').value = '';
    document.getElementById('modeStart').value = '';
    document.getElementById('modeEnd').value = '';
    document.getElementById('modeDescription').value = '';
    document.getElementById('addModeModal').dataset.modeId = '';
    document.getElementById('addModeModal').style.display = 'flex';
}

// Edit mode
function otb_editMode(modeId, event) {
    event.stopPropagation();
    const mode = memberModes.modes[modeId];
    if (mode) {
        document.getElementById('modeModalTitle').innerText = 'Edit Mode';
        document.getElementById('modeName').value = mode.name;
        document.getElementById('modeStart').value = mode.startDate || '';
        document.getElementById('modeEnd').value = mode.endDate || '';
        document.getElementById('modeDescription').value = mode.description || '';
        document.getElementById('addModeModal').dataset.modeId = modeId;
        document.getElementById('addModeModal').style.display = 'flex';
    }
}

// Close mode modal
function otb_closeModeModal() {
    document.getElementById('addModeModal').style.display = 'none';
}

// Simpan mode
function otb_saveMode() {
    const modeId = document.getElementById('addModeModal').dataset.modeId;
    const name = document.getElementById('modeName').value.trim();
    const startDate = document.getElementById('modeStart').value;
    const endDate = document.getElementById('modeEnd').value;
    const description = document.getElementById('modeDescription').value;
    
    if (!name) {
        alert('Nama mode harus diisi');
        return;
    }
    
    if (modeId) {
        // Edit existing mode
        const mode = memberModes.modes[modeId];
        if (mode) {
            mode.name = name;
            mode.startDate = startDate;
            mode.endDate = endDate;
            mode.description = description;
        }
    } else {
        // Create new mode
        const newModeId = 'mode_' + Date.now();
        memberModes.modes[newModeId] = {
            name: name,
            startDate: startDate,
            endDate: endDate,
            members: [],
            description: description
        };
        
        // Switch ke mode baru
        memberModes.currentMode = newModeId;
    }
    
    saveModesToLocal();
    renderModeList();
    loadMembersForCurrentMode();
    otb_closeModeModal();
    showNotification('Mode berhasil disimpan!', 'success');
}

// Sync mode ke server
function otb_syncModeToServer(modeId) {
    const mode = memberModes.modes[modeId];
    if (!mode) return;
    
    fetch('/best-root/public/overtime/budget/save-mode', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
            mode_id: modeId,
            name: mode.name,
            start_date: mode.startDate,
            end_date: mode.endDate,
            description: mode.description,
            members: mode.members
        })
    })
    .then(response => response.json())
    .then(data => {
        if (!data.success) {
            console.log('Server sync failed:', data.message);
        }
    })
    .catch(error => console.log('Server sync error:', error));
}

// Simpan semua modes ke server
function otb_saveAllModes() {
    console.log('otb_saveAllModes dipanggil', memberModes); // Debug
    
    // ===== PENTING: Ambil dulu data dari FORM sebelum simpan =====
    // Ambil data dari tabel untuk mode yang sedang aktif
    const currentMode = memberModes.modes[memberModes.currentMode];
    const membersFromForm = [];
    
    document.querySelectorAll('#memberTableBody tr').forEach(row => {
        if (row.style.display !== 'none' && row.cells.length > 1) {
            const npk = row.querySelector('.npk-input')?.value;
            const name = row.querySelector('.name-input')?.value;
            const rate = row.querySelector('.rate-input')?.value;
            const status = row.querySelector('.status-select')?.value;
            
            if (npk && name) {
                membersFromForm.push({
                    id: row.dataset.id,
                    npk: npk,
                    name: name,
                    rate_per_hour: parseFloat(rate) || 0,
                    is_active: parseInt(status)
                });
            }
        }
    });
    
    // Update current mode dengan data dari form
    if (membersFromForm.length > 0) {
        currentMode.members = membersFromForm;
        console.log('Updated current mode from form:', currentMode.name, membersFromForm);
    }
    
    // Update statistik
    updateMemberStats(membersFromForm);
    
    // Simpan ke localStorage dulu
    saveModesToLocal();
    
    // Tampilkan loading di tombol
    const saveBtn = event.target;
    const originalText = saveBtn.innerHTML;
    saveBtn.innerHTML = '<i class="bi bi-hourglass"></i> Menyimpan...';
    saveBtn.disabled = true;
    
    // Kirim semua mode ke server
    fetch('/best-root/public/overtime/budget/save-modes', {
        method: 'POST',
        headers: { 
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({ modes: memberModes.modes })
    })
    .then(response => {
        console.log('Response status:', response.status);
        if (!response.ok) {
            throw new Error('Network response was not ok: ' + response.status);
        }
        return response.json();
    })
    .then(data => {
        console.log('Response data:', data);
        if (data.success) {
            showNotification('Semua mode berhasil disimpan ke server!', 'success');
            
            // Update global average rate
            const newAvgRate = calculateAvgRateFromMode(memberModes.currentMode);
            window.OTB_AVG_RATE = newAvgRate;
            
            // Update display
            const avgDisplay = document.getElementById('otb_avg_rate_display');
            if (avgDisplay) {
                avgDisplay.innerHTML = 'Rp ' + Math.round(newAvgRate).toLocaleString('id-ID');
            }
            
            // OPSIONAL: Tanyakan apakah ingin reload dari server
            // Kalau tidak ingin reload, kita tidak perlu panggil loadModesFromServer()
            // Tapi untuk memastikan konsistensi, kita bisa reload dalam mode "background"
            
            // Load dari server untuk update mode lain (tanpa mengubah data yang sudah diinput)
            return loadModesFromServer(false); // false = jangan timpa data yang sedang diedit
        } else {
            alert('Gagal: ' + (data.message || 'Terjadi kesalahan'));
        }
    })
    .catch(error => {
        console.error('Error detail:', error);
        alert('Kesalahan koneksi ke server: ' + error.message);
    })
    .finally(() => {
        // Kembalikan tombol ke keadaan semula
        saveBtn.innerHTML = originalText;
        saveBtn.disabled = false;
    });
}

// Load modes dari server
function loadModesFromServer(overwriteCurrentMode = true) {
    return fetch('/best-root/public/overtime/budget/get-modes')
        .then(response => response.json())
        .then(data => {
            if (data.success && data.modes) {
                console.log('Modes loaded from server:', data.modes);
                
                // Simpan data mode yang sedang aktif di form
                const currentModeId = memberModes.currentMode;
                
                // Merge dengan modes dari server
                Object.keys(data.modes).forEach(modeId => {
                    const serverMode = data.modes[modeId];
                    
                    // Hanya update jika mode ada di server
                    if (serverMode) {
                        // Untuk mode default, prioritaskan data lokal jika ada
                        if (modeId === 'default') {
                            // Jika default mode lokal kosong, pakai dari server
                            if (!memberModes.modes.default.members || memberModes.modes.default.members.length === 0) {
                                memberModes.modes.default = serverMode;
                            }
                            // Jika tidak, pertahankan data lokal
                        } else {
                            // Untuk mode kustom, update dari server
                            memberModes.modes[modeId] = serverMode;
                        }
                    }
                });
                
                // Hitung ulang average rate dari mode aktif
                const currentAvgRate = calculateAvgRateFromMode(memberModes.currentMode);
                window.OTB_AVG_RATE = currentAvgRate;
                
                // Update display
                updateRateDisplay();
                renderModeList();
                
                if (overwriteCurrentMode) {
                    loadMembersForCurrentMode();
                }
                
                updateBudgetModeDropdown();
                
                return data.modes;
            }
        })
        .catch(error => console.log('Error loading modes from server:', error));
}


// Save modes ke localStorage
function saveModesToLocal() {
    localStorage.setItem('memberModes', JSON.stringify(memberModes));
}

// Override fungsi otb_openMemberModal
const originalOpenMemberModal = otb_openMemberModal;
otb_openMemberModal = function() {
    loadMemberModes();
    document.getElementById('modalotmember').style.display = 'flex';
};

// Override fungsi otb_closeMemberModal
const originalCloseMemberModal = otb_closeMemberModal;
otb_closeMemberModal = function() {
    document.getElementById('modalotmember').style.display = 'none';
    // Refresh data di halaman utama
    refreshBudgetData();
};

// Fungsi konfirmasi hapus budget
function otb_confirmDelete(bulan, namaBulan) {
    if (confirm(`Apakah Anda yakin ingin menghapus budget bulan ${namaBulan}?`)) {
        otb_hapus(bulan);
    }
}

// Update fungsi otb_hapus yang sudah ada
function otb_hapus(bulan) {
    // Tampilkan loading
    const deleteBtn = event?.target?.closest('button');
    const originalHtml = deleteBtn?.innerHTML;
    if (deleteBtn) {
        deleteBtn.innerHTML = '<i class="bi bi-hourglass"></i>';
        deleteBtn.disabled = true;
    }
    
    fetch('/best-root/public/overtime/budget/delete', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ 
            tahun: <?= $tahun_ini ?>, 
            bulan: parseInt(bulan) 
        })
    })
    .then(r => r.json())
    .then(d => {
        if (d.success) {
            refreshBudgetData();
            showNotification('Budget bulan ' + getNamaBulan(bulan) + ' berhasil dihapus!', 'success');
        } else {
            alert('Gagal: ' + d.message);
            if (deleteBtn) {
                deleteBtn.innerHTML = originalHtml;
                deleteBtn.disabled = false;
            }
        }
    })
    .catch(error => {
        console.error('Error:', error);
        alert('Kesalahan koneksi ke server.');
        if (deleteBtn) {
            deleteBtn.innerHTML = originalHtml;
            deleteBtn.disabled = false;
        }
    });
}

// Helper function untuk mendapatkan nama bulan
function getNamaBulan(bulan) {
    const bulanList = ['Januari','Februari','Maret','April','Mei','Juni',
                       'Juli','Agustus','September','Oktober','November','Desember'];
    return bulanList[bulan - 1] || 'Bulan ' + bulan;
}


</script>

<style>
.ot-stat-card {
    background: var(--ot-bg);
    border-radius: 12px;
    padding: 14px 10px 12px;
    text-align: center;
    border: 1px solid color-mix(in srgb, var(--ot-color) 15%, transparent);
}
.ot-stat-card .stat-value { font-size: 1.4rem; font-weight: 700; color: var(--ot-color); }
.ot-stat-card .stat-label { font-size: 0.7rem; color: #6b7280; }

/* Animasi notifikasi */
@keyframes slideIn {
    from { transform: translateX(100%); opacity: 0; }
    to { transform: translateX(0); opacity: 1; }
}
@keyframes slideOut {
    from { transform: translateX(0); opacity: 1; }
    to { transform: translateX(100%); opacity: 0; }
}
</style>