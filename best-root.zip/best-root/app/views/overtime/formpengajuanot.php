<?php
/**
 * Form Pengajuan Overtime
 * Path  : /app/views/overtime/formpengajuanot.php
 * Dipanggil dari mainpage.php via:
 *   include BASE_PATH . '/app/views/overtime/formpengajuanot.php';
 *
 * Variabel yang diharapkan sudah tersedia dari mainpage.php:
 *   $name  – nama user yang login  ($_SESSION['name'])
 *   $npk   – NPK user yang login   ($_SESSION['npk'])
 */

// ── Data dummy — ganti dengan query DB sesuai $npk ──────────────────────────
$ot_pending   = 2;
$ot_disetujui = 9;
$ot_ditolak   = 1;

// Realisasi jam lembur per bulan (Jan–Des) untuk user ini
// Ganti dengan: SELECT bulan, SUM(jam) FROM ot_pengajuan
//               WHERE npk = $npk AND tahun = YEAR(NOW()) AND status = 'disetujui'
//               GROUP BY bulan
$ot_bulanan = [4, 6, 10, 8, 5, 9, 12, 7, 8, 3, 6, 0];

// ── Budget per bulan — sumber dari tabel ot_budget (halaman Budget Overtime) ─
// Jika budgetovertime.php sudah di-include sebelumnya, $ot_budget_per_bulan sudah ada.
// Jika belum, query langsung:
// SELECT bulan, jam FROM ot_budget WHERE tahun = YEAR(NOW()) ORDER BY bulan
if (!isset($ot_budget_per_bulan)) {
    $ot_budget_per_bulan = [8, 8, 10, 8, 8, 10, 10, 8, 8, 8, 8, 8]; // fallback dummy
}

// Kumulatif realisasi & budget
$ot_kumulatif        = [];
$ot_budget_kumulatif = [];
$sumReal = 0; $sumBud = 0;
foreach ($ot_bulanan as $i => $v) {
    $sumReal += $v;
    $sumBud  += $ot_budget_per_bulan[$i];
    $ot_kumulatif[]        = $sumReal;
    $ot_budget_kumulatif[] = $sumBud;
}

$bulan_labels = ['Jan','Feb','Mar','Apr','Mei','Jun','Jul','Ags','Sep','Okt','Nov','Des'];
$tahun_ini    = date('Y');
// ─────────────────────────────────────────────────────────────────────────────
?>

<!-- ======== OVERTIME FORM ======== -->
<div class="page" id="page-ot-form">
    <div class="mb-4">
        <div class="page-heading">Overtime — Form Pengajuan</div>
        <div class="page-sub">Ajukan permohonan lembur &amp; pantau riwayat Anda</div>
    </div>

    <!-- Layout: kiri (form) | kanan (statistik + chart) -->
    <div class="row g-3 align-items-start">

        <!-- ════════════════ KIRI — FORM ════════════════ -->
        <div class="col-12 col-xl-5">
            <div class="content-card">
                <div class="card-hdr">
                    <h5><i class="bi bi-pencil-square me-2" style="color:#818cf8;"></i>Form Pengajuan Overtime</h5>
                </div>
                <div class="row g-3">
                    <div class="col-12">
                        <label class="flbl">Nama Karyawan</label>
                        <input type="text" class="finp" value="<?= htmlspecialchars($name) ?>" readonly>
                    </div>
                    <div class="col-12">
                        <label class="flbl">NPK</label>
                        <input type="text" class="finp" value="<?= htmlspecialchars($npk) ?>" readonly>
                    </div>
                    <div class="col-12 col-sm-4">
                        <label class="flbl">Tanggal Lembur</label>
                        <input type="date" class="finp" id="ot_tanggal" name="ot_tanggal">
                    </div>
                    <div class="col-6 col-sm-4">
                        <label class="flbl">Jam Mulai</label>
                        <input type="time" class="finp" id="ot_jam_mulai" name="ot_jam_mulai">
                    </div>
                    <div class="col-6 col-sm-4">
                        <label class="flbl">Jam Selesai</label>
                        <input type="time" class="finp" id="ot_jam_selesai" name="ot_jam_selesai">
                    </div>
                    <div class="col-12">
                        <label class="flbl">Alasan / Pekerjaan</label>
                        <textarea class="finp" rows="3" id="ot_alasan" name="ot_alasan"
                                  placeholder="Jelaskan alasan lembur..."></textarea>
                    </div>
                    <div class="col-12">
                        <label class="flbl">Disetujui oleh (Atasan)</label>
                        <input type="text" class="finp" id="ot_atasan" name="ot_atasan"
                               placeholder="Nama atasan...">
                    </div>
                    <div class="col-12 d-flex gap-2 mt-1">
                        <button class="btn-p" onclick="submitFormOT()">
                            <i class="bi bi-send"></i> Kirim Pengajuan
                        </button>
                        <button class="btn-o" onclick="resetFormOT()">
                            <i class="bi bi-arrow-counterclockwise"></i> Reset
                        </button>
                    </div>
                </div>
            </div>
        </div>

        <!-- ════════════════ KANAN — STATISTIK + CHART ════════════════ -->
        <div class="col-12 col-xl-7 d-flex flex-column gap-3">

            <!-- ── Stat Cards: Pending / Disetujui / Ditolak ── -->
            <div class="row g-2">
                <div class="col-4">
                    <div class="ot-stat-card" style="--ot-color:#d97706;--ot-bg:#fffbeb;">
                        <div class="ot-stat-icon"><i class="bi bi-hourglass-split"></i></div>
                        <div class="ot-stat-val"><?= $ot_pending ?></div>
                        <div class="ot-stat-lbl">Pending</div>
                    </div>
                </div>
                <div class="col-4">
                    <div class="ot-stat-card" style="--ot-color:#16a34a;--ot-bg:#f0fdf4;">
                        <div class="ot-stat-icon"><i class="bi bi-check-circle-fill"></i></div>
                        <div class="ot-stat-val"><?= $ot_disetujui ?></div>
                        <div class="ot-stat-lbl">Disetujui</div>
                    </div>
                </div>
                <div class="col-4">
                    <div class="ot-stat-card" style="--ot-color:#dc2626;--ot-bg:#fef2f2;">
                        <div class="ot-stat-icon"><i class="bi bi-x-circle-fill"></i></div>
                        <div class="ot-stat-val"><?= $ot_ditolak ?></div>
                        <div class="ot-stat-lbl">Ditolak</div>
                    </div>
                </div>
            </div>

            <!-- ── Chart 1: Jam lembur per bulan vs budget ── -->
            <div class="content-card">
                <div class="card-hdr" style="margin-bottom:12px;">
                    <h5 style="font-size:0.82rem;">
                        <i class="bi bi-bar-chart-fill me-2" style="color:#818cf8;"></i>
                        Jam Lembur per Bulan — <?= $tahun_ini ?>
                    </h5>
                    <span class="ot-legend-wrap">
                        <span class="ot-legend-dot" style="background:#4f46e5;"></span><span class="ot-legend-txt">Realisasi</span>
                        <span class="ot-legend-dot" style="background:transparent;border:1.5px dashed #9ca3af;"></span><span class="ot-legend-txt">Budget</span>
                    </span>
                </div>
                <div style="position:relative;height:185px;">
                    <canvas id="chartOTBulanan"></canvas>
                </div>
            </div>

            <!-- ── Chart 2: Kumulatif tahunan vs budget ── -->
            <div class="content-card">
                <div class="card-hdr" style="margin-bottom:12px;">
                    <h5 style="font-size:0.82rem;">
                        <i class="bi bi-graph-up me-2" style="color:#818cf8;"></i>
                        Kumulatif Jam Lembur — <?= $tahun_ini ?>
                    </h5>
                    <span class="ot-legend-wrap">
                        <span class="ot-legend-dot" style="background:#4f46e5;"></span><span class="ot-legend-txt">Realisasi</span>
                        <span class="ot-legend-dot" style="background:#f59e0b;"></span><span class="ot-legend-txt">Budget</span>
                    </span>
                </div>
                <div style="position:relative;height:185px;">
                    <canvas id="chartOTKumulatif"></canvas>
                </div>
            </div>

        </div><!-- /kanan -->
    </div><!-- /row -->
</div>

<!-- ══════════════════════════════════════════════════
     STYLES  (scoped dengan prefix ot-)
══════════════════════════════════════════════════ -->
<style>
.ot-stat-card {
    background: var(--ot-bg);
    border-radius: 12px;
    padding: 14px 10px 12px;
    text-align: center;
    border: 1px solid color-mix(in srgb, var(--ot-color) 15%, transparent);
    transition: transform .15s, box-shadow .15s;
}
.ot-stat-card:hover { transform: translateY(-2px); box-shadow: 0 4px 12px rgba(0,0,0,.08); }
.ot-stat-icon { font-size: 1.25rem; color: var(--ot-color); margin-bottom: 6px; }
.ot-stat-val  { font-size: 1.6rem; font-weight: 800; color: var(--ot-color); line-height: 1; }
.ot-stat-lbl  { font-size: 0.7rem; color: #6b7280; margin-top: 4px; font-weight: 500; }

.ot-legend-wrap { display:flex; align-items:center; gap:6px; flex-shrink:0; }
.ot-legend-dot  { width:10px; height:10px; border-radius:3px; display:inline-block; flex-shrink:0; }
.ot-legend-txt  { font-size:0.68rem; color:#6b7280; }
</style>

<!-- ══════════════════════════════════════════════════
     SCRIPTS
══════════════════════════════════════════════════ -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/4.4.1/chart.umd.min.js"></script>
<script>
(function() {
    // ── Data dari PHP ──────────────────────────────────────────
    const OT_LABELS     = <?= json_encode($bulan_labels) ?>;
    const OT_BULANAN    = <?= json_encode($ot_bulanan) ?>;
    const OT_BUDGET_BUL = <?= json_encode(array_fill(0, 12, $ot_budget_bulanan)) ?>;
    const OT_KUMULATIF  = <?= json_encode($ot_kumulatif) ?>;
    const OT_BUDGET_KUM = <?= json_encode($ot_budget_kumulatif) ?>;

    // ── Warna bar: merah kalau over budget, biru kalau under ──
    function barColors(data, budget) {
        return data.map((v, i) => v > budget[i] ? '#dc262688' : '#4f46e5bb');
    }
    function barColorsBorder(data, budget) {
        return data.map((v, i) => v > budget[i] ? '#dc2626' : '#4f46e5');
    }

    // ── Plugin: label over/under di atas tiap bar ─────────────
    const overUnderPlugin = {
        id: 'otOverUnder',
        afterDatasetsDraw(chart) {
            const { ctx } = chart;
            const meta = chart.getDatasetMeta(0);
            meta.data.forEach((bar, i) => {
                const real = OT_BULANAN[i];
                const bud  = OT_BUDGET_BUL[i];
                if (real === 0) return;
                const diff = real - bud;
                if (diff === 0) return;
                const label = (diff > 0 ? '+' : '') + diff + 'h';
                const color = diff > 0 ? '#dc2626' : '#16a34a';
                ctx.save();
                ctx.font = 'bold 9px Segoe UI, sans-serif';
                ctx.fillStyle = color;
                ctx.textAlign = 'center';
                ctx.fillText(label, bar.x, bar.y - 5);
                ctx.restore();
            });
        }
    };

    // ── Chart 1: Bar bulanan ───────────────────────────────────
    new Chart(document.getElementById('chartOTBulanan').getContext('2d'), {
        type: 'bar',
        plugins: [overUnderPlugin],
        data: {
            labels: OT_LABELS,
            datasets: [
                {
                    label: 'Realisasi (jam)',
                    data: OT_BULANAN,
                    backgroundColor: barColors(OT_BULANAN, OT_BUDGET_BUL),
                    borderColor: barColorsBorder(OT_BULANAN, OT_BUDGET_BUL),
                    borderWidth: 1.5,
                    borderRadius: 5,
                    borderSkipped: false,
                    barPercentage: 0.55,
                },
                {
                    label: 'Budget (jam)',
                    data: OT_BUDGET_BUL,
                    type: 'line',
                    borderColor: '#9ca3af',
                    borderDash: [5, 4],
                    borderWidth: 1.5,
                    pointRadius: 0,
                    fill: false,
                    tension: 0,
                    order: 0,
                }
            ]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            layout: { padding: { top: 18 } },
            plugins: {
                legend: { display: false },
                tooltip: {
                    callbacks: {
                        label(ctx) {
                            const val = ctx.parsed.y;
                            if (ctx.datasetIndex === 0) {
                                const bud  = OT_BUDGET_BUL[ctx.dataIndex];
                                const diff = val - bud;
                                const tag  = diff > 0 ? `⚠ Over +${diff}h` : diff < 0 ? `✓ Under ${diff}h` : `✓ Sesuai budget`;
                                return [`Realisasi: ${val} jam`, tag];
                            }
                            return `Budget: ${ctx.parsed.y} jam`;
                        }
                    }
                }
            },
            scales: {
                x: { grid: { display: false }, ticks: { font: { size: 10 }, color: '#6b7280' } },
                y: {
                    beginAtZero: true, grid: { color: '#f3f4f6' },
                    ticks: { font: { size: 10 }, color: '#6b7280', callback: v => v + 'h' }
                }
            }
        }
    });

    // ── Chart 2: Line kumulatif ────────────────────────────────
    const ctx2 = document.getElementById('chartOTKumulatif').getContext('2d');
    const gradReal = ctx2.createLinearGradient(0, 0, 0, 185);
    gradReal.addColorStop(0, 'rgba(79,70,229,0.18)');
    gradReal.addColorStop(1, 'rgba(79,70,229,0)');
    const gradBud = ctx2.createLinearGradient(0, 0, 0, 185);
    gradBud.addColorStop(0, 'rgba(245,158,11,0.13)');
    gradBud.addColorStop(1, 'rgba(245,158,11,0)');

    new Chart(ctx2, {
        type: 'line',
        data: {
            labels: OT_LABELS,
            datasets: [
                {
                    label: 'Realisasi Kumulatif',
                    data: OT_KUMULATIF,
                    borderColor: '#4f46e5',
                    backgroundColor: gradReal,
                    borderWidth: 2.5,
                    pointRadius: 4,
                    pointBackgroundColor: OT_KUMULATIF.map((v, i) =>
                        v > OT_BUDGET_KUM[i] ? '#dc2626' : '#4f46e5'),
                    pointBorderColor: '#fff',
                    pointBorderWidth: 1.5,
                    fill: true,
                    tension: 0.35,
                },
                {
                    label: 'Budget Kumulatif',
                    data: OT_BUDGET_KUM,
                    borderColor: '#f59e0b',
                    backgroundColor: gradBud,
                    borderWidth: 2,
                    borderDash: [6, 4],
                    pointRadius: 0,
                    fill: true,
                    tension: 0.35,
                }
            ]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            interaction: { mode: 'index', intersect: false },
            plugins: {
                legend: { display: false },
                tooltip: {
                    callbacks: {
                        label(ctx) {
                            const val = ctx.parsed.y;
                            if (ctx.datasetIndex === 0) {
                                const bud  = OT_BUDGET_KUM[ctx.dataIndex];
                                const diff = val - bud;
                                const tag  = diff > 0 ? `⚠ Over +${diff}h` : diff < 0 ? `✓ Under ${diff}h` : `✓ Sesuai budget`;
                                return [`Realisasi: ${val} jam`, tag];
                            }
                            return `Budget: ${ctx.parsed.y} jam`;
                        }
                    }
                }
            },
            scales: {
                x: { grid: { display: false }, ticks: { font: { size: 10 }, color: '#6b7280' } },
                y: {
                    beginAtZero: true, grid: { color: '#f3f4f6' },
                    ticks: { font: { size: 10 }, color: '#6b7280', callback: v => v + 'h' }
                }
            }
        }
    });
})();

// ── Form logic ─────────────────────────────────────────────────
function submitFormOT() {
    const tanggal    = document.getElementById('ot_tanggal').value;
    const jamMulai   = document.getElementById('ot_jam_mulai').value;
    const jamSelesai = document.getElementById('ot_jam_selesai').value;
    const alasan     = document.getElementById('ot_alasan').value.trim();
    const atasan     = document.getElementById('ot_atasan').value.trim();

    if (!tanggal || !jamMulai || !jamSelesai || !alasan || !atasan) {
        alert('Harap lengkapi semua kolom sebelum mengirim.');
        return;
    }
    if (jamSelesai <= jamMulai) {
        alert('Jam selesai harus lebih besar dari jam mulai.');
        return;
    }

    // Kirim ke backend — sesuaikan URL dan uncomment
    /*
    fetch('/best-root/public/overtime/store', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ tanggal, jam_mulai: jamMulai, jam_selesai: jamSelesai, alasan, atasan })
    })
    .then(r => r.json())
    .then(d => {
        if (d.success) { alert('Pengajuan berhasil dikirim!'); resetFormOT(); }
        else alert('Gagal: ' + d.message);
    })
    .catch(() => alert('Kesalahan koneksi.'));
    */

    alert('Pengajuan overtime berhasil dikirim! (placeholder)');
    resetFormOT();
}

function resetFormOT() {
    ['ot_tanggal', 'ot_jam_mulai', 'ot_jam_selesai', 'ot_alasan', 'ot_atasan']
        .forEach(id => { document.getElementById(id).value = ''; });
}
</script>