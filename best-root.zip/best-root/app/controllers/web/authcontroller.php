<?php

namespace app\controllers\web;

use app\models\user;
use app\core\database;

class authcontroller
{
    /**
     * Proses login
     */
    public function authenticate()
    {
        // Cegah browser cache
        header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
        header("Pragma: no-cache");
        header("Expires: Sat, 01 Jan 2000 00:00:00 GMT");

        $npk      = trim($_POST['npk'] ?? '');
        $password = trim($_POST['password'] ?? '');

        // Validasi input tidak boleh kosong
        if (empty($npk) || empty($password)) {
            header('Location: /best-root/public/login?error=empty');
            exit;
        }

        // Ambil koneksi DB dan model User
        $pdo       = database::getInstance();
        $userModel = new user($pdo);

        // Cari user berdasarkan NPK
        $user = $userModel->getByNPK($npk);

        // Verifikasi password
        if ($user && password_verify($password, $user['password'])) {
            // Simpan data ke session
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['npk']     = $user['npk'];
            $_SESSION['name']    = $user['name'];
            $_SESSION['role']    = $user['role'];

            // Redirect ke main page
            header('Location: /best-root/public/mainpage');
            exit;
        }

        // Login gagal
        header('Location: /best-root/public/login?error=invalid');
        exit;
    }

    /**
     * Proses logout
     */
    public function logout()
    {
        // Cegah browser cache
        header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
        header("Pragma: no-cache");
        header("Expires: Sat, 01 Jan 2000 00:00:00 GMT");

        session_destroy();
        header('Location: /best-root/public/login');
        exit;
    }
}