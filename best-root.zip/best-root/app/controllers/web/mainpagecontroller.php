<?php

namespace app\controllers\web;

class mainpagecontroller
{
    public function index()
    {
        // Cegah browser cache
        header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
        header("Cache-Control: post-check=0, pre-check=0", false);
        header("Pragma: no-cache");
        header("Expires: Sat, 01 Jan 2000 00:00:00 GMT");

        // Cek session - kalau belum login redirect ke login
        if (!isset($_SESSION['user_id'])) {
            header('Location: /best-root/public/login');
            exit;
        }

        $name = $_SESSION['name'] ?? 'User';
        $role = $_SESSION['role'] ?? '-';

        require __DIR__ . '/../../../app/views/layouts/mainpage.php';
    }
}