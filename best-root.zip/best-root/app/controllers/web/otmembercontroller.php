<?php

namespace app\controllers\web;

use app\models\otmember;

class otmembercontroller
{
    private otmember $model;

    public function __construct()
    {
        $this->model = new otmember();
    }

    public function index(): void
    {
        $members = $this->model->getAll();
        $this->jsonResponse(['success' => true, 'members' => $members]);
    }

    public function store(): void
    {
        $body = $this->getJsonBody();
        
        if (isset($body['id'])) {
            // Update
            $ok = $this->model->update(
                (int)$body['id'],
                $body['npk'],
                $body['name'],
                (float)$body['rate_per_hour'],
                (bool)$body['is_active']
            );
        } else {
            // Create
            $ok = $this->model->create(
                $body['npk'],
                $body['name'],
                (float)$body['rate_per_hour']
            );
        }

        if ($ok) {
            $this->jsonResponse(['success' => true, 'message' => 'Member berhasil disimpan.']);
        } else {
            $this->jsonResponse(['success' => false, 'message' => 'Gagal menyimpan member.'], 500);
        }
    }

    public function destroy(): void
    {
        $body = $this->getJsonBody();
        $id = (int)($body['id'] ?? 0);

        if ($id <= 0) {
            $this->jsonResponse(['success' => false, 'message' => 'ID tidak valid.'], 422);
            return;
        }

        $ok = $this->model->delete($id);
        
        if ($ok) {
            $this->jsonResponse(['success' => true, 'message' => 'Member berhasil dinonaktifkan.']);
        } else {
            $this->jsonResponse(['success' => false, 'message' => 'Gagal menonaktifkan member.'], 500);
        }
    }

    private function getJsonBody(): array
    {
        $raw = file_get_contents('php://input');
        return json_decode($raw, true) ?? [];
    }

    private function jsonResponse(array $data, int $code = 200): void
    {
        http_response_code($code);
        header('Content-Type: application/json');
        echo json_encode($data);
        exit;
    }
}