<?php

namespace app\controllers\web;

use app\models\otbudget;
use app\models\otmember;
use app\models\otmultiplier;
use app\models\otmembermode;

class otbudgetcontroller
{
    private otbudget $model;
    private otmember $memberModel;
    private otmultiplier $multiplierModel;
    private otmembermode $memberModeModel;

    public function __construct()
    {
        $this->model = new otbudget();
        $this->memberModel = new otmember();
        $this->multiplierModel = new otmultiplier();
        $this->memberModeModel = new otmembermode(); 
    }

    public function index(): void
    {
        $tahun = (int)($_GET['tahun'] ?? date('Y'));

        $rows = $this->model->getByTahun($tahun);
        $summary = $this->model->getSummary($tahun);
        $chart = $this->model->toArrayBulanan($rows);
        $members = $this->memberModel->getAll();
        $avgRate = $this->memberModel->getAverageRate();
        $multiplier = $this->multiplierModel->getByTahun($tahun);

        $this->jsonResponse([
            'success' => true,
            'tahun' => $tahun,
            'rows' => $rows,
            'summary' => $summary,
            'chart' => $chart,
            'members' => $members,
            'avg_rate' => $avgRate,
            'multiplier' => $multiplier
        ]);
    }

    public function store(): void
    {
        $body = $this->getJsonBody();

        $tahun = (int)($body['tahun'] ?? 0);
        $bulan = (int)($body['bulan'] ?? 0);
        $jam = (float)($body['jam'] ?? 0);
        $amount = (float)($body['amount'] ?? 0);
        $keterangan = trim($body['keterangan'] ?? '');
        $target_percent = (float)($body['target_percent'] ?? 0);
        $target_amount = (float)($body['target_amount'] ?? 0);
        $target_jam = (float)($body['target_jam'] ?? 0);
        $member_targets = $body['member_targets'] ?? [];

        // Validasi
        if ($tahun < 2020 || $tahun > 2099) {
            $this->jsonResponse(['success' => false, 'message' => 'Tahun tidak valid.'], 422);
            return;
        }
        if ($bulan < 1 || $bulan > 12) {
            $this->jsonResponse(['success' => false, 'message' => 'Bulan tidak valid (1–12).'], 422);
            return;
        }
        if ($jam <= 0) {
            $this->jsonResponse(['success' => false, 'message' => 'Budget jam harus lebih dari 0.'], 422);
            return;
        }
        if ($amount <= 0) {
            $this->jsonResponse(['success' => false, 'message' => 'Budget amount harus lebih dari 0.'], 422);
            return;
        }

        $ok = $this->model->upsert($tahun, $bulan, $jam, $amount, $keterangan ?: null, 
                                    $target_percent, $target_amount, $target_jam);

        if ($ok) {
            $budget = $this->model->getOne($tahun, $bulan);
            if ($budget && !empty($member_targets)) {
                $this->model->saveMemberTargets($budget['id'], $member_targets);
            }
            $this->jsonResponse(['success' => true, 'message' => 'Budget berhasil disimpan.']);
        } else {
            $this->jsonResponse(['success' => false, 'message' => 'Gagal menyimpan ke database.'], 500);
        }
    }

    public function getMembers(): void
    {
        $members = $this->memberModel->getAll();
        $avgRate = $this->memberModel->getAverageRate();
        $multiplier = $this->multiplierModel->getByTahun((int)date('Y'));
        
        $this->jsonResponse([
            'success' => true,
            'members' => $members,
            'avg_rate' => $avgRate,
            'multiplier' => $multiplier
        ]);
    }

    public function saveMultiplier(): void
    {
        try {
            $body = $this->getJsonBody();
            
            // Validasi input
            $tahun = isset($body['tahun']) ? (int)$body['tahun'] : (int)date('Y');
            $multiplier = isset($body['multiplier']) ? (float)$body['multiplier'] : 1.5;
            $keterangan = isset($body['keterangan']) ? trim($body['keterangan']) : '';
            
            // Validasi range
            if ($tahun < 2020 || $tahun > 2099) {
                $this->jsonResponse([
                    'success' => false, 
                    'message' => 'Tahun tidak valid (2020-2099)'
                ], 422);
                return;
            }
            
            if ($multiplier < 1 || $multiplier > 3) {
                $this->jsonResponse([
                    'success' => false, 
                    'message' => 'Multiplier harus antara 1 - 3'
                ], 422);
                return;
            }
            
            // Simpan ke database
            $ok = $this->multiplierModel->upsert($tahun, $multiplier, $keterangan);
            
            if ($ok) {
                // Ambil data yang sudah disimpan
                $savedData = $this->multiplierModel->getDetailByTahun($tahun);
                
                $this->jsonResponse([
                    'success' => true,
                    'message' => 'Multiplier berhasil disimpan untuk tahun ' . $tahun,
                    'data' => $savedData
                ]);
            } else {
                $this->jsonResponse([
                    'success' => false, 
                    'message' => 'Gagal menyimpan multiplier ke database.'
                ], 500);
            }
        } catch (\Exception $e) {
            $this->jsonResponse([
                'success' => false,
                'message' => 'Error: ' . $e->getMessage()
            ], 500);
        }
    }

    public function destroy(): void
    {
        $body = $this->getJsonBody();
        $tahun = (int)($body['tahun'] ?? 0);
        $bulan = (int)($body['bulan'] ?? 0);

        if ($tahun < 2020 || $bulan < 1 || $bulan > 12) {
            $this->jsonResponse(['success' => false, 'message' => 'Parameter tidak valid.'], 422);
            return;
        }

        $ok = $this->model->delete($tahun, $bulan);

        if ($ok) {
            $this->jsonResponse(['success' => true, 'message' => 'Budget berhasil dihapus.']);
        } else {
            $this->jsonResponse(['success' => false, 'message' => 'Data tidak ditemukan atau gagal dihapus.'], 404);
        }
    }

    private function getJsonBody(): array
    {
        $raw = file_get_contents('php://input');
        return json_decode($raw, true) ?? [];
    }

    private function jsonResponse(array $data, int $code = 200): void
    {
        http_response_code($code);
        header('Content-Type: application/json');
        echo json_encode($data);
        exit;
    }

    public function getMultiplier(): void
    {
        $tahun = (int)($_GET['tahun'] ?? date('Y'));
        
        try {
            // Ambil detail dari model (lebih bersih)
            $detail = $this->multiplierModel->getDetailByTahun($tahun);
            
            $this->jsonResponse([
                'success' => true,
                'tahun' => $tahun,
                'multiplier' => $detail['multiplier'] ?? 1.5,
                'keterangan' => $detail['keterangan'] ?? ''
            ]);
        } catch (\Exception $e) {
            $this->jsonResponse([
                'success' => false,
                'message' => $e->getMessage()
            ], 500);
        }
    }

    /**
     * GET /overtime/budget/get-modes
     * Mendapatkan semua mode member
     */
    public function getModes(): void
    {
        try {
            $modes = $this->memberModeModel->getAllModes();
            
            $this->jsonResponse([
                'success' => true,
                'modes' => $modes
            ]);
        } catch (\Exception $e) {
            $this->jsonResponse([
                'success' => false,
                'message' => 'Gagal mengambil data modes: ' . $e->getMessage()
            ], 500);
        }
    }

    /**
     * POST /overtime/budget/save-mode
     * Menyimpan satu mode member
     */
    public function saveMode(): void
    {
        try {
            $body = $this->getJsonBody();
            
            $modeId = $body['mode_id'] ?? '';
            $name = $body['name'] ?? '';
            $startDate = $body['start_date'] ?? null;
            $endDate = $body['end_date'] ?? null;
            $description = $body['description'] ?? '';
            $members = $body['members'] ?? [];
            
            // Validasi
            if (empty($modeId)) {
                $this->jsonResponse([
                    'success' => false,
                    'message' => 'Mode ID harus diisi'
                ], 422);
                return;
            }
            
            if (empty($name)) {
                $this->jsonResponse([
                    'success' => false,
                    'message' => 'Nama mode harus diisi'
                ], 422);
                return;
            }
            
            // Simpan mode
            $ok = $this->memberModeModel->saveMode(
                $modeId,
                $name,
                $startDate,
                $endDate,
                $description,
                $members
            );
            
            if ($ok) {
                $this->jsonResponse([
                    'success' => true,
                    'message' => 'Mode berhasil disimpan'
                ]);
            } else {
                $this->jsonResponse([
                    'success' => false,
                    'message' => 'Gagal menyimpan mode'
                ], 500);
            }
        } catch (\Exception $e) {
            $this->jsonResponse([
                'success' => false,
                'message' => 'Error: ' . $e->getMessage()
            ], 500);
        }
    }

    /**
     * POST /overtime/budget/save-modes
     * Menyimpan semua mode member sekaligus
     */
    public function saveModes(): void
    {
        try {
            $body = $this->getJsonBody();
            $modes = $body['modes'] ?? [];
            
            if (empty($modes)) {
                $this->jsonResponse([
                    'success' => false,
                    'message' => 'Tidak ada data mode yang dikirim'
                ], 422);
                return;
            }
            
            $success = true;
            $savedCount = 0;
            
            foreach ($modes as $modeId => $mode) {
                $ok = $this->memberModeModel->saveMode(
                    $modeId,
                    $mode['name'] ?? '',
                    $mode['startDate'] ?? null,
                    $mode['endDate'] ?? null,
                    $mode['description'] ?? '',
                    $mode['members'] ?? []
                );
                
                if ($ok) {
                    $savedCount++;
                } else {
                    $success = false;
                }
            }
            
            if ($success) {
                $this->jsonResponse([
                    'success' => true,
                    'message' => "Semua mode berhasil disimpan ($savedCount mode)"
                ]);
            } else {
                $this->jsonResponse([
                    'success' => false,
                    'message' => "Beberapa mode gagal disimpan ($savedCount dari " . count($modes) . " berhasil)"
                ], 500);
            }
        } catch (\Exception $e) {
            $this->jsonResponse([
                'success' => false,
                'message' => 'Error: ' . $e->getMessage()
            ], 500);
        }
    }

    /**
     * DELETE /overtime/budget/delete-mode
     * Menghapus mode member
     */
    public function deleteMode(): void
    {
        try {
            $body = $this->getJsonBody();
            $modeId = $body['mode_id'] ?? '';
            
            if (empty($modeId)) {
                $this->jsonResponse([
                    'success' => false,
                    'message' => 'Mode ID harus diisi'
                ], 422);
                return;
            }
            
            // Jangan izinkan hapus mode default
            if ($modeId === 'default') {
                $this->jsonResponse([
                    'success' => false,
                    'message' => 'Mode default tidak dapat dihapus'
                ], 422);
                return;
            }
            
            $ok = $this->memberModeModel->deleteMode($modeId);
            
            if ($ok) {
                $this->jsonResponse([
                    'success' => true,
                    'message' => 'Mode berhasil dihapus'
                ]);
            } else {
                $this->jsonResponse([
                    'success' => false,
                    'message' => 'Mode tidak ditemukan atau gagal dihapus'
                ], 404);
            }
        } catch (\Exception $e) {
            $this->jsonResponse([
                'success' => false,
                'message' => 'Error: ' . $e->getMessage()
            ], 500);
        }
    }

    // ... method lainnya (getJsonBody, jsonResponse) ...

        /**
     * Test endpoint - untuk debugging
     */
    public function test(): void
    {
        echo "Test endpoint berfungsi!";
        exit;
    }

    /**
     * Test koneksi database
     */
    public function testDb(): void
    {
        try {
            // Test koneksi database
            $db = \app\core\database::getInstance();
            $stmt = $db->query("SELECT 1 as test");
            $result = $stmt->fetch();
            
            // Test tabel ot_multiplier
            $tables = $db->query("SHOW TABLES LIKE 'ot_multiplier'")->fetchAll();
            
            // Test insert
            $testTahun = 9999;
            $this->multiplierModel->upsert($testTahun, 1.5, 'Test');
            
            $this->jsonResponse([
                'success' => true,
                'database' => 'Connected',
                'table_exists' => count($tables) > 0,
                'test_insert' => 'OK',
                'result' => $result
            ]);
        } catch (\Exception $e) {
            $this->jsonResponse([
                'success' => false,
                'error' => $e->getMessage()
            ], 500);
        }
    }
}