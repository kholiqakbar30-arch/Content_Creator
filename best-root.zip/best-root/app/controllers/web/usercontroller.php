<?php
namespace app\controllers\web;

use app\core\database;

class usercontroller
{
    private $db;

    public function __construct()
    {
        $this->db = database::getInstance();
    }

    /**
     * GET /users/search?q=...
     * Mencari users berdasarkan NPK atau Nama
     */
    public function search()
    {
        $query = $_GET['q'] ?? '';
        
        if (strlen($query) < 2) {
            $this->jsonResponse([]);
            return;
        }

        try {
            $search = "%$query%";
            $stmt = $this->db->prepare("
                SELECT npk, name, role 
                FROM users 
                WHERE npk LIKE ? OR name LIKE ? 
                LIMIT 10
            ");
            $stmt->execute([$search, $search]);
            $users = $stmt->fetchAll(\PDO::FETCH_ASSOC);
            
            $this->jsonResponse($users);
        } catch (\Exception $e) {
            $this->jsonResponse(['error' => $e->getMessage()], 500);
        }
    }

    /**
     * GET /users/get-rate?npk=...
     * Mendapatkan rate user (default 50000 karena tidak ada kolom rate di tabel users)
     */
    public function getRate()
    {
        $npk = $_GET['npk'] ?? '';
        
        if (empty($npk)) {
            $this->jsonResponse(['success' => false, 'message' => 'NPK required'], 400);
            return;
        }

        try {
            // Cek apakah user ada di tabel users
            $stmt = $this->db->prepare("SELECT npk FROM users WHERE npk = ?");
            $stmt->execute([$npk]);
            $exists = $stmt->fetch();
            
            if ($exists) {
                // Kembalikan rate default 50000
                $this->jsonResponse([
                    'success' => true, 
                    'rate' => 50000
                ]);
            } else {
                $this->jsonResponse([
                    'success' => false, 
                    'message' => 'User tidak ditemukan'
                ], 404);
            }
            
        } catch (\Exception $e) {
            $this->jsonResponse([
                'success' => false, 
                'message' => $e->getMessage()
            ], 500);
        }
    }

    /**
     * GET /users/get-all
     * Mendapatkan semua users untuk import
     */
    public function getAll()
    {
        try {
            // Query dengan struktur tabel yang benar
            $stmt = $this->db->query("
                SELECT npk, name, role 
                FROM users 
                ORDER BY name ASC
            ");
            $users = $stmt->fetchAll(\PDO::FETCH_ASSOC);
            
            $this->jsonResponse($users);
        } catch (\Exception $e) {
            $this->jsonResponse(['error' => $e->getMessage()], 500);
        }
    }

    /**
     * Helper untuk JSON response
     */
    private function jsonResponse($data, $code = 200)
    {
        http_response_code($code);
        header('Content-Type: application/json');
        echo json_encode($data);
        exit;
    }
}