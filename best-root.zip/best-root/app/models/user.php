<?php

namespace app\models;

use PDO;

class user
{
    private $pdo;
    private $table = 'users';

    public function __construct(PDO $pdo)
    {
        $this->pdo = $pdo;
    }

    /**
     * Ambil user berdasarkan NPK
     */
    public function getByNPK($npk)
    {
        $stmt = $this->pdo->prepare("SELECT * FROM {$this->table} WHERE npk = :npk LIMIT 1");
        $stmt->execute([':npk' => $npk]);
        return $stmt->fetch();
    }

    /**
     * Ambil user berdasarkan ID
     */
    public function getById($id)
    {
        $stmt = $this->pdo->prepare("SELECT * FROM {$this->table} WHERE id = :id LIMIT 1");
        $stmt->execute([':id' => $id]);
        return $stmt->fetch();
    }

    /**
     * Ambil semua user
     */
    public function getAll()
    {
        $stmt = $this->pdo->query("SELECT * FROM {$this->table}");
        return $stmt->fetchAll();
    }
}