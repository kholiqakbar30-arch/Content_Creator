<?php

namespace app\models;

use app\core\database;
use PDO;

class otmultiplier
{
    private PDO $db;

    public function __construct()
    {
        $this->db = database::getInstance();
    }

    public function getByTahun(int $tahun): float
    {
        $stmt = $this->db->prepare("
            SELECT multiplier FROM ot_multiplier WHERE tahun = :tahun
        ");
        $stmt->execute([':tahun' => $tahun]);
        $result = $stmt->fetch();
        return $result ? (float)$result['multiplier'] : 1.5;
    }

    public function upsert(int $tahun, float $multiplier, ?string $keterangan): bool
    {
        // Cek apakah data sudah ada
        $check = $this->db->prepare("SELECT id FROM ot_multiplier WHERE tahun = :tahun");
        $check->execute([':tahun' => $tahun]);
        $exists = $check->fetch();
        
        if ($exists) {
            // Update
            $stmt = $this->db->prepare("
                UPDATE ot_multiplier 
                SET multiplier = :multiplier, 
                    keterangan = :keterangan, 
                    updated_at = CURRENT_TIMESTAMP
                WHERE tahun = :tahun
            ");
        } else {
            // Insert
            $stmt = $this->db->prepare("
                INSERT INTO ot_multiplier (tahun, multiplier, keterangan)
                VALUES (:tahun, :multiplier, :keterangan)
            ");
        }
        
        return $stmt->execute([
            ':tahun' => $tahun,
            ':multiplier' => $multiplier,
            ':keterangan' => $keterangan
        ]);
    }
    
    /**
     * Ambil detail lengkap multiplier berdasarkan tahun
     */
    public function getDetailByTahun(int $tahun): array
    {
        $stmt = $this->db->prepare("
            SELECT id, tahun, multiplier, keterangan, created_at, updated_at 
            FROM ot_multiplier 
            WHERE tahun = :tahun
        ");
        $stmt->execute([':tahun' => $tahun]);
        $result = $stmt->fetch();
        
        return $result ?: [
            'multiplier' => 1.5, 
            'keterangan' => '',
            'tahun' => $tahun
        ];
    }
}