<?php

namespace app\models;

use app\core\database;
use PDO;

class otbudget
{
    private PDO $db;

    public function __construct()
    {
        $this->db = database::getInstance();
    }

    public function getByTahun(int $tahun): array
    {
        $stmt = $this->db->prepare("
            SELECT bulan, jam, amount, keterangan, target_percent, target_amount, target_jam
            FROM ot_budget
            WHERE tahun = :tahun
            ORDER BY bulan
        ");
        $stmt->execute([':tahun' => $tahun]);
        return $stmt->fetchAll();
    }

    public function getOne(int $tahun, int $bulan): array|false
    {
        $stmt = $this->db->prepare("
            SELECT id, tahun, bulan, jam, amount, keterangan, target_percent, target_amount, target_jam
            FROM ot_budget
            WHERE tahun = :tahun AND bulan = :bulan
        ");
        $stmt->execute([':tahun' => $tahun, ':bulan' => $bulan]);
        return $stmt->fetch();
    }

    public function upsert(int $tahun, int $bulan, float $jam, float $amount, 
                           ?string $keterangan, float $target_percent = 0, 
                           float $target_amount = 0, float $target_jam = 0): bool
    {
        $stmt = $this->db->prepare("
            INSERT INTO ot_budget (tahun, bulan, jam, amount, keterangan, target_percent, target_amount, target_jam)
            VALUES (:tahun, :bulan, :jam, :amount, :keterangan, :target_percent, :target_amount, :target_jam)
            ON CONFLICT (tahun, bulan)
            DO UPDATE SET
                jam = EXCLUDED.jam,
                amount = EXCLUDED.amount,
                keterangan = EXCLUDED.keterangan,
                target_percent = EXCLUDED.target_percent,
                target_amount = EXCLUDED.target_amount,
                target_jam = EXCLUDED.target_jam,
                updated_at = CURRENT_TIMESTAMP
        ");
        return $stmt->execute([
            ':tahun' => $tahun,
            ':bulan' => $bulan,
            ':jam' => $jam,
            ':amount' => $amount,
            ':keterangan' => $keterangan,
            ':target_percent' => $target_percent,
            ':target_amount' => $target_amount,
            ':target_jam' => $target_jam
        ]);
    }

    public function saveMemberTargets(int $budgetId, array $memberTargets): bool
    {
        // Hapus data lama
        $delete = $this->db->prepare("DELETE FROM ot_budget_member WHERE budget_id = :budget_id");
        $delete->execute([':budget_id' => $budgetId]);

        // Insert data baru
        $insert = $this->db->prepare("
            INSERT INTO ot_budget_member (budget_id, member_id, target_jam)
            VALUES (:budget_id, :member_id, :target_jam)
        ");

        foreach ($memberTargets as $target) {
            if ($target['jam'] > 0) {
                $insert->execute([
                    ':budget_id' => $budgetId,
                    ':member_id' => $target['member_id'],
                    ':target_jam' => $target['jam']
                ]);
            }
        }
        return true;
    }

    public function getMemberTargets(int $tahun, int $bulan): array
    {
        $stmt = $this->db->prepare("
            SELECT bm.member_id, m.npk, m.name, m.rate_per_hour, bm.target_jam
            FROM ot_budget_member bm
            JOIN ot_member m ON m.id = bm.member_id
            JOIN ot_budget b ON b.id = bm.budget_id
            WHERE b.tahun = :tahun AND b.bulan = :bulan
            ORDER BY m.name
        ");
        $stmt->execute([':tahun' => $tahun, ':bulan' => $bulan]);
        return $stmt->fetchAll();
    }

    public function delete(int $tahun, int $bulan): bool
    {
        $stmt = $this->db->prepare("
            DELETE FROM ot_budget
            WHERE tahun = :tahun AND bulan = :bulan
        ");
        return $stmt->execute([':tahun' => $tahun, ':bulan' => $bulan]);
    }

    public function getSummary(int $tahun): array
    {
        $stmt = $this->db->prepare("
            SELECT
                COALESCE(SUM(jam), 0) AS total_jam,
                COALESCE(SUM(amount), 0) AS total_amount,
                COALESCE(SUM(target_amount), 0) AS total_target_amount,
                COALESCE(SUM(target_jam), 0) AS total_target_jam,
                COUNT(*) AS bulan_terisi
            FROM ot_budget
            WHERE tahun = :tahun
        ");
        $stmt->execute([':tahun' => $tahun]);
        return $stmt->fetch();
    }

    public function toArrayBulanan(array $rows): array
    {
        $jam = array_fill(0, 12, 0);
        $amount = array_fill(0, 12, 0);
        $target_amount = array_fill(0, 12, 0);
        $target_jam = array_fill(0, 12, 0);
        $target_percent = array_fill(0, 12, 0);
        
        foreach ($rows as $row) {
            $idx = (int)$row['bulan'] - 1;
            $jam[$idx] = (float)$row['jam'];
            $amount[$idx] = (float)$row['amount'];
            $target_amount[$idx] = (float)($row['target_amount'] ?? 0);
            $target_jam[$idx] = (float)($row['target_jam'] ?? 0);
            $target_percent[$idx] = (float)($row['target_percent'] ?? 0);
        }
        
        return [
            'jam' => $jam, 
            'amount' => $amount,
            'target_amount' => $target_amount,
            'target_jam' => $target_jam,
            'target_percent' => $target_percent
        ];
    }
}