<?php
namespace app\models;

use app\core\database;
use PDO;

class otmembermode
{
    private PDO $db;
    private string $table = 'ot_member_modes';

    public function __construct()
    {
        $this->db = database::getInstance();
        $this->createTableIfNotExists();
    }

    /**
     * Buat tabel jika belum ada - versi PostgreSQL
     */
    private function createTableIfNotExists(): void
    {
        // Cek apakah tabel sudah ada
        $stmt = $this->db->prepare("
            SELECT EXISTS (
                SELECT FROM information_schema.tables 
                WHERE table_name = ?
            )
        ");
        $stmt->execute([$this->table]);
        $exists = $stmt->fetchColumn();
        
        if (!$exists) {
            $sql = "
                CREATE TABLE {$this->table} (
                    id SERIAL PRIMARY KEY,
                    mode_id VARCHAR(50) NOT NULL UNIQUE,
                    name VARCHAR(100) NOT NULL,
                    start_date VARCHAR(20) NULL,
                    end_date VARCHAR(20) NULL,
                    description TEXT NULL,
                    members TEXT NULL,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                )
            ";
            
            try {
                $this->db->exec($sql);
                error_log("Tabel {$this->table} berhasil dibuat");
            } catch (\Exception $e) {
                error_log("Error creating table {$this->table}: " . $e->getMessage());
            }
        }
    }

    /**
     * Mendapatkan semua mode member
     */
    public function getAllModes(): array
    {
        $stmt = $this->db->query("
            SELECT * FROM {$this->table} 
            ORDER BY 
                CASE 
                    WHEN mode_id = 'default' THEN 0 
                    ELSE 1 
                END, 
                name ASC
        ");
        
        $modes = [];
        while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
            $modes[$row['mode_id']] = [
                'name' => $row['name'],
                'startDate' => $row['start_date'],
                'endDate' => $row['end_date'],
                'description' => $row['description'],
                'members' => json_decode($row['members'], true) ?: []
            ];
        }
        
        return $modes;
    }

    /**
     * Mendapatkan satu mode berdasarkan ID
     */
    public function getMode(string $modeId): ?array
    {
        $stmt = $this->db->prepare("SELECT * FROM {$this->table} WHERE mode_id = ?");
        $stmt->execute([$modeId]);
        
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        if (!$row) {
            return null;
        }
        
        return [
            'name' => $row['name'],
            'startDate' => $row['start_date'],
            'endDate' => $row['end_date'],
            'description' => $row['description'],
            'members' => json_decode($row['members'], true) ?: []
        ];
    }

    /**
     * Menyimpan mode member
     */
    public function saveMode(
        string $modeId,
        string $name,
        ?string $startDate,
        ?string $endDate,
        string $description,
        array $members
    ): bool {
        try {
            // Cek apakah mode sudah ada
            $stmt = $this->db->prepare("SELECT id FROM {$this->table} WHERE mode_id = ?");
            $stmt->execute([$modeId]);
            
            $membersJson = json_encode($members, JSON_UNESCAPED_UNICODE);
            
            if ($stmt->fetch()) {
                // Update
                $stmt = $this->db->prepare("
                    UPDATE {$this->table} 
                    SET name = ?, 
                        start_date = ?, 
                        end_date = ?, 
                        description = ?, 
                        members = ?, 
                        updated_at = CURRENT_TIMESTAMP
                    WHERE mode_id = ?
                ");
                
                return $stmt->execute([
                    $name,
                    $startDate,
                    $endDate,
                    $description,
                    $membersJson,
                    $modeId
                ]);
            } else {
                // Insert
                $stmt = $this->db->prepare("
                    INSERT INTO {$this->table} 
                        (mode_id, name, start_date, end_date, description, members, created_at) 
                    VALUES (?, ?, ?, ?, ?, ?, CURRENT_TIMESTAMP)
                ");
                
                return $stmt->execute([
                    $modeId,
                    $name,
                    $startDate,
                    $endDate,
                    $description,
                    $membersJson
                ]);
            }
        } catch (\Exception $e) {
            error_log("Error saveMode: " . $e->getMessage());
            return false;
        }
    }

    /**
     * Menghapus mode member
     */
    public function deleteMode(string $modeId): bool
    {
        try {
            $stmt = $this->db->prepare("DELETE FROM {$this->table} WHERE mode_id = ?");
            return $stmt->execute([$modeId]);
        } catch (\Exception $e) {
            error_log("Error deleteMode: " . $e->getMessage());
            return false;
        }
    }
}