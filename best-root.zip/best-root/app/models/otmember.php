<?php

namespace app\models;

use app\core\database;
use PDO;

class otmember
{
    private PDO $db;

    public function __construct()
    {
        $this->db = database::getInstance();
    }

    public function getAll(): array
    {
        $stmt = $this->db->query("
            SELECT id, npk, name, rate_per_hour, is_active 
            FROM ot_member 
            WHERE is_active = true 
            ORDER BY name
        ");
        return $stmt->fetchAll();
    }

    public function getAverageRate(): float
    {
        $stmt = $this->db->query("
            SELECT COALESCE(AVG(rate_per_hour), 0) as avg_rate 
            FROM ot_member 
            WHERE is_active = true
        ");
        $result = $stmt->fetch();
        return (float)$result['avg_rate'];
    }

    public function create(string $npk, string $name, float $rate_per_hour): bool
    {
        $stmt = $this->db->prepare("
            INSERT INTO ot_member (npk, name, rate_per_hour)
            VALUES (:npk, :name, :rate_per_hour)
        ");
        return $stmt->execute([
            ':npk' => $npk,
            ':name' => $name,
            ':rate_per_hour' => $rate_per_hour
        ]);
    }

    public function update(int $id, string $npk, string $name, float $rate_per_hour, bool $is_active): bool
    {
        $stmt = $this->db->prepare("
            UPDATE ot_member 
            SET npk = :npk, name = :name, rate_per_hour = :rate_per_hour, 
                is_active = :is_active, updated_at = CURRENT_TIMESTAMP
            WHERE id = :id
        ");
        return $stmt->execute([
            ':id' => $id,
            ':npk' => $npk,
            ':name' => $name,
            ':rate_per_hour' => $rate_per_hour,
            ':is_active' => $is_active
        ]);
    }

    public function delete(int $id): bool
    {
        $stmt = $this->db->prepare("UPDATE ot_member SET is_active = false WHERE id = :id");
        return $stmt->execute([':id' => $id]);
    }
}