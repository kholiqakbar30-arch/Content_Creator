<?php

namespace app\middleware;

class authMiddleware
{
    public function handle()
    {
        if (!isset($_SESSION['user_id'])) {
            header('Location: /best-root/public/login');
            exit;
        }
    }
}