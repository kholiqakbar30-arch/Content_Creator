<?php

namespace app\middleware;

class rolemiddleware
{
    public function handle($role)
    {
        if (!isset($_SESSION['role']) || $_SESSION['role'] !== $role) {
            http_response_code(403);
            echo "<h1>403 - Akses Ditolak</h1>";
            exit;
        }
    }
}