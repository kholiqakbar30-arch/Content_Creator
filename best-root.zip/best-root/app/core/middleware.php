<?php

namespace app\Core;

class middleware
{
    public static function handle(array $middlewares)
    {
        foreach ($middlewares as $middleware) {
            if (str_contains($middleware, ':')) {
                [$name, $param] = explode(':', $middleware);
                $class = "app\\middleware\\" . ucfirst($name) . "middleware";
                (new $class)->handle($param);
            } else {
                $class = "app\\middleware\\" . ucfirst($middleware) . "middleware";
                (new $class)->handle();
            }
        }
    }
}