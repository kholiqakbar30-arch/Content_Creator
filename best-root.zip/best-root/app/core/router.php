<?php

namespace app\core;

class router
{
    protected static array $routes = [];

    public static function get($uri, $action, $middleware = [])
    {
        self::$routes['GET'][$uri] = compact('action', 'middleware');
    }

    public static function post($uri, $action, $middleware = [])
    {
        self::$routes['POST'][$uri] = compact('action', 'middleware');
    }

    public static function dispatch()
    {
        $uri = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);

        // Hapus base path /best-root/public
        $basePath = '/best-root/public';
        if (str_starts_with($uri, $basePath)) {
            $uri = substr($uri, strlen($basePath)) ?: '/';
        }

        $method = $_SERVER['REQUEST_METHOD'];

        if (!isset(self::$routes[$method][$uri])) {
            http_response_code(404);
            echo "<h1>404 - Halaman Tidak Ditemukan</h1>";
            return;
        }

        $route = self::$routes[$method][$uri];

        // Jalankan middleware jika ada
        if (!empty($route['middleware'])) {
            Middleware::handle($route['middleware']);
        }

        // Jika Closure
        if ($route['action'] instanceof \Closure) {
            $route['action']();
            return;
        }

        // Jika string "Controller@method"
        [$controller, $methodAction] = explode('@', $route['action']);
        $controller = strtolower("app\\controllers\\{$controller}");
        (new $controller)->$methodAction();
    }
}