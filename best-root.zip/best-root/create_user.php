<?php
// Data user yang mau dibuat
$npk = "XJ58478";          // NPK karyawan
$name = "Muhammad Nurkholiq Akbar";  // Nama
$password_plain = "Yamaha123*"; // Password asli
$email = "nurkholiq_purc@yamaha-motor.co.id";
$role = "Admin";          // bisa user/admin/etc

// Buat hash password
$password_hash = password_hash($password_plain, PASSWORD_DEFAULT);

echo "Hash password: " . $password_hash;
