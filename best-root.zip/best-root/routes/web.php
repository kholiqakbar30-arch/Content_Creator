<?php

use app\core\router;

// Root → redirect ke login
router::get('/', function () {
    header('Location: /best-root/public/login');
    exit;
});

// Tampilkan halaman login
router::get('/login', function () {
    require __DIR__ . '/../app/views/auth/login.php';
});

// Proses login (POST)
router::post('/login', 'web\authcontroller@authenticate');

// Main page (butuh login)
router::get('/mainpage', 'web\mainpagecontroller@index', ['auth']);

// Logout
router::get('/logout', 'web\authcontroller@logout');

// Overtime Budget Routes - TAMBAHKAN 'web\' DI DEPAN
router::get('/overtime/budget/data', 'web\otbudgetcontroller@index');
router::post('/overtime/budget/store', 'web\otbudgetcontroller@store');
router::post('/overtime/budget/delete', 'web\otbudgetcontroller@destroy');
router::get('/overtime/budget/members', 'web\otbudgetcontroller@getMembers');
router::post('/overtime/budget/save-multiplier', 'web\otbudgetcontroller@saveMultiplier');
router::get('/overtime/budget/multiplier', 'web\otbudgetcontroller@getMultiplier');

// Member Management Routes - TAMBAHKAN 'web\' DI DEPAN
router::get('/overtime/members', 'web\otmembercontroller@index');
router::post('/overtime/members/store', 'web\otmembercontroller@store');
router::post('/overtime/members/delete', 'web\otmembercontroller@destroy');

// Routes untuk fitur mode member
router::get('/overtime/budget/get-modes', 'web\otbudgetcontroller@getModes');
router::post('/overtime/budget/save-mode', 'web\otbudgetcontroller@saveMode');
router::post('/overtime/budget/save-modes', 'web\otbudgetcontroller@saveModes');
router::post('/overtime/budget/delete-mode', 'web\otbudgetcontroller@deleteMode');

// Routes untuk users
router::get('/users/search', 'web\usercontroller@search');
router::get('/users/get-rate', 'web\usercontroller@getRate');
router::get('/users/get-all', 'web\usercontroller@getAll');
