<?php

use app\core\router;

// Root → redirect ke login
router::get('/', function () {
    header('Location: /best-root/public/login');
    exit;
});

// Tampilkan halaman login
router::get('/login', function () {
    require __DIR__ . '/../app/views/auth/login.php';
});

// Proses login (POST)
router::post('/login', 'web\authcontroller@authenticate');

// Main page (butuh login)
router::get('/mainpage', 'web\mainpagecontroller@index', ['auth']);

// Logout
router::get('/logout', 'web\authcontroller@logout');